#include "stm32f10x.h"
#include "stm32f10x_conf.h"

#include "stdio.h"
#include "string.h"

#include "flash.h"
#include "datahand.h"
#include "gpsnet.h"
#include "usart.h"
#include "485.h"
#include "delay.h"

#include "Jdy_19.h"
#include "stmflash.h"

#include "iobind.h"

/*
*�ļ�������Flash�洢
*�ļ���дʱ�䣺2020��4��7��
*/

#define flag_nem 72       //����69�� ����һ��GPS�豸��
#define one_flag_leng 10  //ÿ����Ŀ

u8 FontBuffer_Read[1300] = {0};
u8 sendbuft[8];

u16 Over_Vol_Readflash = 0;
u16 Down_Vol_Readflash = 0;
u16 SOH_Readflash = 0;

//ÿһ������� AA 55 ��ͷ �����ǰ˸��ֽ���Ϣ����--��0�鿪ʼ�� ���ֽ���ǰ

/*
*��������flash_read_sys_flag
*����������wu
*��������ֵ��wu
*�������ܣ���ʼ����ȡflash����
*/
void flash_read_sys_flag(void)
{
    /*��ȡ�洢����*/
    IapRead_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);

    if(FontBuffer_Read[0 + 10 * 0] == 0xaa && FontBuffer_Read[1 + 10 * 0] == 0x55) //���SOC	    0
    {
//        SOCinit = 1;
//        Cell_Soc = FontBuffer_Read[2 + 10 * 0];
        SOCinit = 0;
        Cell_Soc = 50; //Ĭ��50%
    }
    else
    {
        SOCinit = 0;
        Cell_Soc = 50; //Ĭ��50%
    }

    if(FontBuffer_Read[0 + 10 * 1] == 0xaa && FontBuffer_Read[1 + 10 * 1] == 0x55) //���ѭ������	1
        Cell_usnum = (FontBuffer_Read[2 + 10 * 1] << 8) | FontBuffer_Read[3 + 10 * 1];
    else
        Cell_usnum = 0;

    if(FontBuffer_Read[0 + 10 * 2] == 0xaa && FontBuffer_Read[1 + 10 * 2] == 0x55) //���ѭ���ŵ�������  2
    {
        Cell_Outrl = (u32)(((FontBuffer_Read[2 + 10 * 2] << 8) | FontBuffer_Read[3 + 10 * 2]) * 65536 + ((FontBuffer_Read[4 + 10 * 2] << 8) | FontBuffer_Read[5 + 10 * 2]));
        gps_data.Rev_data.CellOutrl = Cell_Outrl;
        SOH_Readflash = 100;

    }
    else
    {
        Cell_Outrl = 0;
        SOH_Readflash = 100;
    }


    if(FontBuffer_Read[0 + 10 * 3] == 0xaa && FontBuffer_Read[1 + 10 * 3] == 0x55) //���߹��ϴ���  3
        Off_lint = FontBuffer_Read[2 + 10 * 3];
    else
        Off_lint = 1;

    if(FontBuffer_Read[0 + 10 * 4] == 0xaa && FontBuffer_Read[1 + 10 * 4] == 0x55) //�ŵ�ʧЧ����  4
        Out_Dea = FontBuffer_Read[2 + 10 * 4];
    else
        Out_Dea = 1;

    if(FontBuffer_Read[0 + 10 * 5] == 0xaa && FontBuffer_Read[1 + 10 * 5] == 0x55) //���ʧЧ����  5
        Chg_Dea = FontBuffer_Read[2 + 10 * 5];
    else
        Chg_Dea = 1;

    if(FontBuffer_Read[0 + 10 * 6] == 0xaa && FontBuffer_Read[1 + 10 * 6] == 0x55) //��س��´���  6
        Cell_Tmp = FontBuffer_Read[2 + 10 * 6];
    else
        Cell_Tmp = 1;

    if(FontBuffer_Read[0 + 10 * 7] == 0xaa && FontBuffer_Read[1 + 10 * 7] == 0x55) //���ʰ峬�´��� 7
        Pow_Tmp = FontBuffer_Read[2 + 10 * 7];
    else
        Pow_Tmp = 1;

    if(FontBuffer_Read[0 + 10 * 8] == 0xaa && FontBuffer_Read[1 + 10 * 8] == 0x55) //���Mos�ܹ��ϴ��� 8
        Chg_Moshit = FontBuffer_Read[2 + 10 * 8];
    else
        Chg_Moshit = 1;

    if(FontBuffer_Read[0 + 10 * 9] == 0xaa && FontBuffer_Read[1 + 10 * 9] == 0x55) //�ŵ�MOs�ܹ��ϴ��� 9
        Out_Moshit = FontBuffer_Read[2 + 10 * 9];
    else
        Out_Moshit = 1;

    ///////////////////////////////////////////////////////////////////////////////////////////
    if(FontBuffer_Read[0 + 10 * 12] == 0xaa && FontBuffer_Read[1 + 10 * 12] == 0x55) //�����ѹ����ֵ 12
        gps_data.RevWrite_data.SingvolG = (FontBuffer_Read[2 + 10 * 12] << 8) | FontBuffer_Read[3 + 10 * 12];
    else
        gps_data.RevWrite_data.SingvolG = 4200;

    if(FontBuffer_Read[0 + 10 * 13] == 0xaa && FontBuffer_Read[1 + 10 * 13] == 0x55) //�����ѹ�ָ�ֵ 13
        gps_data.RevWrite_data.SingvolGH = (FontBuffer_Read[2 + 10 * 13] << 8) | FontBuffer_Read[3 + 10 * 13];
    else
        gps_data.RevWrite_data.SingvolGH = 4100;

    if(FontBuffer_Read[0 + 10 * 14] == 0xaa && FontBuffer_Read[1 + 10 * 14] == 0x55) //�����ѹ������ʱ 14
        gps_data.RevWrite_data.SingvolGtime = (FontBuffer_Read[2 + 10 * 14] << 8) | FontBuffer_Read[3 + 10 * 14];
    else
        gps_data.RevWrite_data.SingvolGtime = 4;

    if(FontBuffer_Read[0 + 10 * 15] == 0xaa && FontBuffer_Read[1 + 10 * 15] == 0x55) //����Ƿѹ����ֵ 15
        gps_data.RevWrite_data.SingvolQ = (FontBuffer_Read[2 + 10 * 15] << 8) | FontBuffer_Read[3 + 10 * 15];
    else
        gps_data.RevWrite_data.SingvolQ = 2800;

    if(FontBuffer_Read[0 + 10 * 16] == 0xaa && FontBuffer_Read[1 + 10 * 16] == 0x55) //����Ƿѹ�ָ�ֵ 16
        gps_data.RevWrite_data.SingvolQH = (FontBuffer_Read[2 + 10 * 16] << 8) | FontBuffer_Read[3 + 10 * 16];
    else
        gps_data.RevWrite_data.SingvolQH = 2900;

    if(FontBuffer_Read[0 + 10 * 17] == 0xaa && FontBuffer_Read[1 + 10 * 17] == 0x55) //����Ƿѹ������ʱ 17
        gps_data.RevWrite_data.SingvolQtime = (FontBuffer_Read[2 + 10 * 17] << 8) | FontBuffer_Read[3 + 10 * 17];
    else
        gps_data.RevWrite_data.SingvolQtime = 4;

    //20230824 ѹ��ſ�ʼ�洢
    if(FontBuffer_Read[0 + 10 * 18] == 0xaa && FontBuffer_Read[1 + 10 * 18] == 0x55) //��оѹ��� 18
        gps_data.RevWrite_data.CellXyc = (FontBuffer_Read[2 + 10 * 18] << 8) | FontBuffer_Read[3 + 10 * 18];
    else
        gps_data.RevWrite_data.CellXyc = 1000;

    if(FontBuffer_Read[0 + 10 * 19] == 0xaa && FontBuffer_Read[1 + 10 * 19] == 0x55) //�ŵ��������ֵ 19
        gps_data.RevWrite_data.OutcurrG = (FontBuffer_Read[2 + 10 * 19] << 8) | FontBuffer_Read[3 + 10 * 19];
    else
        gps_data.RevWrite_data.OutcurrG = 60;

    if(FontBuffer_Read[0 + 10 * 20] == 0xaa && FontBuffer_Read[1 + 10 * 20] == 0x55) //�ŵ����������ʱ 20
        gps_data.RevWrite_data.OutcurrGtime = (FontBuffer_Read[2 + 10 * 20] << 8) | FontBuffer_Read[3 + 10 * 20];
    else
        gps_data.RevWrite_data.OutcurrGtime = 60;

    if(FontBuffer_Read[0 + 10 * 21] == 0xaa && FontBuffer_Read[1 + 10 * 21] == 0x55) //����������ֵ 21
        gps_data.RevWrite_data.ChgcurrG = (FontBuffer_Read[2 + 10 * 21] << 8) | FontBuffer_Read[3 + 10 * 21];
    else
        gps_data.RevWrite_data.ChgcurrG = 20;

    if(FontBuffer_Read[0 + 10 * 22] == 0xaa && FontBuffer_Read[1 + 10 * 22] == 0x55) //��������ʱ 22
        gps_data.RevWrite_data.ChgcurrGtime = (FontBuffer_Read[2 + 10 * 22] << 8) | FontBuffer_Read[3 + 10 * 22];
    else
        gps_data.RevWrite_data.ChgcurrGtime = 64;

    if(FontBuffer_Read[0 + 10 * 23] == 0xaa && FontBuffer_Read[1 + 10 * 23] == 0x55) //����������ѹ 23
        gps_data.RevWrite_data.Equalivol = (FontBuffer_Read[2 + 10 * 23] << 8) | FontBuffer_Read[3 + 10 * 23];
    else
        gps_data.RevWrite_data.Equalivol = 4000;

    if(FontBuffer_Read[0 + 10 * 24] == 0xaa && FontBuffer_Read[1 + 10 * 24] == 0x55) //���⿪��ѹ�� 24
        gps_data.RevWrite_data.Equalivolcc = (FontBuffer_Read[2 + 10 * 24] << 8) | FontBuffer_Read[3 + 10 * 24];
    else
        gps_data.RevWrite_data.Equalivolcc = 10;

    if(FontBuffer_Read[0 + 10 * 25] == 0xaa && FontBuffer_Read[1 + 10 * 25] == 0x55) //���⿪�� 25
        gps_data.RevWrite_data.EqualiON = FontBuffer_Read[2 + 10 * 25];
    else
        gps_data.RevWrite_data.EqualiON = 1; //����Ĭ�Ͽ���

    if(FontBuffer_Read[0 + 10 * 26] == 0xaa && FontBuffer_Read[1 + 10 * 26] == 0x55) //���ʹ��¶ȱ���ֵ 26
        gps_data.RevWrite_data.PowTmp = (FontBuffer_Read[2 + 10 * 26] << 8) | FontBuffer_Read[3 + 10 * 26];
    else
        gps_data.RevWrite_data.PowTmp = 75;

    if(FontBuffer_Read[0 + 10 * 27] == 0xaa && FontBuffer_Read[1 + 10 * 27] == 0x55) //���ʹ��¶Ȼָ�ֵ 27
        gps_data.RevWrite_data.PowTmpH = (FontBuffer_Read[2 + 10 * 27] << 8) | FontBuffer_Read[3 + 10 * 27];
    else
        gps_data.RevWrite_data.PowTmpH = 60;

    if(FontBuffer_Read[0 + 10 * 28] == 0xaa && FontBuffer_Read[1 + 10 * 28] == 0x55) //��������¶ȱ���ֵ 28
        gps_data.RevWrite_data.Equaltmpb = (FontBuffer_Read[2 + 10 * 28] << 8) | FontBuffer_Read[3 + 10 * 28];
    else
        gps_data.RevWrite_data.Equaltmpb = 65;

    if(FontBuffer_Read[0 + 10 * 29] == 0xaa && FontBuffer_Read[1 + 10 * 29] == 0x55) //��������¶Ȼָ�ֵ 29
        gps_data.RevWrite_data.EqualtmpH = (FontBuffer_Read[2 + 10 * 29] << 8) | FontBuffer_Read[3 + 10 * 29];
    else
        gps_data.RevWrite_data.EqualtmpH = 55;

    if(FontBuffer_Read[0 + 10 * 30] == 0xaa && FontBuffer_Read[1 + 10 * 30] == 0x55) //����²��ֵ 30
        gps_data.RevWrite_data.CellTmp = (FontBuffer_Read[2 + 10 * 30] << 8) | FontBuffer_Read[3 + 10 * 30];
    else
        gps_data.RevWrite_data.CellTmp = 20;

    if(FontBuffer_Read[0 + 10 * 31] == 0xaa && FontBuffer_Read[1 + 10 * 31] == 0x55) //��س����±���ֵ 31
    {
        gps_data.RevWrite_data.CellChgTmpG = (FontBuffer_Read[2 + 10 * 31] << 8) | FontBuffer_Read[3 + 10 * 31];
        gps_data.RevWrite_data.CellChgTmpGH = gps_data.RevWrite_data.CellChgTmpG - 10;
    }
    else
    {
        gps_data.RevWrite_data.CellChgTmpG = 65;
        gps_data.RevWrite_data.CellChgTmpGH = gps_data.RevWrite_data.CellChgTmpG - 10;
    }

    if(FontBuffer_Read[0 + 10 * 32] == 0xaa && FontBuffer_Read[1 + 10 * 32] == 0x55) //��س����±���ֵ 32
    {
        gps_data.RevWrite_data.CellOutTmpG = (FontBuffer_Read[2 + 10 * 32] << 8) | FontBuffer_Read[3 + 10 * 32];
        gps_data.RevWrite_data.CellOutTmpGH = gps_data.RevWrite_data.CellOutTmpG - 10;
    }
    else
    {
        gps_data.RevWrite_data.CellOutTmpG = 65;
        gps_data.RevWrite_data.CellOutTmpGH = gps_data.RevWrite_data.CellOutTmpG - 10;
    }

//
    if(FontBuffer_Read[0 + 10 * 33] == 0xaa && FontBuffer_Read[1 + 10 * 33] == 0x55) //��ص��±���ֵ 33
        gps_data.RevWrite_data.ChgTmpD = (FontBuffer_Read[2 + 10 * 33] << 8) | FontBuffer_Read[3 + 10 * 33];
    else
        gps_data.RevWrite_data.ChgTmpD = -40;

    if(FontBuffer_Read[0 + 10 * 34] == 0xaa && FontBuffer_Read[1 + 10 * 34] == 0x55) //��ر����ָ�ֵ 34
        gps_data.RevWrite_data.ChgTmpDH = (FontBuffer_Read[2 + 10 * 34] << 8) | FontBuffer_Read[3 + 10 * 34];
    else
        gps_data.RevWrite_data.ChgTmpDH = -35;

    if(FontBuffer_Read[0 + 10 * 35] == 0xaa && FontBuffer_Read[1 + 10 * 35] == 0x55) //�ŵ���±���ֵ 35
        gps_data.RevWrite_data.OutTmpD = (FontBuffer_Read[2 + 10 * 35] << 8) | FontBuffer_Read[3 + 10 * 35];
    else
        gps_data.RevWrite_data.OutTmpD = -40;

    if(FontBuffer_Read[0 + 10 * 36] == 0xaa && FontBuffer_Read[1 + 10 * 36] == 0x55) //�ŵ���±����ָ�ֵ 36
        gps_data.RevWrite_data.OutTmpDH = (FontBuffer_Read[2 + 10 * 36] << 8) | FontBuffer_Read[3 + 10 * 36];
    else
        gps_data.RevWrite_data.OutTmpDH = -35;

    if(FontBuffer_Read[0 + 10 * 37] == 0xaa && FontBuffer_Read[1 + 10 * 37] == 0x55) //��ش������� 37
        gps_data.RevWrite_data.Cellnum = FontBuffer_Read[2 + 10 * 37];
    else
        gps_data.RevWrite_data.Cellnum = 16; //Ĭ�ϴ���-----

    /*���ݵ�о������ȡ�ܵ�ѹ����ֵ*/
    if(FontBuffer_Read[0 + 10 * 10] == 0xaa && FontBuffer_Read[1 + 10 * 10] == 0x55) //�ܵ�ѹ��ѹ����ֵ 10
        gps_data.RevWrite_data.ZvolG = ((FontBuffer_Read[2 + 10 * 10] << 8) | FontBuffer_Read[3 + 10 * 10]);
    else
        gps_data.RevWrite_data.ZvolG = gps_data.RevWrite_data.SingvolG / 10.0 * gps_data.RevWrite_data.Cellnum;

    if(FontBuffer_Read[0 + 10 * 11] == 0xaa && FontBuffer_Read[1 + 10 * 11] == 0x55) //�ܵ�ѹǷѹ����ֵ 11
        gps_data.RevWrite_data.ZvolQ = ((FontBuffer_Read[2 + 10 * 11] << 8) | FontBuffer_Read[3 + 10 * 11]);
    else
        gps_data.RevWrite_data.ZvolQ = gps_data.RevWrite_data.SingvolQ / 10.0 * gps_data.RevWrite_data.Cellnum;

    //////////////////////////////////////////////////////////////////////////////////////////////////////////

    if(FontBuffer_Read[0 + 10 * 38] == 0xaa && FontBuffer_Read[1 + 10 * 38] == 0x55) //����������� 38
        gps_data.RevWrite_data.CellRl = (u32)(((FontBuffer_Read[2 + 10 * 38] << 8) | (FontBuffer_Read[3 + 10 * 38])) * 65536 + ((FontBuffer_Read[4 + 10 * 38] << 8) | FontBuffer_Read[5 + 10 * 38]));
    else
        gps_data.RevWrite_data.CellRl = 40; /////////////////////////////////////////////////Ĭ��40AH

    if(FontBuffer_Read[0 + 10 * 39] == 0xaa && FontBuffer_Read[1 + 10 * 39] == 0x55) //���MOS�ܿ��� 39
        Chg_Lock = FontBuffer_Read[2 + 10 * 39];
    else
        Chg_Lock = 0;

    if(Chg_Lock == 0)
        gps_data.RevWrite_data.ChgMOS = 1;
    else
        gps_data.RevWrite_data.ChgMOS = 0;

    if(FontBuffer_Read[0 + 10 * 40] == 0xaa && FontBuffer_Read[1 + 10 * 40] == 0x55) //�ŵ�MOS�ܿ��� 40
        Out_Lock = FontBuffer_Read[2 + 10 * 40];
    else
        Out_Lock = 0;

    if(Out_Lock == 0)
        gps_data.RevWrite_data.OutMOS = 1;
    else
        gps_data.RevWrite_data.OutMOS = 0;

    if(FontBuffer_Read[0 + 10 * 41] == 0xaa && FontBuffer_Read[1 + 10 * 41] == 0x55) //����У׼���� ��׼ 41
        gps_data.RevWrite_data.CurrJZ = (FontBuffer_Read[2 + 10 * 41] << 8) | FontBuffer_Read[3 + 10 * 41];
    else
        gps_data.RevWrite_data.CurrJZ = 10000; //mA

    if(FontBuffer_Read[0 + 10 * 42] == 0xaa && FontBuffer_Read[1 + 10 * 42] == 0x55) //�������ַ 42
        gps_data.RevWrite_data.BHBAddr = FontBuffer_Read[2 + 10 * 42];
    else
        gps_data.RevWrite_data.BHBAddr = 1;

    if(FontBuffer_Read[0 + 10 * 43] == 0xaa && FontBuffer_Read[1 + 10 * 43] == 0x55) //������� 43
    {
        gps_data.RevWrite_data.Celltype = FontBuffer_Read[2 + 10 * 43];
    }
    else
    {
        gps_data.RevWrite_data.Celltype = 1;	//Ĭ����Ԫ
    }

    if(FontBuffer_Read[0 + 10 * 44] == 0xaa && FontBuffer_Read[1 + 10 * 44] == 0x55) //���ߵȴ�ʱ�� 44
        gps_data.RevWrite_data.SleepTime = (FontBuffer_Read[2 + 10 * 44] << 8) | FontBuffer_Read[3 + 10 * 44];
    else
        gps_data.RevWrite_data.SleepTime = 15;

    if(FontBuffer_Read[0 + 10 * 45] == 0xaa && FontBuffer_Read[1 + 10 * 45] == 0x55) //����������ֵ 45
        gps_data.RevWrite_data.DRLNum = FontBuffer_Read[2 + 10 * 45];
    else
        gps_data.RevWrite_data.DRLNum = 10;	    //20%

    if(FontBuffer_Read[0 + 10 * 46] == 0xaa && FontBuffer_Read[1 + 10 * 46] == 0x55) //�޸Ĳ������� 46
        memcpy(gps_data.RevWrite_data.Pass, &FontBuffer_Read[2 + 10 * 46], 8);
    else
        memset(gps_data.RevWrite_data.Pass, 0, 8);

    //ר�ó�������أ�Ĭ�Ϲر�
    if(FontBuffer_Read[0 + 10 * 47] == 0xaa && FontBuffer_Read[1 + 10 * 47] == 0x55) //ר�ó�������� 47
    {
        gps_data.RevWrite_data.ZChgON = FontBuffer_Read[2 + 10 * 47];

        if(gps_data.RevWrite_data.ZChgON >= 1)
            SpecChargerFlag = 1;//ר�ó����
        else
        {
            SpecChargerFlag = 0;//ר�ó����
        }

    }
    else
    {
        gps_data.RevWrite_data.ZChgON = 0;
    }

    if(FontBuffer_Read[0 + 10 * 48] == 0xaa && FontBuffer_Read[1 + 10 * 48] == 0x55) //�豸ID 48
    {
        memcpy(gps_data.RevWrite_data.EquID, &FontBuffer_Read[2 + 10 * 48], 8);
    }
    else
    {
        //YT603200400001
        memcpy(gps_data.RevWrite_data.EquID, &databuf[2], 3);			 //603
        memcpy(&gps_data.RevWrite_data.EquID[3], &databuf[9], 5);			 //00001
    }

    if(FontBuffer_Read[0 + 10 * 49] == 0xaa && FontBuffer_Read[1 + 10 * 49] == 0x55) //�������� 49
    {
        memcpy(gps_data.RevWrite_data.CCDat, &FontBuffer_Read[2 + 10 * 49], 4);
    }
    else
        memcpy(gps_data.RevWrite_data.CCDat, &databuf[5], 4);			 //2004

    if(FontBuffer_Read[0 + 10 * 50] == 0xaa && FontBuffer_Read[1 + 10 * 50] == 0x55) //ϵͳ����ʱ�� �� 50
        gps_data.RevWrite_data.SysTime = (u32)(((FontBuffer_Read[2 + 10 * 50] << 8) | (FontBuffer_Read[3 + 10 * 50])) * 65536 + ((FontBuffer_Read[4 + 10 * 50] << 8) | FontBuffer_Read[5 + 10 * 50]));
    else
        gps_data.RevWrite_data.SysTime = 0;

    if(FontBuffer_Read[0 + 10 * 51] == 0xaa && FontBuffer_Read[1 + 10 * 51] == 0x55) //���������׼ֵ
    {
        long fl_data = 0;
        fl_data = (u32)(((FontBuffer_Read[2 + 10 * 51] << 8) | (FontBuffer_Read[3 + 10 * 51])) * 65536 + ((FontBuffer_Read[4 + 10 * 51] << 8) | FontBuffer_Read[5 + 10 * 51]));
        Curr_Res = *((float *)&fl_data); //ת��������
    }
    else
        Curr_Res = 0.001035;

    if(FontBuffer_Read[0 + 10 * 52] == 0xaa && FontBuffer_Read[1 + 10 * 52] == 0x55) //���ʵ������
        gps_data.RevWrite_data.Reali_Q = (u32)(((FontBuffer_Read[2 + 10 * 52] << 8) | (FontBuffer_Read[3 + 10 * 52])) * 65536 + ((FontBuffer_Read[4 + 10 * 52] << 8) | FontBuffer_Read[5 + 10 * 52]));
    else
        gps_data.RevWrite_data.Reali_Q = gps_data.RevWrite_data.CellRl; //��ʼ��1:1

    /*����ʵ������Լ��*/
    if(gps_data.RevWrite_data.Reali_Q > gps_data.RevWrite_data.CellRl)
        gps_data.RevWrite_data.Reali_Q = gps_data.RevWrite_data.CellRl;

    //////////////////////////////////////////////////////////////////////////////////////////////
    /***************************�µ�ID������������******************************/
    /////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////////
    if(FontBuffer_Read[0 + 10 * 53] == 0xaa && FontBuffer_Read[1 + 10 * 53] == 0x55) //�������� 53
    {
        //memcpy(&gps_data.RevWrite_data.XID[0], &dataxingaobuf[0], 2);//BT�����޸�
        memcpy(&gps_data.RevWrite_data.XID[0], &FontBuffer_Read[2 + 10 * 53], 8);
    }
    else
        memcpy(&gps_data.RevWrite_data.XID[0], &dataxingaobuf[0], 9);

    //////////////////////////////////////////////////////////////////////////////////////////////
    if(FontBuffer_Read[0 + 10 * 54] == 0xaa && FontBuffer_Read[1 + 10 * 54] == 0x55) //�������� 54
    {
        memcpy(&gps_data.RevWrite_data.XID[8], &FontBuffer_Read[2 + 10 * 54], 7);
    }
    else
        memcpy(&gps_data.RevWrite_data.XID[9], &dataxingaobuf[9], 6);

    //////////////////////////////////////////////////////////////////////////////////////////////
    if(FontBuffer_Read[0 + 10 * 55] == 0xaa && FontBuffer_Read[1 + 10 * 55] == 0x55) //�������� 55
    {
        memcpy(&gps_data.RevWrite_data.XID[15], &FontBuffer_Read[2 + 10 * 55], 6);
    }
    else
        memcpy(&gps_data.RevWrite_data.XID[15], &dataxingaobuf[15], 6);

    //////////////////////////////////////////////////////////////////////////////////////////////
    if(FontBuffer_Read[0 + 10 * 56] == 0xaa && FontBuffer_Read[1 + 10 * 56] == 0x55) //�������� 56
    {
        memcpy(&gps_data.RevWrite_data.XID[21], &FontBuffer_Read[2 + 10 * 56], 3);
    }
    else
        memcpy(&gps_data.RevWrite_data.XID[21], &dataxingaobuf[21], 3);

    //////////////////////////////////////////////////////////////////////////////////////////////
    if(FontBuffer_Read[0 + 10 * 57] == 0xaa && FontBuffer_Read[1 + 10 * 57] == 0x55) //�����豸ID
    {
        //memcpy(&broad_name[4],&FontBuffer_Read[2+10*57],5);
    }

    if(FontBuffer_Read[0 + 10 * 58] == 0xaa && FontBuffer_Read[1 + 10 * 58] == 0x55) //��������ID
    {
        memcpy(&Pass_init[0], &FontBuffer_Read[2 + 10 * 58], 6);
    }

    //////////////////////////////////////////////////////////////////////////////////////////
    if(FontBuffer_Read[0 + 10 * 59] == 0xaa && FontBuffer_Read[1 + 10 * 59] == 0x55) //��о�͵�ѹ�ر�GPS   59
    {
        gps_data.RevWrite_data.GpsDVol = ((FontBuffer_Read[2 + 10 * 59] << 8) | FontBuffer_Read[3 + 10 * 59]); //��λ��MV
    }
    else
    {
        if(gps_data.RevWrite_data.Celltype == 0)
            gps_data.RevWrite_data.GpsDVol = 2750;
        else if(gps_data.RevWrite_data.Celltype == 1)
            gps_data.RevWrite_data.GpsDVol = 2750;
        else if(gps_data.RevWrite_data.Celltype == 2)
            gps_data.RevWrite_data.GpsDVol = 2750;
    }

    if(FontBuffer_Read[0 + 10 * 60] == 0xaa && FontBuffer_Read[1 + 10 * 60] == 0x55) //��о��ѹ�ָ�GPS   60
    {
        gps_data.RevWrite_data.GpsDVolH = ((FontBuffer_Read[2 + 10 * 60] << 8) | FontBuffer_Read[3 + 10 * 60]); //��λ��MV
    }
    else
    {
        if(gps_data.RevWrite_data.Celltype == 0)
            gps_data.RevWrite_data.GpsDVolH = 2850;
        else if(gps_data.RevWrite_data.Celltype == 1)
            gps_data.RevWrite_data.GpsDVolH = 2850;
        else if(gps_data.RevWrite_data.Celltype == 2)
            gps_data.RevWrite_data.GpsDVolH = 2850;
    }

    if(FontBuffer_Read[0 + 10 * 61] == 0xaa && FontBuffer_Read[1 + 10 * 61] == 0x55) //ʪ�ȿ���   61
    {
        gps_data.RevWrite_data.ShiduKaiguan = FontBuffer_Read[2 + 10 * 61];
    }
    else
    {
        gps_data.RevWrite_data.ShiduKaiguan = 0;
    }

    if(FontBuffer_Read[0 + 10 * 62] == 0xaa && FontBuffer_Read[1 + 10 * 62] == 0x55) //��ǰʪ����ֵ   62
    {
        gps_data.RevWrite_data.ShiduValueNow = FontBuffer_Read[2 + 10 * 62];
    }

    if(FontBuffer_Read[0 + 10 * 63] == 0xaa && FontBuffer_Read[1 + 10 * 63] == 0x55) //ʪ�ȱ���ֵ   63
    {
        gps_data.RevWrite_data.ShiduValueProtect = FontBuffer_Read[2 + 10 * 63];
    }
    else
    {
        gps_data.RevWrite_data.ShiduValueProtect = 90;
    }

    if(FontBuffer_Read[0 + 10 * 64] == 0xaa && FontBuffer_Read[1 + 10 * 64] == 0x55) //��·����   64
    {
        gps_data.RevWrite_data.ShortCurValue = FontBuffer_Read[2 + 10 * 64];
    }
    else
    {
        gps_data.RevWrite_data.ShortCurValue = 38;
    }

    if(FontBuffer_Read[0 + 10 * 65] == 0xaa && FontBuffer_Read[1 + 10 * 65] == 0x55) //��·��ʱ   65
    {
        gps_data.RevWrite_data.ShortCurDelay = ((FontBuffer_Read[2 + 10 * 65] << 8) | FontBuffer_Read[3 + 10 * 65]);
    }
    else
    {
        gps_data.RevWrite_data.ShortCurDelay = 400;
    }

    if(FontBuffer_Read[0 + 10 * 66] == 0xaa && FontBuffer_Read[1 + 10 * 66] == 0x55) //ʹ�ܿ���   66
    {
        gps_data.RevWrite_data.EnableSwitch = ((FontBuffer_Read[2 + 10 * 66] << 8) | FontBuffer_Read[3 + 10 * 66]);
    }
    else
    {
        gps_data.RevWrite_data.EnableSwitch = 0x0002;//Ĭ���¶ȹر�
    }

    if(FontBuffer_Read[0 + 10 * 67] == 0xaa && FontBuffer_Read[1 + 10 * 67] == 0x55) //�������ű�������
    {
        gps_data.RevWrite_data.CellOUT2CURR_G = ((FontBuffer_Read[2 + 10 * 67] << 8) | FontBuffer_Read[3 + 10 * 67]);
    }
    else
    {
        gps_data.RevWrite_data.CellOUT2CURR_G = 80;
    }

    if(FontBuffer_Read[0 + 10 * 68] == 0xaa && FontBuffer_Read[1 + 10 * 68] == 0x55) //��������������ʱ
    {
        gps_data.RevWrite_data.CellOUT2TIME_G = ((FontBuffer_Read[2 + 10 * 68] << 8) | FontBuffer_Read[3 + 10 * 68]);
    }
    else
    {
        gps_data.RevWrite_data.CellOUT2TIME_G = 4;
    }

    if(FontBuffer_Read[0 + 10 * 69] == 0xaa && FontBuffer_Read[1 + 10 * 69] == 0x55) //������У׼��ѹ
    {
        gps_data.RevWrite_data.CellDRLBEEP_Jiao = ((FontBuffer_Read[2 + 10 * 69] << 8) | FontBuffer_Read[3 + 10 * 69]);
    }
    else
    {
        gps_data.RevWrite_data.CellDRLBEEP_Jiao = 3350;
    }


    IntVolume = Cell_Soc / 100.0 * gps_data.RevWrite_data.CellRl;

    /*ʵ�������ͱ�����������*/
    Q_hs = (gps_data.RevWrite_data.CellRl * 1.0) / (gps_data.RevWrite_data.Reali_Q * 1.0);

    /*���ݵ������ ��ŵ�����ȷ����ŵ籶��*/
    if(gps_data.RevWrite_data.Celltype == 0)
    {
        OutSOC_xs = 1.08;
        ChgSOC_xs = 1.08;
    }
    else if(gps_data.RevWrite_data.Celltype == 1)
    {
        OutSOC_xs = 1.08;
        ChgSOC_xs = 1.08;
    }
    else if(gps_data.RevWrite_data.Celltype == 2)
    {
        OutSOC_xs = 1.08;
        ChgSOC_xs = 1.08;
    }

    //////////////////////////////////////////////////////////////
    if(Chg_Lock == 0)
    {
        ChgMos_bit = 0;

        Free309CHGMos();
    }
    else
    {
        ChgMos_bit = 1;

        Shut309CHGMos();
    }

    if(Out_Lock == 0)
    {
        OutMos_bit = 0;

        Free309DSGMos();
    }
    else
    {
        OutMos_bit = 1;

        Shut309DSGMos();
    }


}

/*
*��������flash_write_sys_flag
*����������	write_unm ����
*��������ֵ��wu
*�������ܣ�дFLASH��Ϣ
*/

void  flash_write_sys_flag(unsigned char write_unm)
{
    IapRead_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);

    switch(write_unm)
    {
        case 0://SOC
            //FontBuffer_Read[2 + 10 * write_unm] = (unsigned char)Cell_Soc;
            break;

        case 1:
            FontBuffer_Read[2 + 10 * write_unm] = (unsigned char)(Cell_usnum >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (unsigned char)Cell_usnum;
            break;

        case 2://ѭ���ŵ���
            FontBuffer_Read[2 + 10 * write_unm] = (unsigned char)(gps_data.Rev_data.CellOutrl >> 24);
            FontBuffer_Read[3 + 10 * write_unm] = (unsigned char)(gps_data.Rev_data.CellOutrl >> 16);
            FontBuffer_Read[4 + 10 * write_unm] = (unsigned char)(gps_data.Rev_data.CellOutrl >> 8);
            FontBuffer_Read[5 + 10 * write_unm] = (unsigned char)gps_data.Rev_data.CellOutrl;
            break;

        case 3:
            FontBuffer_Read[2 + 10 * write_unm] = (unsigned char)Off_lint;
            break;

        case 4:
            FontBuffer_Read[2 + 10 * write_unm] = (unsigned char)Out_Dea;
            break;

        case 5:
            FontBuffer_Read[2 + 10 * write_unm] = (unsigned char)Chg_Dea;
            break;

        case 6:
            FontBuffer_Read[2 + 10 * write_unm] = (unsigned char)Cell_Tmp;
            break;

        case 7:
            FontBuffer_Read[2 + 10 * write_unm] = (unsigned char)Pow_Tmp;
            break;

        case 8:
            FontBuffer_Read[2 + 10 * write_unm] = (unsigned char)Chg_Moshit;
            break;

        case 9:
            FontBuffer_Read[2 + 10 * write_unm] = (unsigned char)Out_Moshit;
            break;

        case 10:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.ZvolG  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8) gps_data.RevWrite_data.ZvolG;
            break;

        case 11:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.ZvolQ  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ZvolQ;
            break;

        case 12:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.SingvolG  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.SingvolG;
            break;

        case 13:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.SingvolGH  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.SingvolGH;
            break;

        case 14:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.SingvolGtime  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.SingvolGtime;
            break;

        case 15:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.SingvolQ  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.SingvolQ;
            break;

        case 16:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.SingvolQH  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.SingvolQH;
            break;

        case 17:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.SingvolQtime  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.SingvolQtime;
            break;

        case 18:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CellXyc  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.CellXyc;
            break;

        case 19:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.OutcurrG  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.OutcurrG;
            break;

        case 20:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.OutcurrGtime  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.OutcurrGtime;
            break;

        case 21:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.ChgcurrG  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ChgcurrG;
            break;

        case 22:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.ChgcurrGtime  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ChgcurrGtime;
            break;

        case 23:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.Equalivol  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.Equalivol;
            break;

        case 24:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.Equalivolcc  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.Equalivolcc;
            break;

        case 25:
            FontBuffer_Read[2 + 10 * write_unm] = gps_data.RevWrite_data.EqualiON;
            break;

        case 26:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.PowTmp  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.PowTmp;
            break;

        case 27:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.PowTmpH  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.PowTmpH;
            break;

        case 28:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.Equaltmpb  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.Equaltmpb;
            break;

        case 29:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.EqualtmpH  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.EqualtmpH;
            break;

        case 30:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CellTmp  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.CellTmp;
            break;

        case 31:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CellChgTmpG  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.CellChgTmpG;
            break;

        case 32:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CellOutTmpG  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.CellOutTmpG;
            break;

        case 33:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.ChgTmpD  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ChgTmpD;
            break;

        case 34:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.ChgTmpDH  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ChgTmpDH;
            break;

        case 35:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.OutTmpD  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.OutTmpD;
            break;

        case 36:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.OutTmpDH  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.OutTmpDH;
            break;

        case 37:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)gps_data.RevWrite_data.Cellnum;
            break;

        case 38:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CellRl  >> 24);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CellRl  >> 16);
            FontBuffer_Read[4 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CellRl  >> 8);
            FontBuffer_Read[5 + 10 * write_unm] = (u8) gps_data.RevWrite_data.CellRl;
            break;

        case 39:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)Chg_Lock;
            break;

        case 40:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)Out_Lock;
            break;

        case 41:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CurrJZ  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.CurrJZ;
            break;

        case 42:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)gps_data.RevWrite_data.BHBAddr;
            break;

        case 43:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)gps_data.RevWrite_data.Celltype;
            break;

        case 44:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.SleepTime  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.SleepTime;
            break;

        case 45:
            FontBuffer_Read[2 + 10 * write_unm] = gps_data.RevWrite_data.DRLNum;
            break;

        case 46:
            memcpy(&FontBuffer_Read[2 + 10 * write_unm], gps_data.RevWrite_data.Pass, 8);
            break;

        case 47:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ZChgON;
            break;

        case 48:
            memcpy(&FontBuffer_Read[2 + 10 * write_unm], gps_data.RevWrite_data.EquID, 8);
            break;

        case 49:
            FontBuffer_Read[2 + 10 * write_unm] = gps_data.RevWrite_data.CCDat[0];
            FontBuffer_Read[3 + 10 * write_unm] = gps_data.RevWrite_data.CCDat[1];
            FontBuffer_Read[4 + 10 * write_unm] = gps_data.RevWrite_data.CCDat[2];
            FontBuffer_Read[5 + 10 * write_unm] = gps_data.RevWrite_data.CCDat[3];
            break;

        case 50://ϵͳʱ��
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.SysTime  >> 24);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.SysTime  >> 16);
            FontBuffer_Read[4 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.SysTime  >> 8);
            FontBuffer_Read[5 + 10 * write_unm] = (u8) gps_data.RevWrite_data.SysTime;
            break;

        case 51:				//���������׼����
        {
            unsigned int int_data = 0;
            int_data = *((unsigned int *)&Curr_Res);

            FontBuffer_Read[2 + 10 * write_unm] = (u8)(int_data  >> 24);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)(int_data  >> 16);
            FontBuffer_Read[4 + 10 * write_unm] = (u8)(int_data  >> 8);
            FontBuffer_Read[5 + 10 * write_unm] = (u8) int_data;
        }
        break;

        case 52:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.Reali_Q  >> 24);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.Reali_Q  >> 16);
            FontBuffer_Read[4 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.Reali_Q  >> 8);
            FontBuffer_Read[5 + 10 * write_unm] = (u8) gps_data.RevWrite_data.Reali_Q;
            break;

        case 53: //�µ�ID�洢
            FontBuffer_Read[2 + 10 * write_unm] = gps_data.RevWrite_data.XID[0]; //'B'
            FontBuffer_Read[3 + 10 * write_unm] = gps_data.RevWrite_data.XID[1]; //'T'
            FontBuffer_Read[4 + 10 * write_unm] = gps_data.RevWrite_data.XID[2]; //'3'
            FontBuffer_Read[5 + 10 * write_unm] = gps_data.RevWrite_data.XID[3]; //'0'
            FontBuffer_Read[6 + 10 * write_unm] = gps_data.RevWrite_data.XID[4]; //'7'
            FontBuffer_Read[7 + 10 * write_unm] = gps_data.RevWrite_data.XID[5]; //'2'
            FontBuffer_Read[8 + 10 * write_unm] = gps_data.RevWrite_data.XID[6]; //'0'
            FontBuffer_Read[9 + 10 * write_unm] = gps_data.RevWrite_data.XID[7]; //'2'

            break;

        case 54://�µ�ID�洢
            FontBuffer_Read[2 + 10 * write_unm] = gps_data.RevWrite_data.XID[8]; //'0'
            FontBuffer_Read[3 + 10 * write_unm] = gps_data.RevWrite_data.XID[9]; //'1'
            FontBuffer_Read[4 + 10 * write_unm] = gps_data.RevWrite_data.XID[10]; //'2'
            FontBuffer_Read[5 + 10 * write_unm] = gps_data.RevWrite_data.XID[11]; //'0'
            FontBuffer_Read[6 + 10 * write_unm] = gps_data.RevWrite_data.XID[12]; //'0'
            FontBuffer_Read[7 + 10 * write_unm] = gps_data.RevWrite_data.XID[13]; //'0'
            FontBuffer_Read[8 + 10 * write_unm] = gps_data.RevWrite_data.XID[14]; //'0'
            break;

        case 55://�µ�ID�洢
            FontBuffer_Read[2 + 10 * write_unm] = gps_data.RevWrite_data.XID[15]; //'2'
            FontBuffer_Read[3 + 10 * write_unm] = gps_data.RevWrite_data.XID[16]; //'0'
            FontBuffer_Read[4 + 10 * write_unm] = gps_data.RevWrite_data.XID[17]; //'0'
            FontBuffer_Read[5 + 10 * write_unm] = gps_data.RevWrite_data.XID[18]; //'5'
            FontBuffer_Read[6 + 10 * write_unm] = gps_data.RevWrite_data.XID[19]; //'2'
            FontBuffer_Read[7 + 10 * write_unm] = gps_data.RevWrite_data.XID[20]; //'1'
            break;

        case 56:
            FontBuffer_Read[2 + 10 * write_unm] = gps_data.RevWrite_data.XID[21]; //'0'
            FontBuffer_Read[3 + 10 * write_unm] = gps_data.RevWrite_data.XID[22]; //'0'
            FontBuffer_Read[4 + 10 * write_unm] = gps_data.RevWrite_data.XID[23]; //'1'
            break;

        case 57:
            //memcpy(&FontBuffer_Read[2+10*write_unm],&broad_name[4],5);  //"00001"
            break;

        case 58:
            memcpy(&FontBuffer_Read[2 + 10 * write_unm], &Pass_init[0], 6); //"123456"
            break;

        case 59:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.GpsDVol  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.GpsDVol;
            break;

        case 60:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.GpsDVolH  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.GpsDVolH;
            break;

        case 61:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ShiduKaiguan;
            break;

        case 62:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ShiduValueNow;
            break;

        case 63:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ShiduValueProtect;
            break;

        case 64:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ShortCurValue;
            break;

        case 65:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.ShortCurDelay  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.ShortCurDelay;
            break;

        case 66:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.EnableSwitch  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.EnableSwitch;
            break;

        case 67:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CellOUT2CURR_G  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.CellOUT2CURR_G;
            break;


        case 68:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CellOUT2TIME_G  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.CellOUT2TIME_G;
            break;

        case 69:
            FontBuffer_Read[2 + 10 * write_unm] = (u8)(gps_data.RevWrite_data.CellDRLBEEP_Jiao  >> 8);
            FontBuffer_Read[3 + 10 * write_unm] = (u8)gps_data.RevWrite_data.CellDRLBEEP_Jiao;
            break;



        default:
            break;
    }

    FontBuffer_Read[0 + 10 * write_unm] = 0xaa;
    FontBuffer_Read[1 + 10 * write_unm] = 0x55;

    /*��ʼдFLASH����*/
    IapProgram_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);
}


/*
*��������flash_write_sys_flag
*����������	wu
*��������ֵ��wu
*�������ܣ���λ��дFLASH��Ϣ
*/

void  flash_write_sys_flag_ALL(void)
{
    IapRead_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);

    FontBuffer_Read[0 + 10 * 10] = 0xaa;
    FontBuffer_Read[1 + 10 * 10] = 0x55;
    FontBuffer_Read[2 + 10 * 10] = (u8)(gps_data.RevWrite_data.ZvolG  >> 8);
    FontBuffer_Read[3 + 10 * 10] = (u8) gps_data.RevWrite_data.ZvolG;

    FontBuffer_Read[0 + 10 * 11] = 0xaa;
    FontBuffer_Read[1 + 10 * 11] = 0x55;
    FontBuffer_Read[2 + 10 * 11] = (u8)(gps_data.RevWrite_data.ZvolQ  >> 8);
    FontBuffer_Read[3 + 10 * 11] = (u8)gps_data.RevWrite_data.ZvolQ;

    FontBuffer_Read[0 + 10 * 12] = 0xaa;
    FontBuffer_Read[1 + 10 * 12] = 0x55;
    FontBuffer_Read[2 + 10 * 12] = (u8)(gps_data.RevWrite_data.SingvolG  >> 8);
    FontBuffer_Read[3 + 10 * 12] = (u8)gps_data.RevWrite_data.SingvolG;

    FontBuffer_Read[0 + 10 * 13] = 0xaa;
    FontBuffer_Read[1 + 10 * 13] = 0x55;
    FontBuffer_Read[2 + 10 * 13] = (u8)(gps_data.RevWrite_data.SingvolGH  >> 8);
    FontBuffer_Read[3 + 10 * 13] = (u8)gps_data.RevWrite_data.SingvolGH;

    FontBuffer_Read[0 + 10 * 14] = 0xaa;
    FontBuffer_Read[1 + 10 * 14] = 0x55;
    FontBuffer_Read[2 + 10 * 14] = (u8)(gps_data.RevWrite_data.SingvolGtime  >> 8);
    FontBuffer_Read[3 + 10 * 14] = (u8)gps_data.RevWrite_data.SingvolGtime;

    FontBuffer_Read[0 + 10 * 15] = 0xaa;
    FontBuffer_Read[1 + 10 * 15] = 0x55;
    FontBuffer_Read[2 + 10 * 15] = (u8)(gps_data.RevWrite_data.SingvolQ  >> 8);
    FontBuffer_Read[3 + 10 * 15] = (u8)gps_data.RevWrite_data.SingvolQ;

    FontBuffer_Read[0 + 10 * 16] = 0xaa;
    FontBuffer_Read[1 + 10 * 16] = 0x55;
    FontBuffer_Read[2 + 10 * 16] = (u8)(gps_data.RevWrite_data.SingvolQH  >> 8);
    FontBuffer_Read[3 + 10 * 16] = (u8)gps_data.RevWrite_data.SingvolQH;

    FontBuffer_Read[0 + 10 * 17] = 0xaa;
    FontBuffer_Read[1 + 10 * 17] = 0x55;
    FontBuffer_Read[2 + 10 * 17] = (u8)(gps_data.RevWrite_data.SingvolQtime  >> 8);
    FontBuffer_Read[3 + 10 * 17] = (u8)gps_data.RevWrite_data.SingvolQtime;

    FontBuffer_Read[0 + 10 * 18] = 0xaa;
    FontBuffer_Read[1 + 10 * 18] = 0x55;
    FontBuffer_Read[2 + 10 * 18] = (u8)(gps_data.RevWrite_data.CellXyc  >> 8);
    FontBuffer_Read[3 + 10 * 18] = (u8)gps_data.RevWrite_data.CellXyc;

    FontBuffer_Read[0 + 10 * 19] = 0xaa;
    FontBuffer_Read[1 + 10 * 19] = 0x55;
    FontBuffer_Read[2 + 10 * 19] = (u8)(gps_data.RevWrite_data.OutcurrG  >> 8);
    FontBuffer_Read[3 + 10 * 19] = (u8)gps_data.RevWrite_data.OutcurrG;

    FontBuffer_Read[0 + 10 * 20] = 0xaa;
    FontBuffer_Read[1 + 10 * 20] = 0x55;
    FontBuffer_Read[2 + 10 * 20] = (u8)(gps_data.RevWrite_data.OutcurrGtime  >> 8);
    FontBuffer_Read[3 + 10 * 20] = (u8)gps_data.RevWrite_data.OutcurrGtime;

    FontBuffer_Read[0 + 10 * 21] = 0xaa;
    FontBuffer_Read[1 + 10 * 21] = 0x55;
    FontBuffer_Read[2 + 10 * 21] = (u8)(gps_data.RevWrite_data.ChgcurrG  >> 8);
    FontBuffer_Read[3 + 10 * 21] = (u8)gps_data.RevWrite_data.ChgcurrG;

    FontBuffer_Read[0 + 10 * 22] = 0xaa;
    FontBuffer_Read[1 + 10 * 22] = 0x55;
    FontBuffer_Read[2 + 10 * 22] = (u8)(gps_data.RevWrite_data.ChgcurrGtime  >> 8);
    FontBuffer_Read[3 + 10 * 22] = (u8)gps_data.RevWrite_data.ChgcurrGtime;

    FontBuffer_Read[0 + 10 * 23] = 0xaa;
    FontBuffer_Read[1 + 10 * 23] = 0x55;
    FontBuffer_Read[2 + 10 * 23] = (u8)(gps_data.RevWrite_data.Equalivol  >> 8);
    FontBuffer_Read[3 + 10 * 23] = (u8)gps_data.RevWrite_data.Equalivol;

    FontBuffer_Read[0 + 10 * 24] = 0xaa;
    FontBuffer_Read[1 + 10 * 24] = 0x55;
    FontBuffer_Read[2 + 10 * 24] = (u8)(gps_data.RevWrite_data.Equalivolcc  >> 8);
    FontBuffer_Read[3 + 10 * 24] = (u8)gps_data.RevWrite_data.Equalivolcc;

    FontBuffer_Read[0 + 10 * 25] = 0xaa;
    FontBuffer_Read[1 + 10 * 25] = 0x55;
    FontBuffer_Read[2 + 10 * 25] = gps_data.RevWrite_data.EqualiON;

    FontBuffer_Read[0 + 10 * 26] = 0xaa;
    FontBuffer_Read[1 + 10 * 26] = 0x55;
    FontBuffer_Read[2 + 10 * 26] = (u8)(gps_data.RevWrite_data.PowTmp  >> 8);
    FontBuffer_Read[3 + 10 * 26] = (u8)gps_data.RevWrite_data.PowTmp;

    FontBuffer_Read[0 + 10 * 27] = 0xaa;
    FontBuffer_Read[1 + 10 * 27] = 0x55;
    FontBuffer_Read[2 + 10 * 27] = (u8)(gps_data.RevWrite_data.PowTmpH  >> 8);
    FontBuffer_Read[3 + 10 * 27] = (u8)gps_data.RevWrite_data.PowTmpH;

    FontBuffer_Read[0 + 10 * 28] = 0xaa;
    FontBuffer_Read[1 + 10 * 28] = 0x55;
    FontBuffer_Read[2 + 10 * 28] = (u8)(gps_data.RevWrite_data.Equaltmpb  >> 8);
    FontBuffer_Read[3 + 10 * 28] = (u8)gps_data.RevWrite_data.Equaltmpb;

    FontBuffer_Read[0 + 10 * 29] = 0xaa;
    FontBuffer_Read[1 + 10 * 29] = 0x55;
    FontBuffer_Read[2 + 10 * 29] = (u8)(gps_data.RevWrite_data.EqualtmpH  >> 8);
    FontBuffer_Read[3 + 10 * 29] = (u8)gps_data.RevWrite_data.EqualtmpH;

    FontBuffer_Read[0 + 10 * 30] = 0xaa;
    FontBuffer_Read[1 + 10 * 30] = 0x55;
    FontBuffer_Read[2 + 10 * 30] = (u8)(gps_data.RevWrite_data.CellTmp  >> 8);
    FontBuffer_Read[3 + 10 * 30] = (u8)gps_data.RevWrite_data.CellTmp;

    FontBuffer_Read[0 + 10 * 31] = 0xaa;
    FontBuffer_Read[1 + 10 * 31] = 0x55;
    FontBuffer_Read[2 + 10 * 31] = (u8)(gps_data.RevWrite_data.CellChgTmpG  >> 8);
    FontBuffer_Read[3 + 10 * 31] = (u8)gps_data.RevWrite_data.CellChgTmpG;

    FontBuffer_Read[0 + 10 * 32] = 0xaa;
    FontBuffer_Read[1 + 10 * 32] = 0x55;
    FontBuffer_Read[2 + 10 * 32] = (u8)(gps_data.RevWrite_data.CellOutTmpG  >> 8);
    FontBuffer_Read[3 + 10 * 32] = (u8)gps_data.RevWrite_data.CellOutTmpG;

    FontBuffer_Read[0 + 10 * 33] = 0xaa;
    FontBuffer_Read[1 + 10 * 33] = 0x55;
    FontBuffer_Read[2 + 10 * 33] = (u8)(gps_data.RevWrite_data.ChgTmpD  >> 8);
    FontBuffer_Read[3 + 10 * 33] = (u8)gps_data.RevWrite_data.ChgTmpD;

    FontBuffer_Read[0 + 10 * 34] = 0xaa;
    FontBuffer_Read[1 + 10 * 34] = 0x55;
    FontBuffer_Read[2 + 10 * 34] = (u8)(gps_data.RevWrite_data.ChgTmpDH  >> 8);
    FontBuffer_Read[3 + 10 * 34] = (u8)gps_data.RevWrite_data.ChgTmpDH;

    FontBuffer_Read[0 + 10 * 35] = 0xaa;
    FontBuffer_Read[1 + 10 * 35] = 0x55;
    FontBuffer_Read[2 + 10 * 35] = (u8)(gps_data.RevWrite_data.OutTmpD  >> 8);
    FontBuffer_Read[3 + 10 * 35] = (u8)gps_data.RevWrite_data.OutTmpD;

    FontBuffer_Read[0 + 10 * 36] = 0xaa;
    FontBuffer_Read[1 + 10 * 36] = 0x55;
    FontBuffer_Read[2 + 10 * 36] = (u8)(gps_data.RevWrite_data.OutTmpDH  >> 8);
    FontBuffer_Read[3 + 10 * 36] = (u8)gps_data.RevWrite_data.OutTmpDH;

    FontBuffer_Read[0 + 10 * 37] = 0xaa;
    FontBuffer_Read[1 + 10 * 37] = 0x55;
    FontBuffer_Read[2 + 10 * 37] = (u8)gps_data.RevWrite_data.Cellnum;

    FontBuffer_Read[0 + 10 * 38] = 0xaa;
    FontBuffer_Read[1 + 10 * 38] = 0x55;
    FontBuffer_Read[2 + 10 * 38] = (u8)(gps_data.RevWrite_data.CellRl  >> 24);
    FontBuffer_Read[3 + 10 * 38] = (u8)(gps_data.RevWrite_data.CellRl  >> 16);
    FontBuffer_Read[4 + 10 * 38] = (u8)(gps_data.RevWrite_data.CellRl  >> 8);
    FontBuffer_Read[5 + 10 * 38] = (u8) gps_data.RevWrite_data.CellRl;

    FontBuffer_Read[0 + 10 * 39] = 0xaa;
    FontBuffer_Read[1 + 10 * 39] = 0x55;
    FontBuffer_Read[2 + 10 * 39] = (u8)Chg_Lock;

    FontBuffer_Read[0 + 10 * 40] = 0xaa;
    FontBuffer_Read[1 + 10 * 40] = 0x55;
    FontBuffer_Read[2 + 10 * 40] = (u8)Out_Lock;

    FontBuffer_Read[0 + 10 * 41] = 0xaa;
    FontBuffer_Read[1 + 10 * 41] = 0x55;
    FontBuffer_Read[2 + 10 * 41] = (u8)(gps_data.RevWrite_data.CurrJZ  >> 8);
    FontBuffer_Read[3 + 10 * 41] = (u8)gps_data.RevWrite_data.CurrJZ;

    FontBuffer_Read[0 + 10 * 42] = 0xaa;
    FontBuffer_Read[1 + 10 * 42] = 0x55;
    FontBuffer_Read[2 + 10 * 42] = (u8)gps_data.RevWrite_data.BHBAddr;

    FontBuffer_Read[0 + 10 * 43] = 0xaa;
    FontBuffer_Read[1 + 10 * 43] = 0x55;
    FontBuffer_Read[2 + 10 * 43] = (u8)gps_data.RevWrite_data.Celltype;

    FontBuffer_Read[0 + 10 * 44] = 0xaa;
    FontBuffer_Read[1 + 10 * 44] = 0x55;
    FontBuffer_Read[2 + 10 * 44] = (u8)(gps_data.RevWrite_data.SleepTime  >> 8);
    FontBuffer_Read[3 + 10 * 44] = (u8)gps_data.RevWrite_data.SleepTime;

    FontBuffer_Read[0 + 10 * 45] = 0xaa;
    FontBuffer_Read[1 + 10 * 45] = 0x55;
    FontBuffer_Read[2 + 10 * 45] = gps_data.RevWrite_data.DRLNum;

    FontBuffer_Read[0 + 10 * 46] = 0xaa;
    FontBuffer_Read[1 + 10 * 46] = 0x55;
    memcpy(&FontBuffer_Read[2 + 10 * 46], gps_data.RevWrite_data.Pass, 8);

    FontBuffer_Read[0 + 10 * 47] = 0xaa;
    FontBuffer_Read[1 + 10 * 47] = 0x55;
    FontBuffer_Read[2 + 10 * 47] = (u8)gps_data.RevWrite_data.ZChgON;

    FontBuffer_Read[0 + 10 * 48] = 0xaa;
    FontBuffer_Read[1 + 10 * 48] = 0x55;
    memcpy(&FontBuffer_Read[2 + 10 * 48], gps_data.RevWrite_data.EquID, 8);

    FontBuffer_Read[0 + 10 * 49] = 0xaa;
    FontBuffer_Read[1 + 10 * 49] = 0x55;
    FontBuffer_Read[2 + 10 * 49] = gps_data.RevWrite_data.CCDat[0];
    FontBuffer_Read[3 + 10 * 49] = gps_data.RevWrite_data.CCDat[1];
    FontBuffer_Read[4 + 10 * 49] = gps_data.RevWrite_data.CCDat[2];
    FontBuffer_Read[5 + 10 * 49] = gps_data.RevWrite_data.CCDat[3];

    FontBuffer_Read[0 + 10 * 50] = 0xaa;
    FontBuffer_Read[1 + 10 * 50] = 0x55;
    FontBuffer_Read[2 + 10 * 50] = (u8)(gps_data.RevWrite_data.SysTime  >> 24);
    FontBuffer_Read[3 + 10 * 50] = (u8)(gps_data.RevWrite_data.SysTime  >> 16);
    FontBuffer_Read[4 + 10 * 50] = (u8)(gps_data.RevWrite_data.SysTime  >> 8);
    FontBuffer_Read[5 + 10 * 50] = (u8) gps_data.RevWrite_data.SysTime;

    FontBuffer_Read[0 + 10 * 52] = 0xaa;
    FontBuffer_Read[1 + 10 * 52] = 0x55;
    FontBuffer_Read[2 + 10 * 52] = (u8)(gps_data.RevWrite_data.Reali_Q  >> 24);
    FontBuffer_Read[3 + 10 * 52] = (u8)(gps_data.RevWrite_data.Reali_Q  >> 16);
    FontBuffer_Read[4 + 10 * 52] = (u8)(gps_data.RevWrite_data.Reali_Q  >> 8);
    FontBuffer_Read[5 + 10 * 52] = (u8) gps_data.RevWrite_data.Reali_Q;

    ////////////////////////////////////////////////////////////////////////
    FontBuffer_Read[0 + 10 * 53] = 0xaa;
    FontBuffer_Read[1 + 10 * 53] = 0x55;
    FontBuffer_Read[2 + 10 * 53] = gps_data.RevWrite_data.XID[0]; //'B'
    FontBuffer_Read[3 + 10 * 53] = gps_data.RevWrite_data.XID[1]; //'T'
    FontBuffer_Read[4 + 10 * 53] = gps_data.RevWrite_data.XID[2]; //'3'
    FontBuffer_Read[5 + 10 * 53] = gps_data.RevWrite_data.XID[3]; //'0'
    FontBuffer_Read[6 + 10 * 53] = gps_data.RevWrite_data.XID[4]; //'7'
    FontBuffer_Read[7 + 10 * 53] = gps_data.RevWrite_data.XID[5]; //'2'
    FontBuffer_Read[8 + 10 * 53] = gps_data.RevWrite_data.XID[6]; //'0'
    FontBuffer_Read[9 + 10 * 53] = gps_data.RevWrite_data.XID[7]; //'2'


    FontBuffer_Read[0 + 10 * 54] = 0xaa;
    FontBuffer_Read[1 + 10 * 54] = 0x55;
    FontBuffer_Read[2 + 10 * 54] = gps_data.RevWrite_data.XID[8]; //'0'
    FontBuffer_Read[3 + 10 * 54] = gps_data.RevWrite_data.XID[9]; //'1'
    FontBuffer_Read[4 + 10 * 54] = gps_data.RevWrite_data.XID[10]; //'2'
    FontBuffer_Read[5 + 10 * 54] = gps_data.RevWrite_data.XID[11]; //'0'
    FontBuffer_Read[6 + 10 * 54] = gps_data.RevWrite_data.XID[12]; //'0'
    FontBuffer_Read[7 + 10 * 54] = gps_data.RevWrite_data.XID[13]; //'0'
    FontBuffer_Read[8 + 10 * 54] = gps_data.RevWrite_data.XID[14]; //'0'

    FontBuffer_Read[0 + 10 * 55] = 0xaa;
    FontBuffer_Read[1 + 10 * 55] = 0x55;
    FontBuffer_Read[2 + 10 * 55] = gps_data.RevWrite_data.XID[15]; //'2'
    FontBuffer_Read[3 + 10 * 55] = gps_data.RevWrite_data.XID[16]; //'0'
    FontBuffer_Read[4 + 10 * 55] = gps_data.RevWrite_data.XID[17]; //'0'
    FontBuffer_Read[5 + 10 * 55] = gps_data.RevWrite_data.XID[18]; //'5'
    FontBuffer_Read[6 + 10 * 55] = gps_data.RevWrite_data.XID[19]; //'2'
    FontBuffer_Read[7 + 10 * 55] = gps_data.RevWrite_data.XID[20]; //'1'



    FontBuffer_Read[0 + 10 * 59] = 0xaa;
    FontBuffer_Read[1 + 10 * 59] = 0x55;
    FontBuffer_Read[2 + 10 * 59] = (u8)(gps_data.RevWrite_data.GpsDVol  >> 8);
    FontBuffer_Read[3 + 10 * 59] = (u8)gps_data.RevWrite_data.GpsDVol;



    FontBuffer_Read[0 + 10 * 60] = 0xaa;
    FontBuffer_Read[1 + 10 * 60] = 0x55;
    FontBuffer_Read[2 + 10 * 60] = (u8)(gps_data.RevWrite_data.GpsDVolH  >> 8);
    FontBuffer_Read[3 + 10 * 60] = (u8)gps_data.RevWrite_data.GpsDVolH;

    FontBuffer_Read[0 + 10 * 56] = 0xaa;
    FontBuffer_Read[1 + 10 * 56] = 0x55;
    FontBuffer_Read[2 + 10 * 56] = gps_data.RevWrite_data.XID[21]; //'0'
    FontBuffer_Read[3 + 10 * 56] = gps_data.RevWrite_data.XID[22]; //'0'
    FontBuffer_Read[4 + 10 * 56] = gps_data.RevWrite_data.XID[23]; //'1'

    FontBuffer_Read[0 + 10 * 61] = 0xaa;
    FontBuffer_Read[1 + 10 * 61] = 0x55;
    FontBuffer_Read[2 + 10 * 61] = (u8)gps_data.RevWrite_data.ShiduKaiguan;

    FontBuffer_Read[0 + 10 * 62] = 0xaa;
    FontBuffer_Read[1 + 10 * 62] = 0x55;
    FontBuffer_Read[2 + 10 * 62] = (u8)gps_data.RevWrite_data.ShiduValueNow;

    FontBuffer_Read[0 + 10 * 63] = 0xaa;
    FontBuffer_Read[1 + 10 * 63] = 0x55;
    FontBuffer_Read[2 + 10 * 63] = (u8)gps_data.RevWrite_data.ShiduValueProtect;

    FontBuffer_Read[0 + 10 * 64] = 0xaa;
    FontBuffer_Read[1 + 10 * 64] = 0x55;
    FontBuffer_Read[2 + 10 * 64] = (u8)gps_data.RevWrite_data.ShortCurValue;

    FontBuffer_Read[0 + 10 * 65] = 0xaa;
    FontBuffer_Read[1 + 10 * 65] = 0x55;
    FontBuffer_Read[2 + 10 * 65] = (u8)(gps_data.RevWrite_data.ShortCurDelay  >> 8);
    FontBuffer_Read[3 + 10 * 65] = (u8)gps_data.RevWrite_data.ShortCurDelay;

    FontBuffer_Read[0 + 10 * 66] = 0xaa;
    FontBuffer_Read[1 + 10 * 66] = 0x55;
    FontBuffer_Read[2 + 10 * 66] = (u8)(gps_data.RevWrite_data.EnableSwitch  >> 8);
    FontBuffer_Read[3 + 10 * 66] = (u8)gps_data.RevWrite_data.EnableSwitch;

    FontBuffer_Read[0 + 10 * 67] = 0xaa;
    FontBuffer_Read[1 + 10 * 67] = 0x55;
    FontBuffer_Read[2 + 10 * 67] = (u8)(gps_data.RevWrite_data.CellOUT2CURR_G  >> 8);
    FontBuffer_Read[3 + 10 * 67] = (u8)gps_data.RevWrite_data.CellOUT2CURR_G;

    FontBuffer_Read[0 + 10 * 68] = 0xaa;
    FontBuffer_Read[1 + 10 * 68] = 0x55;
    FontBuffer_Read[2 + 10 * 68] = (u8)(gps_data.RevWrite_data.CellOUT2TIME_G  >> 8);
    FontBuffer_Read[3 + 10 * 68] = (u8)gps_data.RevWrite_data.CellOUT2TIME_G;

    FontBuffer_Read[0 + 10 * 69] = 0xaa;
    FontBuffer_Read[1 + 10 * 69] = 0x55;
    FontBuffer_Read[2 + 10 * 69] = (u8)(gps_data.RevWrite_data.CellDRLBEEP_Jiao  >> 8);
    FontBuffer_Read[3 + 10 * 69] = (u8)gps_data.RevWrite_data.CellDRLBEEP_Jiao;

    /*��ʼдFLASH����*/
    IapProgram_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);

}

/*
*��������flash_write_sys_flag
*����������	wu
*��������ֵ��wu
*�������ܣ�дFLASH��ʼ����Ϣ
*/

void  flash_write_sys_flag_Init(void)
{
    IapRead_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);

    FontBuffer_Read[0 + 10 * 12] = 0xaa;
    FontBuffer_Read[1 + 10 * 12] = 0x55;
    FontBuffer_Read[2 + 10 * 12] = (u8)(gps_data.RevWrite_data.SingvolG  >> 8);
    FontBuffer_Read[3 + 10 * 12] = (u8)gps_data.RevWrite_data.SingvolG;

    FontBuffer_Read[0 + 10 * 13] = 0xaa;
    FontBuffer_Read[1 + 10 * 13] = 0x55;
    FontBuffer_Read[2 + 10 * 13] = (u8)(gps_data.RevWrite_data.SingvolGH  >> 8);
    FontBuffer_Read[3 + 10 * 13] = (u8)gps_data.RevWrite_data.SingvolGH;

    FontBuffer_Read[0 + 10 * 14] = 0xaa;
    FontBuffer_Read[1 + 10 * 14] = 0x55;
    FontBuffer_Read[2 + 10 * 14] = (u8)(gps_data.RevWrite_data.SingvolGtime  >> 8);
    FontBuffer_Read[3 + 10 * 14] = (u8)gps_data.RevWrite_data.SingvolGtime;

    FontBuffer_Read[0 + 10 * 15] = 0xaa;
    FontBuffer_Read[1 + 10 * 15] = 0x55;
    FontBuffer_Read[2 + 10 * 15] = (u8)(gps_data.RevWrite_data.SingvolQ  >> 8);
    FontBuffer_Read[3 + 10 * 15] = (u8)gps_data.RevWrite_data.SingvolQ;

    FontBuffer_Read[0 + 10 * 16] = 0xaa;
    FontBuffer_Read[1 + 10 * 16] = 0x55;
    FontBuffer_Read[2 + 10 * 16] = (u8)(gps_data.RevWrite_data.SingvolQH  >> 8);
    FontBuffer_Read[3 + 10 * 16] = (u8)gps_data.RevWrite_data.SingvolQH;

    FontBuffer_Read[0 + 10 * 17] = 0xaa;
    FontBuffer_Read[1 + 10 * 17] = 0x55;
    FontBuffer_Read[2 + 10 * 17] = (u8)(gps_data.RevWrite_data.SingvolQtime  >> 8);
    FontBuffer_Read[3 + 10 * 17] = (u8)gps_data.RevWrite_data.SingvolQtime;

    FontBuffer_Read[0 + 10 * 18] = 0xaa;
    FontBuffer_Read[1 + 10 * 18] = 0x55;
    FontBuffer_Read[2 + 10 * 18] = (u8)(gps_data.RevWrite_data.CellXyc  >> 8);
    FontBuffer_Read[3 + 10 * 18] = (u8)gps_data.RevWrite_data.CellXyc;

    FontBuffer_Read[0 + 10 * 19] = 0xaa;
    FontBuffer_Read[1 + 10 * 19] = 0x55;
    FontBuffer_Read[2 + 10 * 19] = (u8)(gps_data.RevWrite_data.OutcurrG  >> 8);
    FontBuffer_Read[3 + 10 * 19] = (u8)gps_data.RevWrite_data.OutcurrG;

    FontBuffer_Read[0 + 10 * 20] = 0xaa;
    FontBuffer_Read[1 + 10 * 20] = 0x55;
    FontBuffer_Read[2 + 10 * 20] = (u8)(gps_data.RevWrite_data.OutcurrGtime  >> 8);
    FontBuffer_Read[3 + 10 * 20] = (u8)gps_data.RevWrite_data.OutcurrGtime;

    FontBuffer_Read[0 + 10 * 21] = 0xaa;
    FontBuffer_Read[1 + 10 * 21] = 0x55;
    FontBuffer_Read[2 + 10 * 21] = (u8)(gps_data.RevWrite_data.ChgcurrG  >> 8);
    FontBuffer_Read[3 + 10 * 21] = (u8)gps_data.RevWrite_data.ChgcurrG;

    FontBuffer_Read[0 + 10 * 22] = 0xaa;
    FontBuffer_Read[1 + 10 * 22] = 0x55;
    FontBuffer_Read[2 + 10 * 22] = (u8)(gps_data.RevWrite_data.ChgcurrGtime  >> 8);
    FontBuffer_Read[3 + 10 * 22] = (u8)gps_data.RevWrite_data.ChgcurrGtime;

    FontBuffer_Read[0 + 10 * 23] = 0xaa;
    FontBuffer_Read[1 + 10 * 23] = 0x55;
    FontBuffer_Read[2 + 10 * 23] = (u8)(gps_data.RevWrite_data.Equalivol  >> 8);
    FontBuffer_Read[3 + 10 * 23] = (u8)gps_data.RevWrite_data.Equalivol;

    FontBuffer_Read[0 + 10 * 24] = 0xaa;
    FontBuffer_Read[1 + 10 * 24] = 0x55;
    FontBuffer_Read[2 + 10 * 24] = (u8)(gps_data.RevWrite_data.Equalivolcc  >> 8);
    FontBuffer_Read[3 + 10 * 24] = (u8)gps_data.RevWrite_data.Equalivolcc;

    /*��ʼдFLASH����*/
    IapProgram_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);
}


/*
*��������flash_write_sys_flag
*����������	wu
*��������ֵ��wu
*�������ܣ�дFLASH��ʼ����Ϣ
*/

void  flash_write_sys_flag_Zvol(void)
{
    IapRead_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);

    FontBuffer_Read[0 + 10 * 10] = 0xaa;
    FontBuffer_Read[1 + 10 * 10] = 0x55;
    FontBuffer_Read[2 + 10 * 10] = (u8)(gps_data.RevWrite_data.ZvolG  >> 8);
    FontBuffer_Read[3 + 10 * 10] = (u8) gps_data.RevWrite_data.ZvolG;

    FontBuffer_Read[0 + 10 * 11] = 0xaa;
    FontBuffer_Read[1 + 10 * 11] = 0x55;
    FontBuffer_Read[2 + 10 * 11] = (u8)(gps_data.RevWrite_data.ZvolQ  >> 8);
    FontBuffer_Read[3 + 10 * 11] = (u8)gps_data.RevWrite_data.ZvolQ;

    /*��ʼдFLASH����*/
    IapProgram_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);

}


/*EEPROM����ʱ���³�ʼ��*/
void  flash_write_sys_flag_ALL_Init(void)
{
    unsigned int int_data = 0;

    IapRead_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);

    Cell_usnum = 0;
    FontBuffer_Read[0 + 10 * 1] = 0xaa;                           //ѭ������
    FontBuffer_Read[1 + 10 * 1] = 0x55;
    FontBuffer_Read[2 + 10 * 1] = (u8)(Cell_usnum  >> 8);
    FontBuffer_Read[3 + 10 * 1] = (u8) Cell_usnum;

    Cell_Outrl = 0;
    gps_data.Rev_data.CellOutrl = 0;
    FontBuffer_Read[0 + 10 * 2] = 0xaa;                           //ѭ���ŵ���
    FontBuffer_Read[1 + 10 * 2] = 0x55;
    FontBuffer_Read[2 + 10 * 2] = (u8)(gps_data.Rev_data.CellOutrl  >> 24);
    FontBuffer_Read[3 + 10 * 2] = (u8)(gps_data.Rev_data.CellOutrl  >> 16);
    FontBuffer_Read[4 + 10 * 2] = (u8)(gps_data.Rev_data.CellOutrl  >> 8);
    FontBuffer_Read[5 + 10 * 2] = (u8) gps_data.Rev_data.CellOutrl;

    gps_data.RevWrite_data.SingvolG = 4200;
    FontBuffer_Read[0 + 10 * 12] = 0xaa;
    FontBuffer_Read[1 + 10 * 12] = 0x55;
    FontBuffer_Read[2 + 10 * 12] = (u8)(gps_data.RevWrite_data.SingvolG  >> 8);
    FontBuffer_Read[3 + 10 * 12] = (u8)gps_data.RevWrite_data.SingvolG;

    gps_data.RevWrite_data.SingvolGH = 4100;
    FontBuffer_Read[0 + 10 * 13] = 0xaa;
    FontBuffer_Read[1 + 10 * 13] = 0x55;
    FontBuffer_Read[2 + 10 * 13] = (u8)(gps_data.RevWrite_data.SingvolGH  >> 8);
    FontBuffer_Read[3 + 10 * 13] = (u8)gps_data.RevWrite_data.SingvolGH;

    gps_data.RevWrite_data.SingvolGtime = 4;
    FontBuffer_Read[0 + 10 * 14] = 0xaa;
    FontBuffer_Read[1 + 10 * 14] = 0x55;
    FontBuffer_Read[2 + 10 * 14] = (u8)(gps_data.RevWrite_data.SingvolGtime  >> 8);
    FontBuffer_Read[3 + 10 * 14] = (u8)gps_data.RevWrite_data.SingvolGtime;

    gps_data.RevWrite_data.SingvolQ = 2800;
    FontBuffer_Read[0 + 10 * 15] = 0xaa;
    FontBuffer_Read[1 + 10 * 15] = 0x55;
    FontBuffer_Read[2 + 10 * 15] = (u8)(gps_data.RevWrite_data.SingvolQ  >> 8);
    FontBuffer_Read[3 + 10 * 15] = (u8)gps_data.RevWrite_data.SingvolQ;

    gps_data.RevWrite_data.SingvolQH = 2900;
    FontBuffer_Read[0 + 10 * 16] = 0xaa;
    FontBuffer_Read[1 + 10 * 16] = 0x55;
    FontBuffer_Read[2 + 10 * 16] = (u8)(gps_data.RevWrite_data.SingvolQH  >> 8);
    FontBuffer_Read[3 + 10 * 16] = (u8)gps_data.RevWrite_data.SingvolQH;

    gps_data.RevWrite_data.SingvolQtime = 4;
    FontBuffer_Read[0 + 10 * 17] = 0xaa;
    FontBuffer_Read[1 + 10 * 17] = 0x55;
    FontBuffer_Read[2 + 10 * 17] = (u8)(gps_data.RevWrite_data.SingvolQtime  >> 8);
    FontBuffer_Read[3 + 10 * 17] = (u8)gps_data.RevWrite_data.SingvolQtime;

    gps_data.RevWrite_data.CellXyc = 1000;
    FontBuffer_Read[0 + 10 * 18] = 0xaa;
    FontBuffer_Read[1 + 10 * 18] = 0x55;
    FontBuffer_Read[2 + 10 * 18] = (u8)(gps_data.RevWrite_data.CellXyc  >> 8);
    FontBuffer_Read[3 + 10 * 18] = (u8)gps_data.RevWrite_data.CellXyc;

    gps_data.RevWrite_data.OutcurrG = 60;
    FontBuffer_Read[0 + 10 * 19] = 0xaa;
    FontBuffer_Read[1 + 10 * 19] = 0x55;
    FontBuffer_Read[2 + 10 * 19] = (u8)(gps_data.RevWrite_data.OutcurrG  >> 8);
    FontBuffer_Read[3 + 10 * 19] = (u8)gps_data.RevWrite_data.OutcurrG;

    gps_data.RevWrite_data.OutcurrGtime = 60;
    FontBuffer_Read[0 + 10 * 20] = 0xaa;
    FontBuffer_Read[1 + 10 * 20] = 0x55;
    FontBuffer_Read[2 + 10 * 20] = (u8)(gps_data.RevWrite_data.OutcurrGtime  >> 8);
    FontBuffer_Read[3 + 10 * 20] = (u8)gps_data.RevWrite_data.OutcurrGtime;

    gps_data.RevWrite_data.ChgcurrG = 20;
    FontBuffer_Read[0 + 10 * 21] = 0xaa;
    FontBuffer_Read[1 + 10 * 21] = 0x55;
    FontBuffer_Read[2 + 10 * 21] = (u8)(gps_data.RevWrite_data.ChgcurrG  >> 8);
    FontBuffer_Read[3 + 10 * 21] = (u8)gps_data.RevWrite_data.ChgcurrG;

    gps_data.RevWrite_data.ChgcurrGtime = 64;
    FontBuffer_Read[0 + 10 * 22] = 0xaa;
    FontBuffer_Read[1 + 10 * 22] = 0x55;
    FontBuffer_Read[2 + 10 * 22] = (u8)(gps_data.RevWrite_data.ChgcurrGtime  >> 8);
    FontBuffer_Read[3 + 10 * 22] = (u8)gps_data.RevWrite_data.ChgcurrGtime;

    gps_data.RevWrite_data.Equalivol = 4000;
    FontBuffer_Read[0 + 10 * 23] = 0xaa;
    FontBuffer_Read[1 + 10 * 23] = 0x55;
    FontBuffer_Read[2 + 10 * 23] = (u8)(gps_data.RevWrite_data.Equalivol  >> 8);
    FontBuffer_Read[3 + 10 * 23] = (u8)gps_data.RevWrite_data.Equalivol;

    gps_data.RevWrite_data.Equalivolcc = 10;
    FontBuffer_Read[0 + 10 * 24] = 0xaa;
    FontBuffer_Read[1 + 10 * 24] = 0x55;
    FontBuffer_Read[2 + 10 * 24] = (u8)(gps_data.RevWrite_data.Equalivolcc  >> 8);
    FontBuffer_Read[3 + 10 * 24] = (u8)gps_data.RevWrite_data.Equalivolcc;

    gps_data.RevWrite_data.EqualiON = 1; //��������Ĭ�Ͽ���
    FontBuffer_Read[0 + 10 * 25] = 0xaa;
    FontBuffer_Read[1 + 10 * 25] = 0x55;
    FontBuffer_Read[2 + 10 * 25] = gps_data.RevWrite_data.EqualiON;

    gps_data.RevWrite_data.PowTmp = 75;
    FontBuffer_Read[0 + 10 * 26] = 0xaa;
    FontBuffer_Read[1 + 10 * 26] = 0x55;
    FontBuffer_Read[2 + 10 * 26] = (u8)(gps_data.RevWrite_data.PowTmp  >> 8);
    FontBuffer_Read[3 + 10 * 26] = (u8)gps_data.RevWrite_data.PowTmp;

    gps_data.RevWrite_data.PowTmpH = 60;
    FontBuffer_Read[0 + 10 * 27] = 0xaa;
    FontBuffer_Read[1 + 10 * 27] = 0x55;
    FontBuffer_Read[2 + 10 * 27] = (u8)(gps_data.RevWrite_data.PowTmpH  >> 8);
    FontBuffer_Read[3 + 10 * 27] = (u8)gps_data.RevWrite_data.PowTmpH;

    gps_data.RevWrite_data.Equaltmpb = 65;
    FontBuffer_Read[0 + 10 * 28] = 0xaa;
    FontBuffer_Read[1 + 10 * 28] = 0x55;
    FontBuffer_Read[2 + 10 * 28] = (u8)(gps_data.RevWrite_data.Equaltmpb  >> 8);
    FontBuffer_Read[3 + 10 * 28] = (u8)gps_data.RevWrite_data.Equaltmpb;

    gps_data.RevWrite_data.EqualtmpH = 55;
    FontBuffer_Read[0 + 10 * 29] = 0xaa;
    FontBuffer_Read[1 + 10 * 29] = 0x55;
    FontBuffer_Read[2 + 10 * 29] = (u8)(gps_data.RevWrite_data.EqualtmpH  >> 8);
    FontBuffer_Read[3 + 10 * 29] = (u8)gps_data.RevWrite_data.EqualtmpH;

    gps_data.RevWrite_data.CellTmp = 20;
    FontBuffer_Read[0 + 10 * 30] = 0xaa;
    FontBuffer_Read[1 + 10 * 30] = 0x55;
    FontBuffer_Read[2 + 10 * 30] = (u8)(gps_data.RevWrite_data.CellTmp  >> 8);
    FontBuffer_Read[3 + 10 * 30] = (u8)gps_data.RevWrite_data.CellTmp;

    gps_data.RevWrite_data.CellChgTmpG = 65;
    gps_data.RevWrite_data.CellChgTmpGH = gps_data.RevWrite_data.CellChgTmpG - 10;
    FontBuffer_Read[0 + 10 * 31] = 0xaa;
    FontBuffer_Read[1 + 10 * 31] = 0x55;
    FontBuffer_Read[2 + 10 * 31] = (u8)(gps_data.RevWrite_data.CellChgTmpG  >> 8);
    FontBuffer_Read[3 + 10 * 31] = (u8)gps_data.RevWrite_data.CellChgTmpG;

    gps_data.RevWrite_data.CellOutTmpG = 65;
    gps_data.RevWrite_data.CellOutTmpGH = gps_data.RevWrite_data.CellOutTmpG - 10;
    FontBuffer_Read[0 + 10 * 32] = 0xaa;
    FontBuffer_Read[1 + 10 * 32] = 0x55;
    FontBuffer_Read[2 + 10 * 32] = (u8)(gps_data.RevWrite_data.CellOutTmpG  >> 8);
    FontBuffer_Read[3 + 10 * 32] = (u8)gps_data.RevWrite_data.CellOutTmpG;

    gps_data.RevWrite_data.ChgTmpD = -40;
    FontBuffer_Read[0 + 10 * 33] = 0xaa;
    FontBuffer_Read[1 + 10 * 33] = 0x55;
    FontBuffer_Read[2 + 10 * 33] = (u8)(gps_data.RevWrite_data.ChgTmpD  >> 8);
    FontBuffer_Read[3 + 10 * 33] = (u8)gps_data.RevWrite_data.ChgTmpD;

    gps_data.RevWrite_data.ChgTmpDH = -35;
    FontBuffer_Read[0 + 10 * 34] = 0xaa;
    FontBuffer_Read[1 + 10 * 34] = 0x55;
    FontBuffer_Read[2 + 10 * 34] = (u8)(gps_data.RevWrite_data.ChgTmpDH  >> 8);
    FontBuffer_Read[3 + 10 * 34] = (u8)gps_data.RevWrite_data.ChgTmpDH;

    gps_data.RevWrite_data.OutTmpD = -40;
    FontBuffer_Read[0 + 10 * 35] = 0xaa;
    FontBuffer_Read[1 + 10 * 35] = 0x55;
    FontBuffer_Read[2 + 10 * 35] = (u8)(gps_data.RevWrite_data.OutTmpD  >> 8);
    FontBuffer_Read[3 + 10 * 35] = (u8)gps_data.RevWrite_data.OutTmpD;

    gps_data.RevWrite_data.OutTmpDH = -35;
    FontBuffer_Read[0 + 10 * 36] = 0xaa;
    FontBuffer_Read[1 + 10 * 36] = 0x55;
    FontBuffer_Read[2 + 10 * 36] = (u8)(gps_data.RevWrite_data.OutTmpDH  >> 8);
    FontBuffer_Read[3 + 10 * 36] = (u8)gps_data.RevWrite_data.OutTmpDH;

    gps_data.RevWrite_data.Cellnum = 16; //Ĭ�ϴ���-----
    FontBuffer_Read[0 + 10 * 37] = 0xaa;
    FontBuffer_Read[1 + 10 * 37] = 0x55;
    FontBuffer_Read[2 + 10 * 37] = (u8)gps_data.RevWrite_data.Cellnum;

    ///////////////////////////////

    gps_data.RevWrite_data.ZvolG = gps_data.RevWrite_data.SingvolG / 10.0 * gps_data.RevWrite_data.Cellnum;
    FontBuffer_Read[0 + 10 * 10] = 0xaa;
    FontBuffer_Read[1 + 10 * 10] = 0x55;
    FontBuffer_Read[2 + 10 * 10] = (u8)(gps_data.RevWrite_data.ZvolG  >> 8);
    FontBuffer_Read[3 + 10 * 10] = (u8) gps_data.RevWrite_data.ZvolG;

    gps_data.RevWrite_data.ZvolQ = gps_data.RevWrite_data.SingvolQ / 10.0 * gps_data.RevWrite_data.Cellnum;
    FontBuffer_Read[0 + 10 * 11] = 0xaa;
    FontBuffer_Read[1 + 10 * 11] = 0x55;
    FontBuffer_Read[2 + 10 * 11] = (u8)(gps_data.RevWrite_data.ZvolQ  >> 8);
    FontBuffer_Read[3 + 10 * 11] = (u8)gps_data.RevWrite_data.ZvolQ;

    gps_data.RevWrite_data.CellRl = 40;
    FontBuffer_Read[0 + 10 * 38] = 0xaa;
    FontBuffer_Read[1 + 10 * 38] = 0x55;
    FontBuffer_Read[2 + 10 * 38] = (u8)(gps_data.RevWrite_data.CellRl  >> 24);
    FontBuffer_Read[3 + 10 * 38] = (u8)(gps_data.RevWrite_data.CellRl  >> 16);
    FontBuffer_Read[4 + 10 * 38] = (u8)(gps_data.RevWrite_data.CellRl  >> 8);
    FontBuffer_Read[5 + 10 * 38] = (u8) gps_data.RevWrite_data.CellRl;

    Chg_Lock = 0;
    FontBuffer_Read[0 + 10 * 39] = 0xaa;
    FontBuffer_Read[1 + 10 * 39] = 0x55;
    FontBuffer_Read[2 + 10 * 39] = (u8)Chg_Lock;

    Out_Lock = 0;
    FontBuffer_Read[0 + 10 * 40] = 0xaa;
    FontBuffer_Read[1 + 10 * 40] = 0x55;
    FontBuffer_Read[2 + 10 * 40] = (u8)Out_Lock;

    gps_data.RevWrite_data.CurrJZ = 10000; //mA
    FontBuffer_Read[0 + 10 * 41] = 0xaa;
    FontBuffer_Read[1 + 10 * 41] = 0x55;
    FontBuffer_Read[2 + 10 * 41] = (u8)(gps_data.RevWrite_data.CurrJZ  >> 8);
    FontBuffer_Read[3 + 10 * 41] = (u8)gps_data.RevWrite_data.CurrJZ;

    gps_data.RevWrite_data.BHBAddr = 1;
    FontBuffer_Read[0 + 10 * 42] = 0xaa;
    FontBuffer_Read[1 + 10 * 42] = 0x55;
    FontBuffer_Read[2 + 10 * 42] = (u8)gps_data.RevWrite_data.BHBAddr;

    gps_data.RevWrite_data.Celltype = 1;	//Ĭ����Ԫ
    FontBuffer_Read[0 + 10 * 43] = 0xaa;
    FontBuffer_Read[1 + 10 * 43] = 0x55;
    FontBuffer_Read[2 + 10 * 43] = (u8)gps_data.RevWrite_data.Celltype;

    gps_data.RevWrite_data.SleepTime = 15;
    FontBuffer_Read[0 + 10 * 44] = 0xaa;
    FontBuffer_Read[1 + 10 * 44] = 0x55;
    FontBuffer_Read[2 + 10 * 44] = (u8)(gps_data.RevWrite_data.SleepTime  >> 8);
    FontBuffer_Read[3 + 10 * 44] = (u8)gps_data.RevWrite_data.SleepTime;

    gps_data.RevWrite_data.DRLNum = 10;	    //20%
    FontBuffer_Read[0 + 10 * 45] = 0xaa;
    FontBuffer_Read[1 + 10 * 45] = 0x55;
    FontBuffer_Read[2 + 10 * 45] = gps_data.RevWrite_data.DRLNum;

    memset(gps_data.RevWrite_data.Pass, 0, 8);
    FontBuffer_Read[0 + 10 * 46] = 0xaa;
    FontBuffer_Read[1 + 10 * 46] = 0x55;
    memcpy(&FontBuffer_Read[2 + 10 * 46], gps_data.RevWrite_data.Pass, 8);

    gps_data.RevWrite_data.ZChgON = 0;//ר�ó��������Ĭ�Ϲ�
    FontBuffer_Read[0 + 10 * 47] = 0xaa;
    FontBuffer_Read[1 + 10 * 47] = 0x55;
    FontBuffer_Read[2 + 10 * 47] = (u8)gps_data.RevWrite_data.ZChgON;

    memcpy(gps_data.RevWrite_data.EquID, &databuf[2], 3);			 //603
    memcpy(&gps_data.RevWrite_data.EquID[3], &databuf[9], 5);			 //00001
    FontBuffer_Read[0 + 10 * 48] = 0xaa;
    FontBuffer_Read[1 + 10 * 48] = 0x55;
    memcpy(&FontBuffer_Read[2 + 10 * 48], gps_data.RevWrite_data.EquID, 8);

    memcpy(gps_data.RevWrite_data.CCDat, &databuf[5], 4);			 //2004
    FontBuffer_Read[0 + 10 * 49] = 0xaa;
    FontBuffer_Read[1 + 10 * 49] = 0x55;
    FontBuffer_Read[2 + 10 * 49] = gps_data.RevWrite_data.CCDat[0];
    FontBuffer_Read[3 + 10 * 49] = gps_data.RevWrite_data.CCDat[1];
    FontBuffer_Read[4 + 10 * 49] = gps_data.RevWrite_data.CCDat[2];
    FontBuffer_Read[5 + 10 * 49] = gps_data.RevWrite_data.CCDat[3];

    gps_data.RevWrite_data.SysTime = 0;
    FontBuffer_Read[0 + 10 * 50] = 0xaa;
    FontBuffer_Read[1 + 10 * 50] = 0x55;
    FontBuffer_Read[2 + 10 * 50] = (u8)(gps_data.RevWrite_data.SysTime  >> 24);
    FontBuffer_Read[3 + 10 * 50] = (u8)(gps_data.RevWrite_data.SysTime  >> 16);
    FontBuffer_Read[4 + 10 * 50] = (u8)(gps_data.RevWrite_data.SysTime  >> 8);
    FontBuffer_Read[5 + 10 * 50] = (u8) gps_data.RevWrite_data.SysTime;

    Curr_Res = 0.001035;         //�ָ���׼����
    int_data = *((unsigned int *)&Curr_Res);
    FontBuffer_Read[2 + 10 * 51] = (u8)(int_data  >> 24);
    FontBuffer_Read[3 + 10 * 51] = (u8)(int_data  >> 16);
    FontBuffer_Read[4 + 10 * 51] = (u8)(int_data  >> 8);
    FontBuffer_Read[5 + 10 * 51] = (u8) int_data;

    gps_data.RevWrite_data.Reali_Q = gps_data.RevWrite_data.CellRl; //��ʼ��1:1
    FontBuffer_Read[0 + 10 * 52] = 0xaa;
    FontBuffer_Read[1 + 10 * 52] = 0x55;
    FontBuffer_Read[2 + 10 * 52] = (u8)(gps_data.RevWrite_data.Reali_Q  >> 24);
    FontBuffer_Read[3 + 10 * 52] = (u8)(gps_data.RevWrite_data.Reali_Q  >> 16);
    FontBuffer_Read[4 + 10 * 52] = (u8)(gps_data.RevWrite_data.Reali_Q  >> 8);
    FontBuffer_Read[5 + 10 * 52] = (u8) gps_data.RevWrite_data.Reali_Q;

    ////////////////////////////////////////////////////////////////////////
    memcpy(&gps_data.RevWrite_data.XID[0], &dataxingaobuf[0], 9);
    FontBuffer_Read[0 + 10 * 53] = 0xaa;
    FontBuffer_Read[1 + 10 * 53] = 0x55;
    FontBuffer_Read[2 + 10 * 53] = gps_data.RevWrite_data.XID[2]; //'3'
    FontBuffer_Read[3 + 10 * 53] = gps_data.RevWrite_data.XID[3]; //'0'
    FontBuffer_Read[4 + 10 * 53] = gps_data.RevWrite_data.XID[4]; //'7'
    FontBuffer_Read[5 + 10 * 53] = gps_data.RevWrite_data.XID[5]; //'2'
    FontBuffer_Read[6 + 10 * 53] = gps_data.RevWrite_data.XID[6]; //'0'
    FontBuffer_Read[7 + 10 * 53] = gps_data.RevWrite_data.XID[7]; //'2'
    FontBuffer_Read[8 + 10 * 53] = gps_data.RevWrite_data.XID[8]; //'0'

    memcpy(&gps_data.RevWrite_data.XID[9], &dataxingaobuf[9], 6);
    FontBuffer_Read[0 + 10 * 54] = 0xaa;
    FontBuffer_Read[1 + 10 * 54] = 0x55;
    FontBuffer_Read[2 + 10 * 54] = gps_data.RevWrite_data.XID[9]; //'1'
    FontBuffer_Read[3 + 10 * 54] = gps_data.RevWrite_data.XID[10]; //'2'
    FontBuffer_Read[4 + 10 * 54] = gps_data.RevWrite_data.XID[11]; //'0'
    FontBuffer_Read[5 + 10 * 54] = gps_data.RevWrite_data.XID[12]; //'0'
    FontBuffer_Read[6 + 10 * 54] = gps_data.RevWrite_data.XID[13]; //'0'
    FontBuffer_Read[7 + 10 * 54] = gps_data.RevWrite_data.XID[14]; //'0'

    memcpy(&gps_data.RevWrite_data.XID[15], &dataxingaobuf[15], 6);
    FontBuffer_Read[0 + 10 * 55] = 0xaa;
    FontBuffer_Read[1 + 10 * 55] = 0x55;
    FontBuffer_Read[2 + 10 * 55] = gps_data.RevWrite_data.XID[15]; //'2'
    FontBuffer_Read[3 + 10 * 55] = gps_data.RevWrite_data.XID[16]; //'0'
    FontBuffer_Read[4 + 10 * 55] = gps_data.RevWrite_data.XID[17]; //'0'
    FontBuffer_Read[5 + 10 * 55] = gps_data.RevWrite_data.XID[18]; //'5'
    FontBuffer_Read[6 + 10 * 55] = gps_data.RevWrite_data.XID[19]; //'2'
    FontBuffer_Read[7 + 10 * 55] = gps_data.RevWrite_data.XID[20]; //'1'

    memcpy(&gps_data.RevWrite_data.XID[21], &dataxingaobuf[21], 3);
    FontBuffer_Read[0 + 10 * 56] = 0xaa;
    FontBuffer_Read[1 + 10 * 56] = 0x55;
    FontBuffer_Read[2 + 10 * 56] = gps_data.RevWrite_data.XID[21]; //'0'
    FontBuffer_Read[3 + 10 * 56] = gps_data.RevWrite_data.XID[22]; //'0'
    FontBuffer_Read[4 + 10 * 56] = gps_data.RevWrite_data.XID[23]; //'1'

    if(gps_data.RevWrite_data.Celltype == 0)
        gps_data.RevWrite_data.GpsDVol = 2750;
    else if(gps_data.RevWrite_data.Celltype == 1)
        gps_data.RevWrite_data.GpsDVol = 2750;
    else if(gps_data.RevWrite_data.Celltype == 2)
        gps_data.RevWrite_data.GpsDVol = 2750;

    FontBuffer_Read[0 + 10 * 59] = 0xaa;
    FontBuffer_Read[1 + 10 * 59] = 0x55;
    FontBuffer_Read[2 + 10 * 59] = (u8)(gps_data.RevWrite_data.GpsDVol  >> 8);
    FontBuffer_Read[3 + 10 * 59] = (u8)gps_data.RevWrite_data.GpsDVol;

    if(gps_data.RevWrite_data.Celltype == 0)
        gps_data.RevWrite_data.GpsDVolH = 2850;
    else if(gps_data.RevWrite_data.Celltype == 1)
        gps_data.RevWrite_data.GpsDVolH = 2850;
    else if(gps_data.RevWrite_data.Celltype == 2)
        gps_data.RevWrite_data.GpsDVolH = 2850;

    FontBuffer_Read[0 + 10 * 60] = 0xaa;
    FontBuffer_Read[1 + 10 * 60] = 0x55;
    FontBuffer_Read[2 + 10 * 60] = (u8)(gps_data.RevWrite_data.GpsDVolH  >> 8);
    FontBuffer_Read[3 + 10 * 60] = (u8)gps_data.RevWrite_data.GpsDVolH;

    gps_data.RevWrite_data.ShiduKaiguan = 0; //ʪ�ȿ���Ĭ�Ϲر�
    FontBuffer_Read[0 + 10 * 61] = 0xaa;
    FontBuffer_Read[1 + 10 * 61] = 0x55;
    FontBuffer_Read[2 + 10 * 61] = (u8)gps_data.RevWrite_data.ShiduKaiguan;

    FontBuffer_Read[0 + 10 * 62] = 0xaa;
    FontBuffer_Read[1 + 10 * 62] = 0x55;
    FontBuffer_Read[2 + 10 * 62] = (u8)gps_data.RevWrite_data.ShiduValueNow;

    gps_data.RevWrite_data.ShiduValueProtect = 90; //ʪ�ȱ�����ֵ Ĭ��90 ��λ��%
    FontBuffer_Read[0 + 10 * 63] = 0xaa;
    FontBuffer_Read[1 + 10 * 63] = 0x55;
    FontBuffer_Read[2 + 10 * 63] = (u8)gps_data.RevWrite_data.ShiduValueProtect;

    gps_data.RevWrite_data.ShortCurValue = 38; //��·����ֵĬ��38  ��λ��10A
    FontBuffer_Read[0 + 10 * 64] = 0xaa;
    FontBuffer_Read[1 + 10 * 64] = 0x55;
    FontBuffer_Read[2 + 10 * 64] = (u8)gps_data.RevWrite_data.ShortCurValue;

    gps_data.RevWrite_data.ShortCurDelay = 400; //��·��ʱĬ��  400us
    FontBuffer_Read[0 + 10 * 65] = 0xaa;
    FontBuffer_Read[1 + 10 * 65] = 0x55;
    FontBuffer_Read[2 + 10 * 65] = (u8)(gps_data.RevWrite_data.ShortCurDelay  >> 8);
    FontBuffer_Read[3 + 10 * 65] = (u8)gps_data.RevWrite_data.ShortCurDelay;

    gps_data.RevWrite_data.EnableSwitch = 0x0002; //ʹ�ܿ���
    FontBuffer_Read[0 + 10 * 66] = 0xaa;
    FontBuffer_Read[1 + 10 * 66] = 0x55;
    FontBuffer_Read[2 + 10 * 66] = (u8)(gps_data.RevWrite_data.EnableSwitch  >> 8);
    FontBuffer_Read[3 + 10 * 66] = (u8)gps_data.RevWrite_data.EnableSwitch;

    gps_data.RevWrite_data.CellOUT2CURR_G = 80; //�������ŵ���
    FontBuffer_Read[0 + 10 * 67] = 0xaa;
    FontBuffer_Read[1 + 10 * 67] = 0x55;
    FontBuffer_Read[2 + 10 * 67] = (u8)(gps_data.RevWrite_data.CellOUT2CURR_G  >> 8);
    FontBuffer_Read[3 + 10 * 67] = (u8)gps_data.RevWrite_data.CellOUT2CURR_G;

    gps_data.RevWrite_data.CellOUT2TIME_G = 4; //�������ŵ�����ʱ
    FontBuffer_Read[0 + 10 * 68] = 0xaa;
    FontBuffer_Read[1 + 10 * 68] = 0x55;
    FontBuffer_Read[2 + 10 * 68] = (u8)(gps_data.RevWrite_data.CellOUT2TIME_G  >> 8);
    FontBuffer_Read[3 + 10 * 68] = (u8)gps_data.RevWrite_data.CellOUT2TIME_G;

    gps_data.RevWrite_data.CellDRLBEEP_Jiao = 3350; //������У׼��ѹ
    FontBuffer_Read[0 + 10 * 69] = 0xaa;
    FontBuffer_Read[1 + 10 * 69] = 0x55;
    FontBuffer_Read[2 + 10 * 69] = (u8)(gps_data.RevWrite_data.CellDRLBEEP_Jiao  >> 8);
    FontBuffer_Read[3 + 10 * 69] = (u8)gps_data.RevWrite_data.CellDRLBEEP_Jiao;

    /*��ʼдFLASH����*/
    IapProgram_num(FontBuffer_Read, sys_flag1_flash_addr, flag_nem * one_flag_leng);

}


