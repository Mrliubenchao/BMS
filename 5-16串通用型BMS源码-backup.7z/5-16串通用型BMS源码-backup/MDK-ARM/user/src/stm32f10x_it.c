/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTI

  AL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "stm32f10x.h"
#include "stm32f10x_conf.h"

#include "button/iobutton.h"
#include "timer/ntimer.h"

#include <string.h>
#include <stdBool.h>
#include <stdio.h>
#include <math.h>

#include "datahand.h"
#include "gpioinit.h"
#include "perconfig.h"
#include "delay.h"
#include "basetime.h"
#include "usart.h"
#include "iobind.h"
#include "joinbind.h"

#include "gpioinit.h"
#include "perconfig.h"

#include "485.h"
#include "gpsnet.h"
#include "usart.h"
#include "can.h"
#include "Jdy_19.h"
#include "gps2.h"

#include "LCD.h"


u8  ledflag = 0;
u8  GpsHaveDateFlag = 0;
u16 g_SysMilliSecCnt = 0;

u32 TT_delay_Count = 0;
u8 TT_delay_flag = 0;


/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
    /* Go to infinite loop when Hard Fault exception occurs */
    while (1)
    {
    }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
    /* Go to infinite loop when Memory Manage exception occurs */
    while (1)
    {
    }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
    /* Go to infinite loop when Bus Fault exception occurs */
    while (1)
    {
    }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
    /* Go to infinite loop when Usage Fault exception occurs */
    while (1)
    {
    }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{

}




/*�жϷ�����*/

void USART1_IRQHandler(void)
{
    u8 res;
    u16 GpsDataLenTemp = 0;
    u16 G4DataLenTemp = 0;
    u32 temp = 0;

    if(USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET)
    {
        temp = USART1->SR;
        temp = USART1->DR;
        USART_ClearFlag(USART1, USART_FLAG_ORE);
    }

    if(USART_GetFlagStatus(USART1, USART_FLAG_NE) != RESET)
    {
        temp = USART1->SR;
        temp = USART1->DR;
        USART_ClearFlag(USART1, USART_FLAG_NE);

    }

    if(USART_GetFlagStatus(USART1, USART_FLAG_FE) != RESET)
    {
        temp = USART1->SR;
        temp = USART1->DR;
        USART_ClearFlag(USART1, USART_FLAG_FE);

    }

    if(USART_GetFlagStatus(USART1, USART_FLAG_PE) != RESET)
    {
        temp = USART1->SR;
        temp = USART1->DR;
        USART_ClearFlag(USART1, USART_FLAG_PE);

    }

    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(USART1, USART_IT_RXNE); //����жϱ�־.
        res = USART1->DR;




        //������
        LCD_Data_BUFF.G4_Rev_buf[LCD_Data_BUFF.G4_Rev_buftmp] = res;

        if(LCD_Data_BUFF.G4_Rev_buftmp == 0)	    //�ж�֡ͷ
        {
            LCD_Data_BUFF.G4_Rev_buftmp = (res != (u8)(LCD_HAND >> 8)) ? 0 : LCD_Data_BUFF.G4_Rev_buftmp + 1;
        }
        else if(LCD_Data_BUFF.G4_Rev_buftmp == 1)
        {
            LCD_Data_BUFF.G4_Rev_buftmp = (res != (u8)(LCD_HAND)) ? 0 : LCD_Data_BUFF.G4_Rev_buftmp + 1;
        }
        else if(LCD_Data_BUFF.G4_Rev_buftmp == 2)
        {
            LCD_Data_BUFF.G4_Rev_buftmp++;
        }
        else if(LCD_Data_BUFF.G4_Rev_buftmp == 3)
        {
            LCD_Data_BUFF.G4_Rev_buftmp = (res != (u8)(0x83)) ? 0 : LCD_Data_BUFF.G4_Rev_buftmp + 1;
        }
        else if(LCD_Data_BUFF.G4_Rev_buftmp > 3)
        {
            LCD_Data_BUFF.G4_Rev_buftmp++;

            if(LCD_Data_BUFF.G4_Rev_buftmp == (LCD_Data_BUFF.G4_Rev_buf[2] + 3)) //����һ֡����
            {

                LCD_Data_BUFF.G4_Rev_buftmp = 0;  //������������
                LCD_Data_BUFF.G4_Rev_start = 1;  //һ����֡�������


            }


        }




















        /*ŵ΢�����ж�*/
        gps_buf.gps_Rev_buf[gps_buf.gps_Rev_buftmp] = res;

        if(gps_buf.gps_Rev_buftmp == 0)	    //�ж�֡ͷ
        {
            gps_buf.gps_Rev_buftmp = (res != (u8)(START_FRAME >> 8)) ? 0 : gps_buf.gps_Rev_buftmp + 1;
        }
        else if(gps_buf.gps_Rev_buftmp == 1)
        {
            gps_buf.gps_Rev_buftmp = (res != (u8)(START_FRAME)) ? 0 : gps_buf.gps_Rev_buftmp + 1;
        }
        else if(gps_buf.gps_Rev_buftmp == 2)	gps_buf.gps_Rev_buftmp++;
        else if(gps_buf.gps_Rev_buftmp == 3)
        {
            UartDataMsCntEnable = 1;
            gps_buf.gps_Rev_buftmp++;
            GpsDataLenTemp = gps_buf.gps_Rev_buf[2] << 8;
            GpsDataLenTemp = GpsDataLenTemp | gps_buf.gps_Rev_buf[3];

            if( GpsDataLenTemp >= 300 ) //���ݳ��ȳ���ָ����󳤶�
            {

                GpsDataLenTemp = 0;
                UartDataMsCnt = 0;
                UartDataMsCntEnable = 0;
                gps_buf.gps_Rev_buftmp = 0;
                memset(gps_buf.gps_Rev_buf, 0, sizeof(gps_buf.gps_Rev_buf));
            }
        }
        else if(gps_buf.gps_Rev_buftmp >= 4)
        {
            gps_buf.gps_Rev_buftmp++;

            if(gps_buf.gps_Rev_buftmp == ( (gps_buf.gps_Rev_buf[2] << 8) | gps_buf.gps_Rev_buf[3]) + 2) //����һ֡����
            {
                if(gps_buf.gps_Rev_buf[gps_buf.gps_Rev_buftmp - 4 - 1] == END_FRAME)
                {
                    gps_buf.gps_Rev_buftmp = 0;  //������������
                    gps_buf.gps_Rev_start = 1;   //һ����֡�������
                    Uart1NWDataFlag = 1; //UART1  NW����
                    GpsHaveDateFlag = 1;
                    UartDataMsCnt = 0;
                    UartDataMsCntEnable = 0;
                }
                else
                {
                    gps_buf.gps_Rev_buftmp = 0;  //������������
                    UartDataMsCnt = 0;
                    UartDataMsCntEnable = 0;
                    memset(gps_buf.gps_Rev_buf, 0, sizeof(gps_buf.gps_Rev_buf));
                }
            }
        }

    }
}

void USART2_IRQHandler(void)
{
    u8 res;
    u16 temp = 0;
    u16 GpsDataLenTemp = 0;


    if(USART_GetFlagStatus(USART2, USART_FLAG_ORE) != RESET)
    {
        temp = USART2->SR;
        res = USART2->DR;
        res = USART_ReceiveData(USART2);
        USART_ClearFlag(USART2, USART_FLAG_ORE);
    }

    if(USART_GetFlagStatus(USART2, USART_FLAG_NE) != RESET)
    {
        temp = USART2->SR;
        res = USART2->DR;
        USART_ClearFlag(USART2, USART_FLAG_NE);
    }

    if(USART_GetFlagStatus(USART2, USART_FLAG_FE) != RESET)
    {
        temp = USART2->SR;
        res = USART2->DR;
        USART_ClearFlag(USART2, USART_FLAG_FE);

    }

    if(USART_GetFlagStatus(USART2, USART_FLAG_PE) != RESET)
    {
        temp = USART2->SR;
        res = USART2->DR;
        USART_ClearFlag(USART2, USART_FLAG_PE);

    }

    if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(USART2, USART_IT_RXNE); //����жϱ�־.
        res = USART2->DR;



        /*ŵ΢�����ж�*/
        gps_buf_2.gps_Rev_buf[gps_buf_2.gps_Rev_buftmp] = res;

        if(gps_buf_2.gps_Rev_buftmp == 0)	    //�ж�֡ͷ
        {
            gps_buf_2.gps_Rev_buftmp = (res != (u8)(START_FRAME >> 8)) ? 0 : gps_buf_2.gps_Rev_buftmp + 1;
        }
        else if(gps_buf_2.gps_Rev_buftmp == 1)
        {
            gps_buf_2.gps_Rev_buftmp = (res != (u8)(START_FRAME)) ? 0 : gps_buf_2.gps_Rev_buftmp + 1;
        }
        else if(gps_buf_2.gps_Rev_buftmp == 2)	gps_buf_2.gps_Rev_buftmp++;
        else if(gps_buf_2.gps_Rev_buftmp == 3)
        {
            UartDataMsCntEnable2 = 1;
            gps_buf_2.gps_Rev_buftmp++;
            GpsDataLenTemp = gps_buf_2.gps_Rev_buf[2] << 8;
            GpsDataLenTemp = GpsDataLenTemp | gps_buf_2.gps_Rev_buf[3];

            if( GpsDataLenTemp >= 300 ) //���ݳ��ȳ���ָ����󳤶�
            {

                GpsDataLenTemp = 0;
                gps_buf_2.gps_Rev_buftmp = 0;
                UartDataMsCntEnable2 = 0;
                UartDataMsCnt2 = 0;
                memset(gps_buf_2.gps_Rev_buf, 0, sizeof(gps_buf_2.gps_Rev_buf));
            }
        }
        else if(gps_buf_2.gps_Rev_buftmp >= 4)
        {
            gps_buf_2.gps_Rev_buftmp++;

            if(gps_buf_2.gps_Rev_buftmp == ((gps_buf_2.gps_Rev_buf[2] << 8) | gps_buf_2.gps_Rev_buf[3]) + 2) //����һ֡����
            {
                if(gps_buf_2.gps_Rev_buf[gps_buf_2.gps_Rev_buftmp - 4 - 1] == END_FRAME)
                {
                    gps_buf_2.gps_Rev_buftmp = 0;  //������������
                    gps_buf_2.gps_Rev_start = 1;   //һ����֡�������
                    Uart2NWDataFlag = 1; //UART2  NW����
                    // GpsHaveDateFlag = 1;
                    UartDataMsCntEnable2 = 0;
                    UartDataMsCnt2 = 0;
                }
                else
                {
                    gps_buf_2.gps_Rev_buftmp = 0;  //������������
                    UartDataMsCntEnable2 = 0;
                    UartDataMsCnt2 = 0;
                    memset(gps_buf_2.gps_Rev_buf, 0, sizeof(gps_buf_2.gps_Rev_buf));
                }
            }
        }
    }
}

void USART3_IRQHandler(void)
{
    u8 res;
    u16 JDY33_DataLenTemp = 0;
    u32 temp = 0;

    if(USART_GetFlagStatus(USART3, USART_FLAG_ORE) != RESET)
    {
        temp = USART3->SR;
        temp = USART3->DR;
        USART_ClearFlag(USART3, USART_FLAG_ORE);

    }

    if(USART_GetFlagStatus(USART3, USART_FLAG_NE) != RESET)
    {
        temp = USART3->SR;
        temp = USART3->DR;
        USART_ClearFlag(USART3, USART_FLAG_NE);

    }

    if(USART_GetFlagStatus(USART3, USART_FLAG_FE) != RESET)
    {
        temp = USART3->SR;
        temp = USART3->DR;
        USART_ClearFlag(USART3, USART_FLAG_FE);

    }

    if(USART_GetFlagStatus(USART3, USART_FLAG_PE) != RESET)
    {
        temp = USART3->SR;
        temp = USART3->DR;
        USART_ClearFlag(USART3, USART_FLAG_PE);

    }

    if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(USART3, USART_IT_RXNE); //����жϱ�־.
        res = USART3->DR;

        /*ŵ΢�����ж�*/
        JDY33_buf.gps_Rev_buf[JDY33_buf.gps_Rev_buftmp] = res;

        if(JDY33_buf.gps_Rev_buftmp == 0)	    //�ж�4E֡ͷ
        {
            JDY33_buf.gps_Rev_buftmp = (res != (u8)(START_FRAME >> 8)) ? 0 : JDY33_buf.gps_Rev_buftmp + 1;
        }
        else if(JDY33_buf.gps_Rev_buftmp == 1)//57
        {
            JDY33_buf.gps_Rev_buftmp = (res != (u8)(START_FRAME)) ? 0 : JDY33_buf.gps_Rev_buftmp + 1;
        }
        else if(JDY33_buf.gps_Rev_buftmp == 2)	JDY33_buf.gps_Rev_buftmp++;
        else if(JDY33_buf.gps_Rev_buftmp == 3)
        {
            UartDataMsCntEnable3 = 1;
            JDY33_buf.gps_Rev_buftmp++;
            JDY33_DataLenTemp = JDY33_buf.gps_Rev_buf[2] << 8;
            JDY33_DataLenTemp = JDY33_DataLenTemp | JDY33_buf.gps_Rev_buf[3];

            if( JDY33_DataLenTemp >= 300 ) //���ݳ��ȳ���ָ����󳤶�
            {
                JDY33_DataLenTemp = 0;
                UartDataMsCnt3 = 0;
                UartDataMsCntEnable3 = 0;
                JDY33_buf.gps_Rev_buftmp = 0;
                memset(JDY33_buf.gps_Rev_buf, 0, sizeof(JDY33_buf.gps_Rev_buf));
            }
        }
        else if(JDY33_buf.gps_Rev_buftmp >= 4)
        {
            JDY33_buf.gps_Rev_buftmp++;

            if(JDY33_buf.gps_Rev_buftmp == ( (JDY33_buf.gps_Rev_buf[2] << 8) | JDY33_buf.gps_Rev_buf[3]) + 2) //����һ֡����
            {
                if(JDY33_buf.gps_Rev_buf[JDY33_buf.gps_Rev_buftmp - 4 - 1] == END_FRAME)
                {
                    JDY33_buf.gps_Rev_buftmp = 0;  //������������
                    JDY33_buf.gps_Rev_start = 1;   //һ����֡�������
                    Uart3NWDataFlag = 1; //UART3  NW����
                    //  GpsHaveDateFlag = 1;
                    UartDataMsCnt3 = 0;
                    UartDataMsCntEnable3 = 0;
                }
                else
                {
                    JDY33_buf.gps_Rev_buftmp = 0;  //������������
                    UartDataMsCnt3 = 0;
                    UartDataMsCntEnable3 = 0;
                    memset(JDY33_buf.gps_Rev_buf, 0, sizeof(JDY33_buf.gps_Rev_buf));
                }
            }
        }


    }
}



/*��ʱ�����ڴ���*/
void TIM2_IRQHandler(void)
{
    if(TIM2->SR & TIM_IT_Update)
    {
        extern unsigned long int globalTime2;//��ʱ��������
        extern int globalTime; //��ʱ�ص���������

        static int cun = 0;
        static int cun_2 = 0;
        static bool Led_flag = 0;
        static bool Led1_flag = 0;

        static bool Led1_updata_flag = 0;
        static int cun_updata = 0;


        static u32 indexcut = 0;
        static u16 count_ms = 0;
        static u32 dahuo_ms = 0;
        static u32 SOC_Count_ms = 0;
        static u32 start500_count = 0;
        static u32 start1000_count = 0;
        u8 i;
        static u8 timecount = 0;
        static u32 Logain_ms = 0;

        if(g_SysMilliSecCnt++ >= 65535)
            g_SysMilliSecCnt = 0;
        else
            g_SysMilliSecCnt = 0;


        if(Login_Flag == 1)
        {
            Logain_ms++;

            if(Logain_ms > 180000) //3����
            {
                Logain_ms = 0;
                Login_Flag = 0;
                Login_TimeFlag = 1;

            }



        }

        count_ms++;

        if(start500_flag == 1)
        {
            start500_count++;

            if(start500_count >= 500)
            {
                end500_flag = 1;
                start500_count = 0;

            }


        }


        if(start1000_flag == 1)
        {
            start1000_count++;

            if(start1000_count >= 1000)
            {
                end1000_flag = 1;
                start1000_count = 0;


            }


        }







        if(UartDataMsCntEnable == 1)
        {
            if( (UartDataMsCnt++) > 5000 )
            {
                UartDataMsCnt = 0;
                UartDataMsCntEnable = 0;
                gps_buf.gps_Rev_buftmp = 0;

            }
        }

        if(UartDataTTCntEnable2 == 1)//485 ��������ͨ�ŵ���ͨ�� �������
        {
            if( (UartDataTTCnt++) > 3000 )
            {
                UartDataTTCnt = 0;
                UartDataTTCntEnable2 = 0;
                dahuo_flag = 1;

            }
        }



        if(UartDataMsCntEnable2 == 1)
        {
            if( (UartDataMsCnt2++) > 5000 )
            {
                UartDataMsCnt2 = 0;
                UartDataMsCntEnable2 = 0;
                gps_buf_2.gps_Rev_buftmp = 0;

            }
        }

        if(UartDataMsCntEnable3 == 1)
        {
            if( (UartDataMsCnt3++) > 5000 )
            {
                UartDataMsCnt3 = 0;
                UartDataMsCntEnable3 = 0;
                JDY33_buf.gps_Rev_buftmp = 0;

            }
        }






        if(count_ms >= 1000)
        {
            count_ms = 0;
            Init_SOC_8S++;

            if(Init_SOC_8S >= 8)
            {

                Init_SOC_8S_flag = 1;
                Init_SOC_8S = 0;

            }

            for(i = 0; i < 32; i++)
            {
                if(Vol4180_Over_time.bits_4180[i])
                    Vol4180_Over_time.bits_4180_cont_s[i]++;

                if(Vol3500_Over_time.bits_3500[i])
                    Vol3500_Over_time.bits_3500_cont_s[i]++;

            }

            for(i = 0; i < 32; i++)
            {
                if(Over_time.bits_1[i])
                    Over_time.bits_1_cont_s[i]++;

                if(Over_time.bits_2[i])
                    Over_time.bits_2_cont_s[i]++;

                if(Over_time.bits_11[i])
                    Over_time.bits_11_cont_s[i]++;
            }

            if(Over_time.bits_3)
                Over_time.bits_3_cont_s++;

            if(Over_time.bits_4)
                Over_time.bits_4_cont_s++;

            if(Over_time.bits_3_2)
                Over_time.bits_3_2_cont_s++;

            if(Over_time.bits_4_2)
                Over_time.bits_4_2_cont_s++;
        }

        globalTime++;
        globalTime2 ++;
        Jdybuffs.Jdy_globalTime++;

        cun++;
        cun_2++;
        cun_updata++;

        indexcut ++;



        if(LED_2_bit == 3)
        {
            if(cun >= 125)
            {
                cun = 0;
                Led_flag = !Led_flag;
            }
        }
        else if(LED_2_bit == 2)
        {
            if(cun >= 1000)
            {
                cun = 0;
                Led_flag = !Led_flag;
            }
        }
        else if(LED_2_bit == 1)
        {
            if(cun >= 3000)
            {
                cun = 0;
                Led_flag = !Led_flag;
            }
        }

        if(LED_2_bit != 0)
        {
            if(Led_flag)
            {
                RESETIO(LED_2);
            }
            else
            {
                SETIO(LED_2);
            }
        }

        //-----------------------------------
        if(LED_1_bit == 3)
        {
            if(cun_2 >= 250)
            {
                cun_2 = 0;
                Led1_flag = !Led1_flag;
            }
        }
        else if(LED_1_bit == 2 )
        {
            if(cun_2 >= 500)
            {
                cun_2 = 0;
                Led1_flag = !Led1_flag;
            }
        }
        else if(LED_1_bit == 1)
        {
            if(cun_2 >= 1000)
            {
                cun_2 = 0;
                Led1_flag = !Led1_flag;
            }
        }

        if(LED_1_bit != 0)
        {
            if(Led1_flag == 0)
            {
                RESETIO(LED_1);
            }
            else
            {
                SETIO(LED_1);
            }
        }

        if(LED_1_bit == 0)
        {
            SETIO(LED_1);
        }

        //////////////////////////////////////////////////////////

        if(indexcut >= 60000)
        {
            indexcut = 0;
            timecount++;

            if(timecount >= 60)
            {
                timecount = 0;
                gps_data.RevWrite_data.SysTime ++; //ϵͳ����ʱ�� ��λ��Сʱ
            }
        }

        TIM2->SR &= (~TIM_IT_Update);
    }
}


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
