#include "stm32f10x.h"
#include "stm32f10x_conf.h"

#include "usart.h"
#include "delay.h"
#include "485.h"

#include "stdio.h"
#include "string.h"

#include "gpsnet.h"
#include "flash.h"
#include "gpioinit.h"
#include "datahand.h"
#include "IIc.h"
#include "Jdy_19.h"
#include "iobind.h"
#include "SH367309.h"

#include "LCD.h"

G4_Buf   LCD_Data_BUFF = {0}; //���մ���������
G4_Buf   SIF_Data_BUFF = {0}; //���մ���������

u8 LCD_Data[1024] = {0};
u16 Count_I = 0;
u8 Alarm_Count = 0;
u8 LCD_Buff_GLoa[30] = {0};
u8 LCD_User_Pass[3] = {0x02, 0x00, 0x00};
u8 LCD_PassWord[3] = {0x00, 0x00, 0x00};
u8 Login_Flag = 0;
u8 Login_TimeFlag = 0;
unsigned char Ye[7] = {0xA5, 0x5A, 0x04, 0x80, 0x03, 0x00, 0x01};
unsigned char YeError[7] = {0xA5, 0x5A, 0x04, 0x80, 0x03, 0x00, 0x07};

u8	LCD_num_sconf = 0;
u8	LCD_SetACanshu = 0;

void LCD_Write()
{
    u8 i = 0;
    u8 Adress = 0;
    u32 shengyu = 0;
    u32 shengyu2 = 0;
    u16 Current_P = 0;
    s16 Current_N = 0;
    u16 Power_Cur = 0;
    u16 Power_Car = 0;
    u8 Stu_Flag = 0;
    Count_I = 0;

    memset(LCD_Data, 0, sizeof(LCD_Data)); //��������


    //BT��
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x1B; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_BT_Adress >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_BT_Adress); //��ַ��λ

    Count_I++;
    memcpy(&LCD_Data[Count_I], gps_data.RevWrite_data.XID, 24);

    Count_I = Count_I + 24;


    //���MOS״̬
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x06; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Chg_Mos_Adress >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Chg_Mos_Adress); //��ַ��λ

    Count_I++;

    if(gps_data.Rev_data.CellStrtu & 0x0001) //ON
    {
        LCD_Data[Count_I] = 0x4F;
        Count_I++;
        LCD_Data[Count_I] = 0x4E;
        Count_I++;
        LCD_Data[Count_I] = 0x20;
        Count_I++;
    }
    else
    {
        LCD_Data[Count_I] = 0x4F;
        Count_I++;
        LCD_Data[Count_I] = 0x46;
        Count_I++;
        LCD_Data[Count_I] = 0x46;
        Count_I++;

    }


    //�ŵ�MOS״̬
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x06; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Dsg_Mos_Adress >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Dsg_Mos_Adress); //��ַ��λ

    Count_I++;


    if(gps_data.Rev_data.CellStrtu & 0x0002) //ON
    {
        LCD_Data[Count_I] = 0x4F;
        Count_I++;
        LCD_Data[Count_I] = 0x4E;
        Count_I++;
        LCD_Data[Count_I] = 0x20;
        Count_I++;
    }
    else
    {
        LCD_Data[Count_I] = 0x4F;
        Count_I++;
        LCD_Data[Count_I] = 0x46;
        Count_I++;
        LCD_Data[Count_I] = 0x46;
        Count_I++;

    }

    //����״̬
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x06; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Junhen_Mos_Adress >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Junhen_Mos_Adress); //��ַ��λ

    Count_I++;


    if(gps_data.Rev_data.CellStrtu & 0x0004) //ON
    {
        LCD_Data[Count_I] = 0x4F;
        Count_I++;
        LCD_Data[Count_I] = 0x4E;
        Count_I++;
        LCD_Data[Count_I] = 0x20;
        Count_I++;
    }
    else
    {
        LCD_Data[Count_I] = 0x4F;
        Count_I++;
        LCD_Data[Count_I] = 0x46;
        Count_I++;
        LCD_Data[Count_I] = 0x46;
        Count_I++;

    }


    //ÿһ����ѹ
    for(i = 0; i < 16; i++)
    {
        //��ѹ
        LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
        Count_I++;

        LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

        Count_I++;
        LCD_Data[Count_I] = 0x05; //���ݳ���

        Count_I++;
        LCD_Data[Count_I] = LCD_WriteOrder; //����

        Count_I++;
        LCD_Data[Count_I] = (u8)((LCD_Cell1_Adress + Adress) >> 8); //��ַ��λ

        Count_I++;
        LCD_Data[Count_I] = (u8)(LCD_Cell1_Adress + Adress); //��ַ��λ
        Count_I++;

        LCD_Data[Count_I] = gps_data.Rev_data.Singcellvol[i][1];
        Count_I++;
        LCD_Data[Count_I] = gps_data.Rev_data.Singcellvol[i][2];
        Count_I++;
        Adress = Adress + 2;
    }

    //��ش���

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Cell_Num_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Cell_Num_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.Rev_data.CellZnum >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)gps_data.Rev_data.CellZnum;
    Count_I++;

    //�������

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Cell_Type_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Cell_Type_Adress); //��ַ��λ
    Count_I++;

    if(gps_data.RevWrite_data.Celltype == 0)
    {
        LCD_Data[Count_I] = (u8)(0);
        Count_I++;
        LCD_Data[Count_I] = 0x02;
        Count_I++;

    }

    else if(gps_data.RevWrite_data.Celltype == 1)
    {
        LCD_Data[Count_I] = (u8)(0);
        Count_I++;
        LCD_Data[Count_I] = 0x01;
        Count_I++;

    }
    else if(gps_data.RevWrite_data.Celltype == 2)
    {

        LCD_Data[Count_I] = (u8)(0);
        Count_I++;
        LCD_Data[Count_I] = 0x03;
        Count_I++;
    }

    //SOC����

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x07; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SOC_TXT) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SOC_TXT); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x53;
    Count_I++;
    LCD_Data[Count_I] = 0x4F;
    Count_I++;
    LCD_Data[Count_I] = 0x43;
    Count_I++;
    LCD_Data[Count_I] = 0x3A;
    Count_I++;

    //%

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x04; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SOC_DW) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SOC_DW); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x25;
    Count_I++;




    //��ߵ�ѹ

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_MaxVol_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_MaxVol_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(cell_vol_max >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)cell_vol_max;
    Count_I++;


//��͵�ѹ

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_MinVol_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_MinVol_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(cell_vol_min >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)cell_vol_min;
    Count_I++;


//ѹ��

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_VolCha_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_VolCha_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)((cell_vol_max - cell_vol_min) >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(cell_vol_max - cell_vol_min);
    Count_I++;

//�����¶�

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_TempIN_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_TempIN_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)((Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp) >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp);
    Count_I++;


//����¶�

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_TempCell_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_TempCell_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)((Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp) >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp);
    Count_I++;

    //MOS�¶�

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_TempMOS_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_TempMOS_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)((Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp) >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp);
    Count_I++;

    //ʪ��

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_TempHum_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_TempHum_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ShiduValueNow);
    Count_I++;



    //SOH

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SOH_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SOH_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(Bms_tt_data.Anal_quanuion.Anal_quan.SOH >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(Bms_tt_data.Anal_quanuion.Anal_quan.SOH);
    Count_I++;


    //SOC
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SOC_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SOC_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.Rev_data.Soc);
    Count_I++;


    //�������

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Sta_long_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Sta_long_Adress); //��ַ��λ
    Count_I++;
    LCD_Data[Count_I] = (u8)((gps_data.RevWrite_data.CellRl * 10) >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellRl * 10);
    Count_I++;


    //ʣ������

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Shengyu_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Shengyu_Adress); //��ַ��λ
    Count_I++;
    shengyu = (gps_data.Rev_data.Soc) * gps_data.RevWrite_data.CellRl;
    shengyu2 = shengyu / 10;
    LCD_Data[Count_I] = (u8)(shengyu2 >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(shengyu2);
    Count_I++;







    //ѭ������

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CirTime_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CirTime_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.Rev_data.Cellusnum >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.Rev_data.Cellusnum);
    Count_I++;


    //��ѹ

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Vol_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Vol_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.Rev_data.CellZvol >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.Rev_data.CellZvol);
    Count_I++;



    //��ǰ����
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Cell_Current_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Cell_Current_Adress); //��ַ��λ
    Count_I++;

    if(gps_data.Rev_data.Currdata > 10000)//�ŵ�
    {
        Stu_Flag = 2;//�ŵ�
        Current_N = (10000 - gps_data.Rev_data.Currdata) / 10;
        Power_Cur = (gps_data.Rev_data.Currdata - 10000) / 100;
        LCD_Data[Count_I] = (u8)(Current_N >> 8);
        Count_I++;
        LCD_Data[Count_I] = (u8)(Current_N);
        Count_I++;



    }
    else if(gps_data.Rev_data.Currdata == 10000)
    {
        Stu_Flag = 3;//��ֹ
        Current_N = 0;
        Power_Cur = 0;
        LCD_Data[Count_I] = (u8)(Current_N >> 8);
        Count_I++;
        LCD_Data[Count_I] = (u8)(Current_N);
        Count_I++;

    }
    else if(gps_data.Rev_data.Currdata < 10000)//���
    {
        Stu_Flag = 1;//���
        Current_P = (10000 - gps_data.Rev_data.Currdata) / 10;
        Power_Cur = (10000 - gps_data.Rev_data.Currdata) / 100;
        LCD_Data[Count_I] = (u8)(Current_P >> 8);
        Count_I++;
        LCD_Data[Count_I] = (u8)(Current_P);
        Count_I++;


    }

    //��ǰ״̬
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Chg_DSG_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Chg_DSG_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(0);
    Count_I++;
    LCD_Data[Count_I] = (u8)(Stu_Flag);
    Count_I++;




    //����

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Power_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Power_Adress); //��ַ��λ
    Count_I++;

    Power_Car = Power_Cur * (gps_data.Rev_data.CellZvol / 100) / 10;

    LCD_Data[Count_I] = (u8)(Power_Car >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(Power_Car);
    Count_I++;



    //����1

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Cell_Alam1_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Cell_Alam1_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;

    if(gps_data.Rev_data.CellhitData & 0x0001 && Alarm_Count == 0)
    {
        LCD_Data[Count_I] = 0x01;
        Count_I++;
    }
    else if(gps_data.Rev_data.CellhitData & 0x0002 && Alarm_Count == 1)
    {
        LCD_Data[Count_I] = 0x02;
        Count_I++;
    }
    else if(gps_data.Rev_data.CellhitData & 0x0010 && Alarm_Count == 2)
    {
        LCD_Data[Count_I] = 0x03;
        Count_I++;
    }
    else if(gps_data.Rev_data.CellhitData & 0x0100 && Alarm_Count == 3)
    {
        LCD_Data[Count_I] = 0x04;
        Count_I++;
    }
    else
    {
        LCD_Data[Count_I] = 0x00;
        Count_I++;

    }



    //����2

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Cell_Alam2_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Cell_Alam2_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;

    if(gps_data.Rev_data.CellhitData & 0x0004 && Alarm_Count == 0)
    {
        LCD_Data[Count_I] = 0x01;
        Count_I++;
    }
    else if(gps_data.Rev_data.CellhitData & 0x0008 && Alarm_Count == 1)
    {
        LCD_Data[Count_I] = 0x02;
        Count_I++;
    }
    else if(gps_data.Rev_data.CellhitData & 0x0200 && Alarm_Count == 2)
    {
        LCD_Data[Count_I] = 0x03;
        Count_I++;
    }

    else if(gps_data.Rev_data.CellhitData & 0x0080 && Alarm_Count == 3)
    {
        LCD_Data[Count_I] = 0x04;
        Count_I++;
    }
    else
    {
        LCD_Data[Count_I] = 0x00;
        Count_I++;

    }










    //����3

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Cell_Alam3_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Cell_Alam3_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;

    if(gps_data.Rev_data.CellhitData & 0x0020 && Alarm_Count == 0)
    {
        LCD_Data[Count_I] = 0x01;
        Count_I++;
    }

    else if(gps_data.Rev_data.CellhitData & 0x0040 && Alarm_Count == 1)
    {
        LCD_Data[Count_I] = 0x02;
        Count_I++;
    }

    else if(gps_data.Rev_data.CellhitData & 0x0C00 && Alarm_Count == 2)
    {
        LCD_Data[Count_I] = 0x03;
        Count_I++;
    }
    else if(gps_data.Rev_data.CellhitData & 0x0C00 && Alarm_Count == 4)
    {
        LCD_Data[Count_I] = 0x03;
        Count_I++;
    }
    else
    {
        LCD_Data[Count_I] = 0x00;
        Count_I++;

    }


    //����4

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_Cell_Alam4_Adress) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Cell_Alam4_Adress); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;

    if(gps_data.Rev_data.CellhitData & 0x0400 && Alarm_Count == 0)
    {
        LCD_Data[Count_I] = 0x01;
        Count_I++;

    }

    else if(gps_data.Rev_data.CellhitData & 0x0800 && Alarm_Count == 1)
    {
        LCD_Data[Count_I] = 0x02;
        Count_I++;

    }

    else if(gps_data.Rev_data.CellhitData & 0x4000 && Alarm_Count == 2)
    {
        LCD_Data[Count_I] = 0x03;
        Count_I++;

    }
    else if(gps_data.Rev_data.CellhitData & 0x4000 && Alarm_Count == 3)
    {
        LCD_Data[Count_I] = 0x03;
        Count_I++;

    }
    else
    {
        LCD_Data[Count_I] = 0x00;
        Count_I++;

    }



    //�ܵ�ѹ��ѹ����

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_ZVOL_G) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_ZVOL_G); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ZvolG >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ZvolG);
    Count_I++;

    //�ܵ�ѹǷѹ����

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_ZVOL_Q) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_ZVOL_Q); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ZvolQ >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ZvolQ);
    Count_I++;


    //�����ѹ����ֵ

    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SINGVOL_G) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SINGVOL_G); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolG >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolG);
    Count_I++;


    //�����ѹ�ָ�ֵ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SINGVOL_GH) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SINGVOL_GH); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolGH >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolGH);
    Count_I++;


    //�����ѹ��ʱ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SINGOVERTIME_G) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SINGOVERTIME_G); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolGtime >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolGtime);
    Count_I++;


    //����Ƿѹ����ֵ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SINGVOL_Q) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SINGVOL_Q); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolQ >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolQ);
    Count_I++;

    //����Ƿѹ�ָ�
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SINGVOL_QH) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SINGVOL_QH); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolQH >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolQH);
    Count_I++;


    //����Ƿѹ��ʱ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SINGOVERTIME_Q) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SINGOVERTIME_Q); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolQtime >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SingvolQtime);
    Count_I++;

    //��оѹ��
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CELLXCB) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CELLXCB); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellXyc >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellXyc);
    Count_I++;

    //�ŵ����
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_OUTCHGCURR_G) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_OUTCHGCURR_G); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.OutcurrG >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.OutcurrG);
    Count_I++;

    //�ŵ������ʱ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_OUTCURRTIME_G) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_OUTCURRTIME_G); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.OutcurrGtime >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.OutcurrGtime);
    Count_I++;

    //������
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CHGCURR_G) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CHGCURR_G); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ChgcurrG >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ChgcurrG);
    Count_I++;



    //��������ʱ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CHGCURRTIME_G) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CHGCURRTIME_G); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ChgcurrGtime >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ChgcurrGtime);
    Count_I++;

    //����������ѹ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_EQUALIONVOL) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_EQUALIONVOL); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Equalivol >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Equalivol);
    Count_I++;

    //���⿪��ѹ��
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_EQUALIVOLC) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_EQUALIVOLC); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Equalivolcc >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Equalivolcc);
    Count_I++;


    //���⿪��
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_EQUALIOPEN) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_EQUALIOPEN); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.EqualiON);
    Count_I++;

    //��·����
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SHORT_CUR_VALUE) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SHORT_CUR_VALUE); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ShortCurValue);
    Count_I++;


    //��·��ʱ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SHORT_CUR_DELAY) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SHORT_CUR_DELAY); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ShortCurDelay >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ShortCurDelay);
    Count_I++;

    //GPS�����ѹ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_GPSDVOL) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_GPSDVOL); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.GpsDVol >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.GpsDVol);
    Count_I++;

    //GPS�ָ���ѹ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_GPSDVOLH) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_GPSDVOLH); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.GpsDVolH >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.GpsDVolH);
    Count_I++;

    //���ʹ��¶ȱ���ֵ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_POWTMPPORT) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_POWTMPPORT); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.PowTmp >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.PowTmp);
    Count_I++;

    //���ʹ��¶Ȼָ�ֵ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_POWTMPHH) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_POWTMPHH); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.PowTmpH >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.PowTmpH);
    Count_I++;


    //�����¶�
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_INTEMPTER) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_INTEMPTER); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Equaltmpb >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Equaltmpb);
    Count_I++;

    //�����¶Ȼָ�
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_INTEMPTERRE) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_INTEMPTERRE); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.EqualtmpH >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.EqualtmpH);
    Count_I++;

    //����²��
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CELLTMOPORT) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CELLTMOPORT); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellTmp >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellTmp);
    Count_I++;


    //ʪ�ȱ�����ֵ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SIDU_PROTECT_VALUE) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SIDU_PROTECT_VALUE); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ShiduValueProtect);
    Count_I++;

    //ʪ�ȱ�������
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_SIDU_KAIGUAN) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SIDU_KAIGUAN); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ShiduKaiguan);
    Count_I++;


    //��س�����
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CHGGTMPPORT) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CHGGTMPPORT); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellChgTmpG >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellChgTmpG);
    Count_I++;


    //��طŵ����
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_OUTGTMPPORT) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_OUTGTMPPORT); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellOutTmpG >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellOutTmpG);
    Count_I++;

    //��س�����
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CHGDTMPPORT) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CHGDTMPPORT); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ChgTmpD >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ChgTmpD);
    Count_I++;

    //��س����±���
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CHGDTMPPORTHH) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CHGDTMPPORTHH); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ChgTmpDH >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ChgTmpDH);
    Count_I++;


    //��طŵ����
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_OUTCHGDTMPPORT) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_OUTCHGDTMPPORT); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.OutTmpD >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.OutTmpD);
    Count_I++;

    //��طŵ���»ָ�
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_OUTCHGDTMPHH) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_OUTCHGDTMPHH); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.OutTmpDH >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.OutTmpDH);
    Count_I++;

    //��ش�������
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CELLNUM) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CELLNUM); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Cellnum >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Cellnum);
    Count_I++;

    //��ر������
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CELLRLS) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CELLRLS); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellRl >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CellRl);
    Count_I++;

    //�������
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;
    LCD_Data[Count_I] = (u8)((LCD_CELLTYPE) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CELLTYPE); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Celltype);
    Count_I++;

    //���ʵ������
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_Reali_Q) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_Reali_Q); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Reali_Q >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.Reali_Q);
    Count_I++;


    //���MOS����
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_CHGMOSKG) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CHGMOSKG); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ChgMOS);
    Count_I++;

    //�ŵ�MOS����
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_OUTMOSKG) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_OUTMOSKG); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.OutMOS);
    Count_I++;

    //�Ƿ���������У׼
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;


    LCD_Data[Count_I] = (u8)((LCD_CURRSwitch) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CURRSwitch); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CurrjzONOFF);
    Count_I++;

    //����У׼ֵ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_CURRBZ) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_CURRBZ); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CurrJZ >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.CurrJZ);
    Count_I++;

    //�������ַ
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_BFBADRR) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_BFBADRR); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.BHBAddr);
    Count_I++;

    //���ߵȴ�ʱ��
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_SLEEPTIME) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SLEEPTIME); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SleepTime >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SleepTime);
    Count_I++;


    //���ݱ���
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_DRLBEEP) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_DRLBEEP); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.DRLNum);
    Count_I++;

    //�޸�����
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x0D; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_SDATAPASS) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SDATAPASS); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = gps_data.RevWrite_data.Pass[0];
    Count_I++;
    LCD_Data[Count_I] = gps_data.RevWrite_data.Pass[1];
    Count_I++;
    LCD_Data[Count_I] = gps_data.RevWrite_data.Pass[2];
    Count_I++;
    LCD_Data[Count_I] = gps_data.RevWrite_data.Pass[3];
    Count_I++;
    LCD_Data[Count_I] = gps_data.RevWrite_data.Pass[4];
    Count_I++;
    LCD_Data[Count_I] = gps_data.RevWrite_data.Pass[5];
    Count_I++;
    LCD_Data[Count_I] = gps_data.RevWrite_data.Pass[6];
    Count_I++;
    LCD_Data[Count_I] = gps_data.RevWrite_data.Pass[7];
    Count_I++;
    LCD_Data[Count_I] = gps_data.RevWrite_data.Pass[8];
    Count_I++;
    LCD_Data[Count_I] = gps_data.RevWrite_data.Pass[9];
    Count_I++;



    //ϵͳ����ʱ��
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x07; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_SysTime) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SysTime); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SysTime >> 24);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SysTime >> 16);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SysTime >> 8);
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.SysTime);
    Count_I++;



    //�����汾��
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x12; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_SOFT_NUM) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_SOFT_NUM); //��ַ��λ
    Count_I++;

    LCD_Data[Count_I] = soft_num_ZF[0];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[1];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[2];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[3];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[4];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[5];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[6];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[7];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[8];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[9];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[10];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[11];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[12];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[13];
    Count_I++;
    LCD_Data[Count_I] = soft_num_ZF[14];
    Count_I++;

    //ר�ó��������
    LCD_Data[Count_I] = (u8)(LCD_HAND >> 8); //ͷ��λ
    Count_I++;

    LCD_Data[Count_I] = (u8)(LCD_HAND); //ͷ��λ

    Count_I++;
    LCD_Data[Count_I] = 0x05; //���ݳ���

    Count_I++;
    LCD_Data[Count_I] = LCD_WriteOrder; //����

    Count_I++;

    LCD_Data[Count_I] = (u8)((LCD_ZCHGKG) >> 8); //��ַ��λ

    Count_I++;
    LCD_Data[Count_I] = (u8)(LCD_ZCHGKG); //��ַ��λ
    Count_I++;
    LCD_Data[Count_I] = 0x00;
    Count_I++;
    LCD_Data[Count_I] = (u8)(gps_data.RevWrite_data.ZChgON);
    Count_I++;


    //
    Alarm_Count++;

    if(Alarm_Count == 4)
    {
        Alarm_Count = 0;
    }

    //��������

    Send_TString_LCD(LCD_Data, Count_I);

}


void LCD_DataHandle(void)
{

    u16 start_addr = 0;  //��ʼ��ַ
    u16 datasss = 0;
    u16 i = 0;
    u8 order = 0;

    /*����һ֡���ĳɹ�*/
    if(LCD_Data_BUFF.G4_Rev_start == 1)
    {
        LCD_Data_BUFF.G4_Rev_start = 0;
        memcpy(LCD_Buff_GLoa, LCD_Data_BUFF.G4_Rev_buf, 30);
        start_addr = (LCD_Data_BUFF.G4_Rev_buf[4] << 8) | (LCD_Data_BUFF.G4_Rev_buf[5]);
        order = LCD_Data_BUFF.G4_Rev_buf[3];

        switch(order)
        {
            case 0x83:
                switch(start_addr)
                {
                    case LCD_ZVOL_G:
                        gps_data.RevWrite_data.ZvolG = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(10);
                        break;

                    case LCD_ZVOL_Q:
                        gps_data.RevWrite_data.ZvolQ = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(11);
                        break;

                    case LCD_SINGVOL_G:
                        gps_data.RevWrite_data.SingvolG = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(12);
                        break;

                    case LCD_SINGVOL_GH:
                        gps_data.RevWrite_data.SingvolGH = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(13);
                        break;

                    case LCD_SINGOVERTIME_G:
                        gps_data.RevWrite_data.SingvolGtime = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(14);
                        break;

                    case LCD_SINGVOL_Q:
                        gps_data.RevWrite_data.SingvolQ = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(15);
                        break;

                    case LCD_SINGVOL_QH:
                        gps_data.RevWrite_data.SingvolQH = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(16);
                        break;

                    case LCD_SINGOVERTIME_Q:
                        gps_data.RevWrite_data.SingvolQtime = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(17);
                        break;

                    case LCD_CELLXCB:
                        gps_data.RevWrite_data.CellXyc = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(18);
                        break;

                    case LCD_OUTCHGCURR_G:
                        gps_data.RevWrite_data.OutcurrG = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(19);
                        break;

                    case LCD_OUTCURRTIME_G:
                        gps_data.RevWrite_data.OutcurrGtime = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(20);
                        break;

                    case LCD_CHGCURR_G:
                        gps_data.RevWrite_data.ChgcurrG = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(21);
                        break;

                    case LCD_CHGCURRTIME_G:
                        gps_data.RevWrite_data.ChgcurrGtime = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(22);
                        break;

                    case LCD_EQUALIONVOL:
                        gps_data.RevWrite_data.Equalivol = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(23);
                        break;

                    case LCD_EQUALIVOLC:
                        gps_data.RevWrite_data.Equalivolcc = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(24);
                        break;

                    case LCD_EQUALIOPEN:
                        gps_data.RevWrite_data.EqualiON = (LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(25);
                        break;

                    case LCD_POWTMPPORT:
                        gps_data.RevWrite_data.PowTmp	= ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(26);
                        break;

                    case LCD_POWTMPHH:
                        gps_data.RevWrite_data.PowTmpH = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(27);
                        break;

                    case LCD_INTEMPTER:
                        gps_data.RevWrite_data.Equaltmpb = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(28);
                        break;

                    case LCD_INTEMPTERRE:
                        gps_data.RevWrite_data.EqualtmpH = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(29);
                        break;

                    case LCD_CELLTMOPORT:
                        gps_data.RevWrite_data.CellTmp = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(30);
                        break;

                    case LCD_CHGGTMPPORT:
                        gps_data.RevWrite_data.CellChgTmpG = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(31);
                        break;

                    case LCD_OUTGTMPPORT:
                        gps_data.RevWrite_data.CellOutTmpG = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(32);
                        break;

                    case LCD_CHGDTMPPORT:
                        gps_data.RevWrite_data.ChgTmpD = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(33);
                        break;

                    case LCD_CHGDTMPPORTHH:
                        gps_data.RevWrite_data.ChgTmpDH = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(34);
                        break;

                    case LCD_OUTCHGDTMPPORT:
                        gps_data.RevWrite_data.OutTmpD = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(35);
                        break;

                    case LCD_OUTCHGDTMPHH:
                        gps_data.RevWrite_data.OutTmpDH = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(36);
                        break;

                    case LCD_CELLNUM:
                        if(gps_data.RevWrite_data.Cellnum != LCD_Data_BUFF.G4_Rev_buf[8])
                        {
                            gps_data.RevWrite_data.ZvolG = gps_data.RevWrite_data.SingvolG / 10.0 * LCD_Data_BUFF.G4_Rev_buf[8];
                            gps_data.RevWrite_data.ZvolQ = gps_data.RevWrite_data.SingvolQ / 10.0 * LCD_Data_BUFF.G4_Rev_buf[8];
                        }

                        gps_data.RevWrite_data.Cellnum = LCD_Data_BUFF.G4_Rev_buf[8];

                        SETIO(VPRO_V11);//����309����
                        LCD_num_sconf = 0;
                        LCD_SetACanshu = 0;
                        LCD_num_sconf =  LCD_Data_BUFF.G4_Rev_buf[8] & 0x0F;
                        delay_ms(20);
                        LCD_SetACanshu = (data_309_A.EEPROMRevdata.Sconf1.datas & 0xF0);
                        LCD_SetACanshu = LCD_SetACanshu | LCD_num_sconf;
                        MTPWrite_fun_1(EEPROM_SCONF1, 1, &LCD_SetACanshu);
                        RESETIO(VPRO_V11);//����309����
                        ResetAFE_1();

                        flash_write_sys_flag(37);
                        flash_write_sys_flag_Zvol();
                        break;

                    case LCD_CELLRLS:
                        if(gps_data.RevWrite_data.CellRl != ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]))
                        {
                            SOCinit = 0;
                            SOCinit_bit = 0;
                        }

                        gps_data.RevWrite_data.CellRl	= ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(38);

                        /*����ʵ������Լ��*/
                        if(gps_data.RevWrite_data.Reali_Q > gps_data.RevWrite_data.CellRl)
                            gps_data.RevWrite_data.Reali_Q = gps_data.RevWrite_data.CellRl;

                        break;

                    case LCD_CHGMOSKG:
                        gps_data.RevWrite_data.ChgMOS	= LCD_Data_BUFF.G4_Rev_buf[8];

                        if(gps_data.RevWrite_data.ChgMOS == 1) //�򿪳��MOS��
                        {
                            Chg_Lock = 0;

                            if(ChgMos_bit == 0)
                            {

                                Free309CHGMos();
                                ChgMos_bit = 0;
                            }
                            else
                            {
                                if(Chg_Flag == 0)  //�ж��Ƿ��й���
                                {

                                    Free309CHGMos();
                                    ChgMos_bit = 0;
                                }
                            }
                        }
                        else					//�رճ��MOS��
                        {
                            Chg_Lock = 1;

                            Shut309CHGMos();
                            ChgMos_bit = 1;
                        }

                        flash_write_sys_flag(39);
                        break;

                    case LCD_OUTMOSKG:
                        gps_data.RevWrite_data.OutMOS	= LCD_Data_BUFF.G4_Rev_buf[8];

                        if(gps_data.RevWrite_data.OutMOS == 1) //�򿪷ŵ�MOS��
                        {
                            Out_Lock = 0;

                            if(OutMos_bit == 0)
                            {

                                Free309DSGMos();
                                OutMos_bit = 0;
                            }
                            else
                            {
                                if(Out_flag == 0)      //�ж��Ƿ��й���
                                {

                                    Free309DSGMos();
                                    OutMos_bit = 0;
                                }
                            }
                        }
                        else
                        {
                            Out_Lock = 1;

                            Shut309DSGMos();
                            OutMos_bit = 1;
                        }

                        flash_write_sys_flag(40);
                        break;

                    case LCD_CURRBZ:
                        gps_data.RevWrite_data.CurrJZ	= ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(41);
                        break;

                    case LCD_BFBADRR:
                        gps_data.RevWrite_data.BHBAddr = LCD_Data_BUFF.G4_Rev_buf[8];
                        flash_write_sys_flag(42);
                        break;

                    case LCD_CELLTYPE:
                        if(gps_data.RevWrite_data.Celltype != LCD_Data_BUFF.G4_Rev_buf[8])
                        {
                            SOCinit_bit = 0;

                            if(LCD_Data_BUFF.G4_Rev_buf[8] == 0) //���
                            {
                                gps_data.RevWrite_data.SingvolG = 3650;
                                gps_data.RevWrite_data.SingvolGtime = 4;
                                gps_data.RevWrite_data.SingvolGH = 3600;
                                gps_data.RevWrite_data.SingvolQ = 2800;
                                gps_data.RevWrite_data.SingvolQtime = 4;
                                gps_data.RevWrite_data.SingvolQH = 2900;
                                gps_data.RevWrite_data.ChgcurrG = 20;
                                gps_data.RevWrite_data.ChgcurrGtime = 4;
                                gps_data.RevWrite_data.OutcurrG = 60;
                                gps_data.RevWrite_data.OutcurrGtime = 60;
                                gps_data.RevWrite_data.CellXyc = 1000;
                                gps_data.RevWrite_data.Equalivol = 3300;
                                gps_data.RevWrite_data.Equalivolcc = 10;
                            }
                            else if(LCD_Data_BUFF.G4_Rev_buf[8] == 1) //��Ԫ
                            {
                                gps_data.RevWrite_data.SingvolG = 4200;
                                gps_data.RevWrite_data.SingvolGtime = 4;
                                gps_data.RevWrite_data.SingvolGH = 4100;
                                gps_data.RevWrite_data.SingvolQ = 2800;
                                gps_data.RevWrite_data.SingvolQtime = 4;
                                gps_data.RevWrite_data.SingvolQH = 2900;
                                gps_data.RevWrite_data.ChgcurrG = 20;
                                gps_data.RevWrite_data.ChgcurrGtime = 4;
                                gps_data.RevWrite_data.OutcurrG = 60;
                                gps_data.RevWrite_data.OutcurrGtime = 60;
                                gps_data.RevWrite_data.CellXyc = 1000;
                                gps_data.RevWrite_data.Equalivol = 4000;
                                gps_data.RevWrite_data.Equalivolcc = 10;
                            }
                            else if(LCD_Data_BUFF.G4_Rev_buf[8] == 2) //�����
                            {
                                gps_data.RevWrite_data.SingvolG = 2300;
                                gps_data.RevWrite_data.SingvolGtime = 4;
                                gps_data.RevWrite_data.SingvolGH = 2250;
                                gps_data.RevWrite_data.SingvolQ = 1500;
                                gps_data.RevWrite_data.SingvolQtime = 4;
                                gps_data.RevWrite_data.SingvolQH = 1600;
                                gps_data.RevWrite_data.ChgcurrG = 20;
                                gps_data.RevWrite_data.ChgcurrGtime = 4;
                                gps_data.RevWrite_data.OutcurrG = 60;
                                gps_data.RevWrite_data.OutcurrGtime = 60;
                                gps_data.RevWrite_data.CellXyc = 1000;
                                gps_data.RevWrite_data.Equalivol = 2000;
                                gps_data.RevWrite_data.Equalivolcc = 5;
                            }




                        }

                        gps_data.RevWrite_data.Celltype = LCD_Data_BUFF.G4_Rev_buf[8];
                        flash_write_sys_flag(43);
                        flash_write_sys_flag_Init();
                        break;

                    case LCD_SLEEPTIME:
                        gps_data.RevWrite_data.SleepTime =  ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(44);
                        break;

                    case LCD_DRLBEEP:
                        gps_data.RevWrite_data.DRLNum	= LCD_Data_BUFF.G4_Rev_buf[8];
                        flash_write_sys_flag(45);
                        break;



                    case LCD_ZCHGKG:
                        gps_data.RevWrite_data.ZChgON = LCD_Data_BUFF.G4_Rev_buf[8];//0�ǹ�  1�ǿ�

                        if(gps_data.RevWrite_data.ZChgON >= 1)  SpecChargerFlag = 1;//ר�ó����
                        else
                        {
                            HDCurr_Flag = 0;
                            HDCurr_num = 0;
                            SpecChargerFlag = 0;
                        }

                        flash_write_sys_flag(47);
                        break;




                    case LCD_SysTime:
                        gps_data.RevWrite_data.SysTime = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(50);
                        break;

                    case LCD_CURRSwitch:
                        gps_data.RevWrite_data.CurrjzONOFF = LCD_Data_BUFF.G4_Rev_buf[8];
                        //�����ݲ����д洢
                        break;

                    case LCD_Reali_Q: //ʵ������
                        gps_data.RevWrite_data.Reali_Q = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(52);
                        break;


                    case LCD_Reset:
                        __set_PRIMASK(1);//�ر����ж�
                        ResetAFE_1();//��λ309AоƬ
                        ResetAFE_2();//��λ309BоƬ
                        delay_ms(50);
                        NVIC_SystemReset(); //����ϵͳ


                        break;



                    case LCD_GPSDVOL: //��о�͵�ѹ�ر�GPS��ʶ
                        gps_data.RevWrite_data.GpsDVol = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(59);
                        break;

                    case LCD_GPSDVOLH://��о��ѹ�ָ�GPS��ʶ
                        gps_data.RevWrite_data.GpsDVolH = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);
                        flash_write_sys_flag(60);
                        break;

                    case LCD_SIDU_KAIGUAN://ʪ�ȿ���
                        gps_data.RevWrite_data.ShiduKaiguan = LCD_Data_BUFF.G4_Rev_buf[8];
                        flash_write_sys_flag(61);
                        break;

                    case LCD_SIDU_PROTECT_VALUE://ʪ�ȱ���ֵ
                        gps_data.RevWrite_data.ShiduValueProtect = LCD_Data_BUFF.G4_Rev_buf[8];
                        flash_write_sys_flag(63);
                        break;

                    case LCD_SHORT_CUR_VALUE://��·����ֵ
                        gps_data.RevWrite_data.ShortCurValue = LCD_Data_BUFF.G4_Rev_buf[8];

//                        if(gps_data.RevWrite_data.ShortCurValue >= 38) //38--111
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, (I2C_GetRead_MsgSBS(0x08, PROTECT1) | 0x07 ) );
//                        else if( (gps_data.RevWrite_data.ShortCurValue >= 34) && (gps_data.RevWrite_data.ShortCurValue < 38) ) //34--110
//                        {
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, (I2C_GetRead_MsgSBS(0x08, PROTECT1) | 0x06 ) );
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, (I2C_GetRead_MsgSBS(0x08, PROTECT1) & (~0x01) ) );
//                        }
//                        else if( (gps_data.RevWrite_data.ShortCurValue >= 30) && (gps_data.RevWrite_data.ShortCurValue < 34) ) //30--101
//                        {
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, (I2C_GetRead_MsgSBS(0x08, PROTECT1) | 0x05 ) );
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, (I2C_GetRead_MsgSBS(0x08, PROTECT1) & (~0x02) ) );
//                        }
//                        else if( (gps_data.RevWrite_data.ShortCurValue >= 26) && (gps_data.RevWrite_data.ShortCurValue < 30) ) //26--100
//                        {
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, (I2C_GetRead_MsgSBS(0x08, PROTECT1) | 0x04 ) );
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, (I2C_GetRead_MsgSBS(0x08, PROTECT1) & (~0x03) ) );
//                        }
//                        else if( (gps_data.RevWrite_data.ShortCurValue >= 22) && (gps_data.RevWrite_data.ShortCurValue < 26) ) //22--011
//                        {
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, (I2C_GetRead_MsgSBS(0x08, PROTECT1) | 0x03 ) );
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, (I2C_GetRead_MsgSBS(0x08, PROTECT1) & (~0x04) ) );
//                        }

                        flash_write_sys_flag(64);
                        break;

                    case LCD_SHORT_CUR_DELAY://��·������ʱ

                        gps_data.RevWrite_data.ShortCurDelay = ((LCD_Data_BUFF.G4_Rev_buf[7] << 8) | LCD_Data_BUFF.G4_Rev_buf[8]);

//                        if(gps_data.RevWrite_data.ShortCurDelay >= 400)
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, ( I2C_GetRead_MsgSBS(0x08, PROTECT1) | 0x18 ) ); //400
//                        else if(gps_data.RevWrite_data.ShortCurDelay <= 70)
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, ( I2C_GetRead_MsgSBS(0x08, PROTECT1) & (~0x18) ) ); //70
//                        else if( (gps_data.RevWrite_data.ShortCurDelay > 70) && (gps_data.RevWrite_data.ShortCurDelay < 200) )
//                        {
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, ( I2C_GetRead_MsgSBS(0x08, PROTECT1) | 0x08 ) ); //100
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, ( I2C_GetRead_MsgSBS(0x08, PROTECT1) & (~0x10) ) ); //100
//                        }
//                        else if( (gps_data.RevWrite_data.ShortCurDelay >= 200) && (gps_data.RevWrite_data.ShortCurDelay < 400) )
//                        {
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, ( I2C_GetRead_MsgSBS(0x08, PROTECT1) | 0x10 ) ); //200
//                            I2C_WriteBreq_MsgSBS( 0x08, PROTECT1, ( I2C_GetRead_MsgSBS(0x08, PROTECT1) & (~0x08) ) ); //200
//                        }

                        flash_write_sys_flag(65);
                        break;


                    case LCD_User://�˺�

                        LCD_User_Pass[0] = 0x02;
                        LCD_User_Pass[1] = LCD_Data_BUFF.G4_Rev_buf[11];
                        LCD_User_Pass[2] = LCD_Data_BUFF.G4_Rev_buf[13];


                        break;

                    case LCD_Password://����


                        LCD_PassWord[0] = LCD_Data_BUFF.G4_Rev_buf[8];
                        LCD_PassWord[1] = LCD_Data_BUFF.G4_Rev_buf[9];
                        LCD_PassWord[2] = LCD_Data_BUFF.G4_Rev_buf[10];



                        break;

                    case LCD_Logain://��¼

                        if((LCD_PassWord[0] == LCD_User_Pass[0]) && (LCD_PassWord[1] == LCD_User_Pass[1]) && (LCD_PassWord[2] == LCD_User_Pass[2]))
                        {

//						   LCD_User_Pass[1]=0x00;
//						   LCD_User_Pass[2]=0x00;
//
//						   LCD_PassWord[0]=0x00;
//						   LCD_PassWord[1]=0x00;
//						   LCD_PassWord[2]=0x00;
                            Login_Flag = 1;
                            Send_string_Ye(Ye, 7);

                        }
                        else
                        {
//				           LCD_User_Pass[1]=0x00;
//						   LCD_User_Pass[2]=0x00;

//						   LCD_PassWord[0]=0x00;
//						   LCD_PassWord[1]=0x00;
//						   LCD_PassWord[2]=0x00;

                            Send_string_Ye(YeError, 7);




                        }


                        break;


                    default:
                        break;
                }



                break;

        }



        memset(LCD_Data_BUFF.G4_Rev_buf, 0, sizeof(LCD_Data_BUFF.G4_Rev_buf));

    }


}