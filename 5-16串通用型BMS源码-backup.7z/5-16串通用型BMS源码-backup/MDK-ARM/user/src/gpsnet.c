#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#include "usart.h"
#include "delay.h"
#include "485.h"
#include "stdio.h"
#include "string.h"
#include "gpsnet.h"
#include "flash.h"
#include "gpioinit.h"
#include "datahand.h"
#include "IIc.h"
#include "Jdy_19.h"
#include "iobind.h"
#include "SH367309.h"


bool      Activate = 1; //�����־λ
GPS_Buf   gps_buf = {0}; //����GPS���ݻ���
GPS_Buf   gps_buf_2 = {0}; //����GPS���ݻ���2
GPS_Buf   JDY33_buf = {0}; //�����������ݻ���
GPS_DATA  gps_data = {0}; //GPS����
OVER_Time_Struct  Over_time = {0}; //��ʱ���

u8 stopstart_309Flag = 0;
u8 restartflag = 0;
u8 num_sconf = 0;
u8 SetACanshu = 0;

/*����ѡ��ָ��*/
u8 Pass_init[7] = {"123456"};
u8 Pass_init_Lase[7] = {"123456"};
u8 Pass_CJ[7] = {"553322"};
u8 Pass_bit = 0;

u16 Gloa_SingvolG = 0;
u16 Gloa_SingvolGH = 0;

u16 Gloa_SingvolQ = 0;
u16 Gloa_SingvolQH = 0;

u8 Alarm_GPS_2M = 0;
/*
*������ Send_GpsFun
*����������	 bmsnum    �ն˺�
             orde      ������
			 type      ��������
			 *buff     �����׵�ַ
			 len       �����򳤶�
			 Recnumber ��¼��
*��������ֵ��wu
*�������ܣ��������ݵ�ƽ̨
*/
void Send_GpsFun(u32 bmsnum, u8 orde, u8 type, u8 *buff, u16 len, u32 Recnumber)
{
    u16 index;
    u8  sendbuf[420] = {0};
    Data_frame data_frame;

    data_frame.start_frame = START_FRAME;
    data_frame.Len_frame = S_GD_LEN + len - 2;
    data_frame.Bms_number = bmsnum;
    data_frame.orde = orde;
    data_frame.farm_sor = 0x00;
    data_frame.Type = type;
    memcpy(data_frame.s_data, buff, len);
    data_frame.Recnumber = Recnumber;
    data_frame.end_signs = END_FRAME;
    data_frame.check_sum = 0;

    sendbuf[0] = (data_frame.start_frame >> 8);
    sendbuf[1] = data_frame.start_frame;
    sendbuf[2] = (data_frame.Len_frame >> 8);
    sendbuf[3] = data_frame.Len_frame;
    sendbuf[4] = (data_frame.Bms_number >> 24);
    sendbuf[5] = (data_frame.Bms_number >> 16);
    sendbuf[6] = (data_frame.Bms_number >> 8);
    sendbuf[7] = data_frame.Bms_number;
    sendbuf[8] = data_frame.orde;
    sendbuf[9] = data_frame.farm_sor;
    sendbuf[10] = data_frame.Type;
    memcpy(&sendbuf[11], data_frame.s_data, len);
    sendbuf[11 + len] = (data_frame.Recnumber >> 24);
    sendbuf[12 + len] = (data_frame.Recnumber >> 16);
    sendbuf[13 + len] = (data_frame.Recnumber >> 8);
    sendbuf[14 + len] =  data_frame.Recnumber;
    sendbuf[15 + len] = data_frame.end_signs;

    for(index = 0; index < S_GD_LEN + len - 4; index++)
    {
        data_frame.check_sum += sendbuf[index];
    }

    sendbuf[16 + len] = 0x00;
    sendbuf[17 + len] = 0x00;
    sendbuf[18 + len] = (data_frame.check_sum >> 8);
    sendbuf[19 + len] = data_frame.check_sum;

    Send_TString_GPS(sendbuf, (u16)(S_GD_LEN + len));
}

void GpsPortNwDataHandle(void)
{
    if(gps_buf.gps_Rev_start == 1) //UART1  GPS�� NW���ݴ���
    {
        NwDataHandle(&gps_buf);
        Alarm_GPS_2M = 0;

        Uart1NWDataFlag = 0;
    }
}

void JDYPortNwDataHandle(void)
{

    if(JDY33_buf.gps_Rev_start == 1) //UART3  GPS�� NW���ݴ���
    {
        NwDataHandle(&JDY33_buf);
        Uart3NWDataFlag = 0;
    }
}


void JDYNAMBSet(void)
{
    if(Jdybuffs.Rev_Succe == 1) //�����㲥������
    {
        Jdybuffs.Rev_Succe = 0;
        Jdybuffs.Rev_Index = 0;
        Send_string_BLENamb(Jdybuffs.Buff);
        memset(Jdybuffs.Buff, 0, sizeof(Jdybuffs.Buff));
        delay_ms(500);

    }

}




void NwDataHandle(GPS_Buf *gps_buf)
{
    u16 data_len = 0;   //����
    u32 crc_sum = 0;	  //�ۼӺ�
    u32 Bms_num = 0;    //BMS�ն˺�
    u16 index;
    u8  orde = 0;       //������
    u8  b_addr = 0;     //��ʶ��
    u8  Type = 0;       //��������
    u32 recnum = 0;     //��¼��
    u8  sendbuffer[350];  //�������ݻ���
    u16 send_len = 0;     //�����򳤶�

    /*����һ֡���ĳɹ�*/
    if(gps_buf->gps_Rev_start == 1)
    {
        gps_buf->gps_Rev_start = 0; //�����־λ

        data_len = (u16)((gps_buf->gps_Rev_buf[2] << 8) | gps_buf->gps_Rev_buf[3]);

        for(index = 0; index < data_len + 2 - 4; index++)
        {
            crc_sum += gps_buf->gps_Rev_buf[index];
        }

        /*����Լ��*/
        if((u16)crc_sum == (u16)((gps_buf->gps_Rev_buf[data_len + 2 - 2] << 8) | gps_buf->gps_Rev_buf[data_len + 2 - 1]))
        {
            /*��ȡBMS�ն˺�*/
            Bms_num = (u32)(((gps_buf->gps_Rev_buf[4] << 8) | (gps_buf->gps_Rev_buf[5])) * 65536 + ((gps_buf->gps_Rev_buf[6] << 8) | gps_buf->gps_Rev_buf[7]));
            /*��ȡ������*/
            orde = gps_buf->gps_Rev_buf[8];
            /*��ȡ��ʶ��*/
            b_addr = gps_buf->gps_Rev_buf[11];
            /*��ȡ��¼��*/
            recnum = (u32)(((gps_buf->gps_Rev_buf[data_len + 2 - 5 - 4] << 8) | (gps_buf->gps_Rev_buf[data_len + 2 - 5 - 3])) * 65536 + ((gps_buf->gps_Rev_buf[data_len + 2 - 5 - 2] << 8) | gps_buf->gps_Rev_buf[data_len + 2 - 5 - 1]));
            tX_bit |= 0x01;//---------------------


            switch(orde)
            {
                case ACTIVACE_ORDE:	   //����ָ�� ���������˳�
                {
                    Type = 0x01; //Ӧ��
                    sendbuffer[0] = b_addr;
                    send_len = 1;
                    Activate = 1;
                    Send_GpsFun(Bms_num, orde, Type, sendbuffer, send_len, recnum);
                }
                break;

                case WRITE_ORDE:       //дָ��
                {
                    if(Activate == 1)
                    {
                        Type = 0x01; //Ӧ��
                        memset(sendbuffer, 0, sizeof(sendbuffer)); //��������

                        switch(b_addr)
                        {
                            case ZVOL_G:
                                gps_data.RevWrite_data.ZvolG = ((gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13]);
                                flash_write_sys_flag(10);
                                break;

                            case ZVOL_Q:
                                gps_data.RevWrite_data.ZvolQ = ((gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13]);
                                flash_write_sys_flag(11);
                                break;

                            case SINGVOL_G:
                                gps_data.RevWrite_data.SingvolG = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(12);
                                break;

                            case SINGVOL_GH:
                                gps_data.RevWrite_data.SingvolGH = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(13);
                                break;

                            case SINGOVERTIME_G:
                                gps_data.RevWrite_data.SingvolGtime = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(14);
                                break;

                            case SINGVOL_Q:
                                gps_data.RevWrite_data.SingvolQ = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(15);
                                break;

                            case SINGVOL_QH:
                                gps_data.RevWrite_data.SingvolQH = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(16);
                                break;

                            case SINGOVERTIME_Q:
                                gps_data.RevWrite_data.SingvolQtime = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(17);
                                break;

                            case CELLXCB:
                                gps_data.RevWrite_data.CellXyc = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(18);
                                break;

                            case OUTCHGCURR_G:
                                gps_data.RevWrite_data.OutcurrG = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(19);
                                break;

                            case OUTCURRTIME_G:
                                gps_data.RevWrite_data.OutcurrGtime = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(20);
                                break;

                            case CHGCURR_G:
                                gps_data.RevWrite_data.ChgcurrG = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(21);
                                break;

                            case CHGCURRTIME_G:
                                gps_data.RevWrite_data.ChgcurrGtime = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(22);
                                break;

                            case EQUALIONVOL:
                                gps_data.RevWrite_data.Equalivol = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(23);
                                break;

                            case EQUALIVOLC:
                                gps_data.RevWrite_data.Equalivolcc = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(24);
                                break;

                            case EQUALIOPEN:
                                gps_data.RevWrite_data.EqualiON = gps_buf->gps_Rev_buf[12];
                                flash_write_sys_flag(25);
                                break;

                            case POWTMPPORT:
                                gps_data.RevWrite_data.PowTmp	= (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(26);
                                break;

                            case POWTMPHH:
                                gps_data.RevWrite_data.PowTmpH = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(27);
                                break;

                            case EQUALITMPPORT:
                                gps_data.RevWrite_data.Equaltmpb = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(28);
                                break;

                            case EQUALITMPHH:
                                gps_data.RevWrite_data.EqualtmpH = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(29);
                                break;

                            case CELLTMOPORT:
                                gps_data.RevWrite_data.CellTmp = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(30);
                                break;

                            case CHGGTMPPORT:
                                gps_data.RevWrite_data.CellChgTmpG = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(31);
                                break;

                            case OUTGTMPPORT:
                                gps_data.RevWrite_data.CellOutTmpG = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(32);
                                break;

                            case CHGDTMPPORT:
                                gps_data.RevWrite_data.ChgTmpD = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(33);
                                break;

                            case CHGDTMPPORTHH:
                                gps_data.RevWrite_data.ChgTmpDH = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(34);
                                break;

                            case OUTCHGDTMPPORT:
                                gps_data.RevWrite_data.OutTmpD = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(35);
                                break;

                            case OUTCHGDTMPHH:
                                gps_data.RevWrite_data.OutTmpDH = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(36);
                                break;

                            case CELLNUM:

                                SETIO(VPRO_V11);//����309����
                                num_sconf = 0;
                                SetACanshu = 0;
                                num_sconf = gps_buf->gps_Rev_buf[12] & 0x0F;
                                delay_ms(20);
                                SetACanshu = (data_309_A.EEPROMRevdata.Sconf1.datas & 0xF0);
                                SetACanshu = SetACanshu | num_sconf;
                                MTPWrite_fun_1(EEPROM_SCONF1, 1, &SetACanshu);
                                RESETIO(VPRO_V11);//����309����
                                ResetAFE_1();

                                if(gps_data.RevWrite_data.Cellnum != gps_buf->gps_Rev_buf[12])
                                {
                                    gps_data.RevWrite_data.ZvolG = gps_data.RevWrite_data.SingvolG / 10.0 * gps_buf->gps_Rev_buf[12];
                                    gps_data.RevWrite_data.ZvolQ = gps_data.RevWrite_data.SingvolQ / 10.0 * gps_buf->gps_Rev_buf[12];
                                }

                                gps_data.RevWrite_data.Cellnum = gps_buf->gps_Rev_buf[12];

                                flash_write_sys_flag(37);
                                flash_write_sys_flag_Zvol();
                                break;

                            case CELLRLS:
                                if(gps_data.RevWrite_data.CellRl != (u32)(((gps_buf->gps_Rev_buf[12] << 8) | (gps_buf->gps_Rev_buf[13])) * 65536 + ((gps_buf->gps_Rev_buf[14] << 8) | gps_buf->gps_Rev_buf[15])))
                                {
                                    SOCinit = 0;
                                    SOCinit_bit = 0;
                                }

                                gps_data.RevWrite_data.CellRl	= (u32)(((gps_buf->gps_Rev_buf[12] << 8) | (gps_buf->gps_Rev_buf[13])) * 65536 + ((gps_buf->gps_Rev_buf[14] << 8) | gps_buf->gps_Rev_buf[15]));
                                flash_write_sys_flag(38);

                                /*����ʵ������Լ��*/
                                if(gps_data.RevWrite_data.Reali_Q > gps_data.RevWrite_data.CellRl)	gps_data.RevWrite_data.Reali_Q = gps_data.RevWrite_data.CellRl;

                                break;

                            case CHGMOSKG:
                                gps_data.RevWrite_data.ChgMOS	= gps_buf->gps_Rev_buf[12];

                                if(gps_data.RevWrite_data.ChgMOS == 1) //�򿪳��MOS��
                                {
                                    Chg_Lock = 0;

                                    if(ChgMos_bit == 0)
                                    {

                                        Free309CHGMos();
                                        ChgMos_bit = 0;
                                    }
                                    else
                                    {
                                        if(Chg_Flag == 0)        //�ж��Ƿ��й���
                                        {

                                            Free309CHGMos();
                                            ChgMos_bit = 0;
                                        }
                                    }
                                }
                                else						             //�رճ��MOS��
                                {
                                    Chg_Lock = 1;

                                    Shut309CHGMos();
                                    ChgMos_bit = 1;
                                }

                                flash_write_sys_flag(39);
                                break;

                            case OUTMOSKG:
                            {
                                gps_data.RevWrite_data.OutMOS	= gps_buf->gps_Rev_buf[12];

                                if(gps_data.RevWrite_data.OutMOS == 1) //�򿪷ŵ�MOS��
                                {
                                    Out_Lock = 0;

                                    if(OutMos_bit == 0)
                                    {

                                        Free309DSGMos();
                                        OutMos_bit = 0;
                                    }
                                    else
                                    {
                                        if(Out_flag == 0)      //�ж��Ƿ��й���
                                        {

                                            Free309DSGMos();
                                            OutMos_bit = 0;
                                        }
                                    }
                                }
                                else
                                {
                                    Out_Lock = 1;
                                    //�رշŵ�MOS��
                                    Shut309DSGMos();
                                    OutMos_bit = 1;
                                }

                                flash_write_sys_flag(40);
                            }
                            break;

                            case CURRBZ:
                                gps_data.RevWrite_data.CurrJZ	= (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(41);
                                break;

                            case BFBADRR:
                                gps_data.RevWrite_data.BHBAddr = gps_buf->gps_Rev_buf[12];
                                flash_write_sys_flag(42);
                                break;

                            case CELLTYPE:
                                if(gps_data.RevWrite_data.Celltype != gps_buf->gps_Rev_buf[12])
                                {
                                    SOCinit_bit = 0;

                                    if(gps_buf->gps_Rev_buf[12] == 0) //���
                                    {
                                        gps_data.RevWrite_data.SingvolG = 3650;
                                        gps_data.RevWrite_data.SingvolGtime = 4;
                                        gps_data.RevWrite_data.SingvolGH = 3600;
                                        gps_data.RevWrite_data.SingvolQ = 2800;
                                        gps_data.RevWrite_data.SingvolQtime = 4;
                                        gps_data.RevWrite_data.SingvolQH = 2900;
                                        gps_data.RevWrite_data.ChgcurrG = 20;
                                        gps_data.RevWrite_data.ChgcurrGtime = 64;
                                        gps_data.RevWrite_data.OutcurrG = 60;
                                        gps_data.RevWrite_data.OutcurrGtime = 60;

                                        gps_data.RevWrite_data.CellOUT2CURR_G = 80;
                                        gps_data.RevWrite_data.CellOUT2TIME_G = 4;


                                        gps_data.RevWrite_data.CellXyc = 1000;
                                        gps_data.RevWrite_data.Equalivol = 3300;
                                        gps_data.RevWrite_data.Equalivolcc = 10;
                                    }
                                    else if(gps_buf->gps_Rev_buf[12] == 1) //��Ԫ
                                    {
                                        gps_data.RevWrite_data.SingvolG = 4200;
                                        gps_data.RevWrite_data.SingvolGtime = 4;
                                        gps_data.RevWrite_data.SingvolGH = 4100;
                                        gps_data.RevWrite_data.SingvolQ = 2800;
                                        gps_data.RevWrite_data.SingvolQtime = 4;
                                        gps_data.RevWrite_data.SingvolQH = 2900;
                                        gps_data.RevWrite_data.ChgcurrG = 20;
                                        gps_data.RevWrite_data.ChgcurrGtime = 64;
                                        gps_data.RevWrite_data.OutcurrG = 60;
                                        gps_data.RevWrite_data.OutcurrGtime = 60;

                                        gps_data.RevWrite_data.CellOUT2CURR_G = 80;
                                        gps_data.RevWrite_data.CellOUT2TIME_G = 4;

                                        gps_data.RevWrite_data.CellXyc = 1000;
                                        gps_data.RevWrite_data.Equalivol = 4000;
                                        gps_data.RevWrite_data.Equalivolcc = 10;
                                    }
                                    else if(gps_buf->gps_Rev_buf[12] == 2) //�����
                                    {
                                        gps_data.RevWrite_data.SingvolG = 2300;
                                        gps_data.RevWrite_data.SingvolGtime = 4;
                                        gps_data.RevWrite_data.SingvolGH = 2250;
                                        gps_data.RevWrite_data.SingvolQ = 1500;
                                        gps_data.RevWrite_data.SingvolQtime = 4;
                                        gps_data.RevWrite_data.SingvolQH = 1600;
                                        gps_data.RevWrite_data.ChgcurrG = 20;
                                        gps_data.RevWrite_data.ChgcurrGtime = 64;
                                        gps_data.RevWrite_data.OutcurrG = 60;
                                        gps_data.RevWrite_data.OutcurrGtime = 60;

                                        gps_data.RevWrite_data.CellOUT2CURR_G = 80;
                                        gps_data.RevWrite_data.CellOUT2TIME_G = 4;


                                        gps_data.RevWrite_data.CellXyc = 1000;
                                        gps_data.RevWrite_data.Equalivol = 2000;
                                        gps_data.RevWrite_data.Equalivolcc = 5;
                                    }
                                }

                                gps_data.RevWrite_data.Celltype = gps_buf->gps_Rev_buf[12];
                                flash_write_sys_flag(43);
                                flash_write_sys_flag_Init();
                                break;

                            case SLEEPTIME:
                                gps_data.RevWrite_data.SleepTime = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(44);
                                break;

                            case DRLBEEP:
                                gps_data.RevWrite_data.DRLNum	= gps_buf->gps_Rev_buf[12];
                                flash_write_sys_flag(45);
                                break;

                            case SDATAPASS:
                                memcpy(gps_data.RevWrite_data.Pass, &gps_buf->gps_Rev_buf[12], 10);
                                flash_write_sys_flag(46);
                                break;

                            case ZCHGKG:
                                gps_data.RevWrite_data.ZChgON = gps_buf->gps_Rev_buf[12];//0�ǹ�  1�ǿ�

                                if(gps_data.RevWrite_data.ZChgON >= 1)  SpecChargerFlag = 1;//ר�ó����
                                else
                                {
                                    HDCurr_Flag = 0;
                                    HDCurr_num = 0;
                                    SpecChargerFlag = 0;
                                }

                                flash_write_sys_flag(47);
                                break;

                            case EQUT_ID:
                                memcpy(gps_data.RevWrite_data.EquID, &gps_buf->gps_Rev_buf[12], 8);
                                flash_write_sys_flag(48);
                                break;

                            case CCDAT:
                                memcpy(gps_data.RevWrite_data.CCDat, &gps_buf->gps_Rev_buf[12], 4);
                                flash_write_sys_flag(49);
                                break;

                            case SYSTIME:
                                gps_data.RevWrite_data.SysTime = (u32)(((gps_buf->gps_Rev_buf[12] << 8) | (gps_buf->gps_Rev_buf[13])) * 65536 + ((gps_buf->gps_Rev_buf[14] << 8) | gps_buf->gps_Rev_buf[15]));
                                flash_write_sys_flag(50);
                                break;

                            case CURR_JZ:
                                gps_data.RevWrite_data.CurrjzONOFF = gps_buf->gps_Rev_buf[12];
                                //�����ݲ����д洢
                                break;

                            case REALITY_Q: //ʵ������
                                gps_data.RevWrite_data.Reali_Q = (u32)(((gps_buf->gps_Rev_buf[12] << 8) | (gps_buf->gps_Rev_buf[13])) * 65536 + ((gps_buf->gps_Rev_buf[14] << 8) | gps_buf->gps_Rev_buf[15]));
                                flash_write_sys_flag(52);
                                break;

                            case XXINGID:   //�µĳ���ID��������
                                memcpy(gps_data.RevWrite_data.XID, &gps_buf->gps_Rev_buf[12], 24);
                                flash_write_sys_flag(53);
                                flash_write_sys_flag(54);
                                flash_write_sys_flag(55);
                                flash_write_sys_flag(56);
                                break;

                            case REST_XT:
                                gps_data.RevWrite_data.rest_xt = gps_buf->gps_Rev_buf[12];

                                if(gps_data.RevWrite_data.rest_xt == 1)
                                {
                                    restartflag = 1;//��֤�ȷ��ͷ����źź�������
                                    ResetAFE_1();//��λ309AоƬ
                                    ResetAFE_2();//��λ309BоƬ
//                                    __set_PRIMASK(1);
//                                    NVIC_SystemReset(); //����ϵͳ
                                }

                                break;

                            case REST_HF: //�ָ���������
                                gps_data.RevWrite_data.rest_hf = gps_buf->gps_Rev_buf[12];

                                if(gps_data.RevWrite_data.rest_hf == 1)
                                {
                                    flash_write_sys_flag_ALL_Init();
                                }

                                break;

                            case REMO_UP: //Զ������
                                break;

                            case GPSDVOL: //��о�͵�ѹ�ر�GPS��ʶ
                                gps_data.RevWrite_data.GpsDVol = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(59);
                                break;

                            case GPSDVOLH://��о��ѹ�ָ�GPS��ʶ
                                gps_data.RevWrite_data.GpsDVolH = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(60);
                                break;

                            case SIDU_KAIGUAN://ʪ�ȿ���
                                gps_data.RevWrite_data.ShiduKaiguan = gps_buf->gps_Rev_buf[12];
                                flash_write_sys_flag(61);
                                break;

                            /*						case SIDU_VALUE://��ǰʪ����ֵ  ֻ����
                            							gps_data.RevWrite_data.ShiduValueNow = gps_buf->gps_Rev_buf[12];
                            						  flash_write_sys_flag(62);
                            						break;	*/

                            case SIDU_PROTECT_VALUE://ʪ�ȱ���ֵ
                                gps_data.RevWrite_data.ShiduValueProtect = gps_buf->gps_Rev_buf[12];
                                flash_write_sys_flag(63);
                                break;

                            case SHORT_CUR_VALUE://��·����ֵ
                                gps_data.RevWrite_data.ShortCurValue = gps_buf->gps_Rev_buf[12];
                                flash_write_sys_flag(64);
                                break;

                            case SHORT_CUR_DELAY://��·������ʱ
                                gps_data.RevWrite_data.ShortCurDelay = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(65);
                                break;

                            case SwitchEnable://ʹ�ܿ���
                                gps_data.RevWrite_data.EnableSwitch = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(66);
                                break;

                            case OUT2CURR_G://�������ŵ���
                                gps_data.RevWrite_data.CellOUT2CURR_G = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(67);
                                break;


                            case OUT2TIME_G://����������ʱ
                                gps_data.RevWrite_data.CellOUT2TIME_G = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(68);
                                break;


                            case DRLBEEP_Jiao://������У׼��ѹ
                                gps_data.RevWrite_data.CellDRLBEEP_Jiao = (gps_buf->gps_Rev_buf[12] << 8) | gps_buf->gps_Rev_buf[13];
                                flash_write_sys_flag(69);
                                break;


                            default:
                                break;
                        }

                        sendbuffer[0] = b_addr;
                        send_len = 1;
                        /*��������*/
                        Send_GpsFun(Bms_num, orde, Type, sendbuffer, send_len, recnum);

                        if(restartflag == 1)
                        {
                            restartflag = 0;
                            __set_PRIMASK(1);//�ر�ȫ���ж�

                            NVIC_SystemReset(); //����ϵͳ
                        }
                    }
                }
                break;

                case REV_ORDE:         //��ָ��
                    if(Activate == 1)
                    {
                        Type = 0x01; //������



                        memset(sendbuffer, 0, sizeof(sendbuffer)); //��������

                        switch(b_addr)
                        {
                            case REVSINGCELLVOL:
                            {
                                u8 i;

                                for(i = 0; i < gps_data.Rev_data.CellZnum; i++)			 //�������
                                {
                                    sendbuffer[i * 3 + 1] = gps_data.Rev_data.Singcellvol[i][0];
                                    sendbuffer[i * 3 + 2] = gps_data.Rev_data.Singcellvol[i][1];
                                    sendbuffer[i * 3 + 3] = gps_data.Rev_data.Singcellvol[i][2];
                                }

                                send_len = gps_data.Rev_data.CellZnum * 3 + 1;
                            }
                            break;

                            case REVPOWTMP:
                                sendbuffer[1] = gps_data.Rev_data.MosTmp >> 8;
                                sendbuffer[2] = gps_data.Rev_data.MosTmp;
                                send_len = 3;
                                break;

                            case REVEQUALI:
                                sendbuffer[1] = gps_data.Rev_data.QualiTmp >> 8;
                                sendbuffer[2] = gps_data.Rev_data.QualiTmp;
                                send_len = 3;
                                break;

                            case REVCELLTMP:
                                sendbuffer[1] = gps_data.Rev_data.CellTmp >> 8;
                                sendbuffer[2] = gps_data.Rev_data.CellTmp;
                                send_len = 3;
                                break;

                            case REVCELLZVOL:
                                sendbuffer[1] = gps_data.Rev_data.CellZvol >> 8;
                                sendbuffer[2] = gps_data.Rev_data.CellZvol;
                                send_len = 3;
                                break;

                            case REVCURR:
                                sendbuffer[1] = gps_data.Rev_data.Currdata >> 8;
                                sendbuffer[2] = gps_data.Rev_data.Currdata;
                                send_len = 3;
                                break;

                            case REVSRL:
                                sendbuffer[1] = gps_data.Rev_data.Soc;
                                send_len = 2;
                                break;

                            case CELLTMPNUM:
                                sendbuffer[1] = gps_data.Rev_data.CellTmpSors;
                                send_len = 2;
                                break;

                            case CELLUSNUM:
                                sendbuffer[1] = gps_data.Rev_data.Cellusnum >> 8;
                                sendbuffer[2] = gps_data.Rev_data.Cellusnum;
                                send_len = 3;
                                break;

                            case BMSCALCELLRL:
                                sendbuffer[1] = gps_data.Rev_data.Bms_rl >> 8;
                                sendbuffer[2] = gps_data.Rev_data.Bms_rl;
                                send_len = 3;
                                break;

                            case CELLZRL://ѭ����������λSOH
                                sendbuffer[1] = 0;
                                sendbuffer[2] = 0;
                                sendbuffer[3] = SOH_Readflash >> 8;
                                sendbuffer[4] = SOH_Readflash;
                                send_len = 5;
                                break;

                            case CELLZCS:
                                sendbuffer[1] = gps_data.Rev_data.CellZnum >> 8;
                                sendbuffer[2] = gps_data.Rev_data.CellZnum;
                                send_len = 3;
                                break;

                            case CELLHIT:
                                if(HitFlag == 1)
                                {
                                    sendbuffer[1] = Hitsturt >> 8;
                                    sendbuffer[2] = Hitsturt;
                                    HitFlag = 0;		//�ϱ������
                                }
                                else
                                {
                                    sendbuffer[1] = gps_data.Rev_data.CellhitData >> 8;
                                    sendbuffer[2] = gps_data.Rev_data.CellhitData;
                                }

                                send_len = 3;
                                break;

                            case CELLSTURT:
                                sendbuffer[1] = gps_data.Rev_data.CellStrtu >> 8;
                                sendbuffer[2] = gps_data.Rev_data.CellStrtu;
                                send_len = 3;
                                break;

                            case HITRECORDS:
                                sendbuffer[1] = gps_data.Rev_data.Hitjlm >> 8;
                                sendbuffer[2] = gps_data.Rev_data.Hitjlm;
                                send_len = 3;
                                break;

                            /////////////////////////////////////////////////////////
                            case ZVOL_G:
                                sendbuffer[1] = gps_data.RevWrite_data.ZvolG >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.ZvolG;
                                send_len = 3;
                                break;

                            case ZVOL_Q:
                                sendbuffer[1] = gps_data.RevWrite_data.ZvolQ >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.ZvolQ;
                                send_len = 3;
                                break;

                            case SINGVOL_G:
                                sendbuffer[1] = gps_data.RevWrite_data.SingvolG >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.SingvolG;
                                send_len = 3;
                                break;

                            case SINGVOL_GH:
                                sendbuffer[1] = gps_data.RevWrite_data.SingvolGH >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.SingvolGH;
                                send_len = 3;
                                break;

                            case SINGOVERTIME_G:
                                sendbuffer[1] = gps_data.RevWrite_data.SingvolGtime >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.SingvolGtime;
                                send_len = 3;
                                break;

                            case SINGVOL_Q:
                                sendbuffer[1] = gps_data.RevWrite_data.SingvolQ >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.SingvolQ;
                                send_len = 3;
                                break;

                            case SINGVOL_QH:
                                sendbuffer[1] = gps_data.RevWrite_data.SingvolQH >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.SingvolQH;
                                send_len = 3;
                                break;

                            case SINGOVERTIME_Q:
                                sendbuffer[1] = gps_data.RevWrite_data.SingvolQtime >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.SingvolQtime;
                                send_len = 3;
                                break;

                            case CELLXCB:
                                sendbuffer[1] = gps_data.RevWrite_data.CellXyc >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.CellXyc;
                                send_len = 3;
                                break;

                            case OUTCHGCURR_G:
                                sendbuffer[1] = gps_data.RevWrite_data.OutcurrG >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.OutcurrG;
                                send_len = 3;
                                break;

                            case OUTCURRTIME_G:
                                sendbuffer[1] = gps_data.RevWrite_data.OutcurrGtime >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.OutcurrGtime;
                                send_len = 3;
                                break;

                            case CHGCURR_G:
                                sendbuffer[1] = gps_data.RevWrite_data.ChgcurrG >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.ChgcurrG;
                                send_len = 3;
                                break;

                            case CHGCURRTIME_G:
                                sendbuffer[1] = gps_data.RevWrite_data.ChgcurrGtime >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.ChgcurrGtime;
                                send_len = 3;
                                break;

                            case EQUALIONVOL:
                                sendbuffer[1] = gps_data.RevWrite_data.Equalivol >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.Equalivol;
                                send_len = 3;
                                break;

                            case EQUALIVOLC:
                                sendbuffer[1] = gps_data.RevWrite_data.Equalivolcc >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.Equalivolcc;
                                send_len = 3;
                                break;

                            case EQUALIOPEN:
                                sendbuffer[1] = gps_data.RevWrite_data.EqualiON;
                                send_len = 2;
                                break;

                            case POWTMPPORT:
                                sendbuffer[1] = gps_data.RevWrite_data.PowTmp >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.PowTmp;
                                send_len = 3;
                                break;

                            case POWTMPHH:
                                sendbuffer[1] = gps_data.RevWrite_data.PowTmpH >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.PowTmpH;
                                send_len = 3;
                                break;

                            case EQUALITMPPORT:
                                sendbuffer[1] = gps_data.RevWrite_data.Equaltmpb >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.Equaltmpb;
                                send_len = 3;
                                break;

                            case EQUALITMPHH:
                                sendbuffer[1] = gps_data.RevWrite_data.EqualtmpH >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.EqualtmpH;
                                send_len = 3;
                                break;

                            case CELLTMOPORT:
                                sendbuffer[1] = gps_data.RevWrite_data.CellTmp >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.CellTmp;
                                send_len = 3;
                                break;

                            case CHGGTMPPORT:
                                sendbuffer[1] = gps_data.RevWrite_data.CellChgTmpG >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.CellChgTmpG;
                                send_len = 3;
                                break;

                            case OUTGTMPPORT:
                                sendbuffer[1] = gps_data.RevWrite_data.CellOutTmpG >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.CellOutTmpG;
                                send_len = 3;
                                break;

                            case CHGDTMPPORT:
                                sendbuffer[1] = gps_data.RevWrite_data.ChgTmpD >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.ChgTmpD;
                                send_len = 3;
                                break;

                            case CHGDTMPPORTHH:
                                sendbuffer[1] = gps_data.RevWrite_data.ChgTmpDH >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.ChgTmpDH;
                                send_len = 3;
                                break;

                            case OUTCHGDTMPPORT:
                                sendbuffer[1] = gps_data.RevWrite_data.OutTmpD >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.OutTmpD;
                                send_len = 3;
                                break;

                            case OUTCHGDTMPHH:
                                sendbuffer[1] = gps_data.RevWrite_data.OutTmpDH >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.OutTmpDH;
                                send_len = 3;
                                break;

                            case CELLNUM:
                                sendbuffer[1] = gps_data.RevWrite_data.Cellnum;
                                send_len = 2;
                                break;

                            case CELLRLS:
                                sendbuffer[1] = gps_data.RevWrite_data.CellRl >> 24;
                                sendbuffer[2] = gps_data.RevWrite_data.CellRl >> 16;
                                sendbuffer[3] = gps_data.RevWrite_data.CellRl >> 8;
                                sendbuffer[4] = gps_data.RevWrite_data.CellRl;
                                send_len = 5;
                                break;

                            case CHGMOSKG:
                                sendbuffer[1] = gps_data.RevWrite_data.ChgMOS;
                                send_len = 2;
                                break;

                            case OUTMOSKG:
                                sendbuffer[1] = gps_data.RevWrite_data.OutMOS;
                                send_len = 2;
                                break;

                            case CURRBZ:
                                sendbuffer[1] = gps_data.RevWrite_data.CurrJZ >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.CurrJZ;
                                send_len = 3;
                                break;

                            case BFBADRR:
                                sendbuffer[1] = gps_data.RevWrite_data.BHBAddr;
                                send_len = 2;
                                break;

                            case CELLTYPE:
                                sendbuffer[1] = gps_data.RevWrite_data.Celltype;
                                send_len = 2;
                                break;

                            case SLEEPTIME:
                                sendbuffer[1] = gps_data.RevWrite_data.SleepTime >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.SleepTime;
                                send_len = 3;
                                break;

                            case DRLBEEP:
                                sendbuffer[1] = gps_data.RevWrite_data.DRLNum;
                                send_len = 2;
                                break;

                            case SDATAPASS:
                                memcpy(&sendbuffer[1], gps_data.RevWrite_data.Pass, 10);
                                send_len = 11;
                                break;

                            case ZCHGKG:
                                sendbuffer[1] = gps_data.RevWrite_data.ZChgON;
                                send_len = 2;
                                break;

                            case EQUT_ID:
                                memcpy(&sendbuffer[1], gps_data.RevWrite_data.EquID, 8);
                                send_len = 9;
                                break;

                            case CCDAT:
                                sendbuffer[1] = gps_data.RevWrite_data.CCDat[0];
                                sendbuffer[2] = gps_data.RevWrite_data.CCDat[1];
                                sendbuffer[3] = gps_data.RevWrite_data.CCDat[2];
                                sendbuffer[4] = gps_data.RevWrite_data.CCDat[3];
                                send_len = 5;
                                break;

                            case SYSTIME:
                                sendbuffer[1] = gps_data.RevWrite_data.SysTime >> 24;
                                sendbuffer[2] = gps_data.RevWrite_data.SysTime >> 16;
                                sendbuffer[3] = gps_data.RevWrite_data.SysTime >> 8;
                                sendbuffer[4] = gps_data.RevWrite_data.SysTime;
                                send_len = 5;
                                break;

                            case SOFT_NUM:	   //�����汾��
                                memcpy(gps_data.RevWrite_data.soft_num, soft_num_ZF, 15);
                                memcpy(&sendbuffer[1], gps_data.RevWrite_data.soft_num, 15);
                                send_len = 16;
                                break;

                            case CURR_JZ:
                                sendbuffer[1] = gps_data.RevWrite_data.CurrjzONOFF;
                                send_len = 2;
                                break;

                            case REALITY_Q:
                                sendbuffer[1] = gps_data.RevWrite_data.Reali_Q >> 24;
                                sendbuffer[2] = gps_data.RevWrite_data.Reali_Q >> 16;
                                sendbuffer[3] = gps_data.RevWrite_data.Reali_Q >> 8;
                                sendbuffer[4] = gps_data.RevWrite_data.Reali_Q;
                                send_len = 5;
                                break;

                            case XXINGID:
                                memcpy(&sendbuffer[1], gps_data.RevWrite_data.XID, 24);
                                send_len = 25;
                                break;

                            case GPSDVOL:
                                sendbuffer[sendbuffer[1] + 222] = GPSDVOL;
                                sendbuffer[sendbuffer[1] + 223] = gps_data.RevWrite_data.GpsDVol >> 8;
                                sendbuffer[sendbuffer[1] + 224] = gps_data.RevWrite_data.GpsDVol;
                                send_len = 3;
                                break;

                            case GPSDVOLH:
                                sendbuffer[sendbuffer[1] + 225] =  GPSDVOLH;
                                sendbuffer[sendbuffer[1] + 226] = gps_data.RevWrite_data.GpsDVolH >> 8;
                                sendbuffer[sendbuffer[1] + 227] = gps_data.RevWrite_data.GpsDVolH;
                                send_len = 3;
                                break;

                            case SIDU_KAIGUAN://ʪ�ȿ���
                                sendbuffer[1] = gps_data.RevWrite_data.ShiduKaiguan;
                                send_len = 2;
                                break;

                            case SIDU_VALUE://��ǰʪ����ֵ
                                sendbuffer[1] = gps_data.RevWrite_data.ShiduValueNow;
                                send_len = 2;
                                break;

                            case SIDU_PROTECT_VALUE://ʪ�ȱ���ֵ
                                sendbuffer[1] = gps_data.RevWrite_data.ShiduValueProtect;
                                send_len = 2;
                                break;

                            case SHORT_CUR_VALUE://��·����ֵ
                                sendbuffer[1] = gps_data.RevWrite_data.ShortCurValue;
                                send_len = 2;
                                break;

                            case SHORT_CUR_DELAY://��·������ʱ
                                sendbuffer[1] = gps_data.RevWrite_data.ShortCurDelay >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.ShortCurDelay;
                                send_len = 3;
                                break;

                            case SwitchEnable://ʹ�ܿ���
                                sendbuffer[1] = gps_data.RevWrite_data.EnableSwitch >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.EnableSwitch;
                                send_len = 3;
                                break;

                            case OUT2CURR_G://�������ŵ���
                                sendbuffer[1] = gps_data.RevWrite_data.CellOUT2CURR_G >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.CellOUT2CURR_G;
                                send_len = 3;
                                break;


                            case OUT2TIME_G://����������ʱ
                                sendbuffer[1] = gps_data.RevWrite_data.CellOUT2TIME_G >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.CellOUT2TIME_G;
                                send_len = 3;
                                break;


                            case DRLBEEP_Jiao://������У׼��ѹ
                                sendbuffer[1] = gps_data.RevWrite_data.CellDRLBEEP_Jiao >> 8;
                                sendbuffer[2] = gps_data.RevWrite_data.CellDRLBEEP_Jiao;
                                send_len = 3;
                                break;

                            default:
                                break;
                        }

                        sendbuffer[0] = b_addr;
                        /*��������*/
                        Send_GpsFun(Bms_num, orde, Type, sendbuffer, send_len, recnum);
                    }

                    break;

                case PASS_ORDE:        //������ָ��-------------�����������
                {


                    switch(b_addr)
                    {
                        case PASS_YAZ: //������֤
                            if((Pass_init[0] == gps_buf->gps_Rev_buf[12]) && (Pass_init[1] == gps_buf->gps_Rev_buf[13])
                                    && (Pass_init[2] == gps_buf->gps_Rev_buf[14]) && (Pass_init[3] == gps_buf->gps_Rev_buf[15])
                                    && (Pass_init[4] == gps_buf->gps_Rev_buf[16]) && (Pass_init[5] == gps_buf->gps_Rev_buf[17])
                              )
                            {
                                sendbuffer[1] = 1;
                            }
                            else
                                sendbuffer[1] = 0;    //1�ɹ� 0ʧ��

                            if(sendbuffer[1] == 0)
                            {
                                //��������
                                if((Pass_CJ[0] == gps_buf->gps_Rev_buf[12]) && (Pass_CJ[1] == gps_buf->gps_Rev_buf[13])
                                        && (Pass_CJ[2] == gps_buf->gps_Rev_buf[14]) && (Pass_CJ[3] == gps_buf->gps_Rev_buf[15])
                                        && (Pass_CJ[4] == gps_buf->gps_Rev_buf[16]) && (Pass_CJ[5] == gps_buf->gps_Rev_buf[17])
                                  )
                                {
                                    sendbuffer[1] = 1;
                                }
                                else
                                    sendbuffer[1] = 0;    //1�ɹ� 0ʧ��
                            }

                            Pass_bit = 0;
                            break;

                        case XIUG_PASS_CHU: //�޸���������ԭʼ����
                            if((Pass_init[0] == gps_buf->gps_Rev_buf[12]) && (Pass_init[1] == gps_buf->gps_Rev_buf[13])
                                    && (Pass_init[2] == gps_buf->gps_Rev_buf[14]) && (Pass_init[3] == gps_buf->gps_Rev_buf[15])
                                    && (Pass_init[4] == gps_buf->gps_Rev_buf[16]) && (Pass_init[5] == gps_buf->gps_Rev_buf[17])
                              )
                            {
                                sendbuffer[1] = 1;
                                Pass_bit = 1;
                            }
                            else
                            {
                                sendbuffer[1] = 0;    //1�ɹ� 0ʧ��
                                Pass_bit = 0;
                            }

                            break;

                        case XIUG_PASS_NEW:
                        {
                            u8 i = 0;
                            memcpy(&Pass_init_Lase[0], &gps_buf->gps_Rev_buf[12], 6);

                            if(Pass_bit == 1)
                            {
                                for(i = 0; i < 6; i++)
                                {
                                    Pass_init[i] = Pass_init_Lase[i];
                                }

                                flash_write_sys_flag(58);
                                Pass_bit = 0;
                                sendbuffer[1] = 1;
                            }
                            else
                                sendbuffer[1] = 0;
                        }
                        break;
                    }

                    Type = 0x01;
                    sendbuffer[0] = b_addr;
                    send_len = 2;
                    /*��������*/
                    Send_GpsFun(Bms_num, orde, Type, sendbuffer, send_len, recnum);
                }
                break;

                case REV_ALLORDE:      //��ȫ��ָ��



                    if(Activate == 1)
                    {
                        u8 i;
                        Type = 0x01; //Ӧ��
                        memset(sendbuffer, 0, sizeof(sendbuffer)); //��������

                        /*�汾����Ϣ*/
                        sendbuffer[0] = REVSINGCELLVOL;
                        sendbuffer[1] = gps_data.Rev_data.CellZnum * 3;

                        for(i = 0; i < gps_data.Rev_data.CellZnum; i++)
                        {
                            sendbuffer[i * 3 + 2] = gps_data.Rev_data.Singcellvol[i][0];
                            sendbuffer[i * 3 + 3] = gps_data.Rev_data.Singcellvol[i][1];
                            sendbuffer[i * 3 + 4] = gps_data.Rev_data.Singcellvol[i][2];
                        }

                        sendbuffer[sendbuffer[1] + 2] = REVPOWTMP;
                        sendbuffer[sendbuffer[1] + 3] = gps_data.Rev_data.MosTmp >> 8;
                        sendbuffer[sendbuffer[1] + 4] = gps_data.Rev_data.MosTmp;

                        sendbuffer[sendbuffer[1] + 5] = REVEQUALI;
                        sendbuffer[sendbuffer[1] + 6] = gps_data.Rev_data.QualiTmp >> 8;
                        sendbuffer[sendbuffer[1] + 7] = gps_data.Rev_data.QualiTmp;

                        sendbuffer[sendbuffer[1] + 8] = REVCELLTMP;
                        sendbuffer[sendbuffer[1] + 9] = gps_data.Rev_data.CellTmp >> 8;
                        sendbuffer[sendbuffer[1] + 10] = gps_data.Rev_data.CellTmp;

                        sendbuffer[sendbuffer[1] + 11] = REVCELLZVOL;
                        sendbuffer[sendbuffer[1] + 12] = gps_data.Rev_data.CellZvol >> 8;
                        sendbuffer[sendbuffer[1] + 13] = gps_data.Rev_data.CellZvol;

                        sendbuffer[sendbuffer[1] + 14] = REVCURR;
                        sendbuffer[sendbuffer[1] + 15] = gps_data.Rev_data.Currdata >> 8;
                        sendbuffer[sendbuffer[1] + 16] = gps_data.Rev_data.Currdata;

                        sendbuffer[sendbuffer[1] + 17] = REVSRL;
                        sendbuffer[sendbuffer[1] + 18] = gps_data.Rev_data.Soc;

                        sendbuffer[sendbuffer[1] + 19] = CELLTMPNUM;
                        sendbuffer[sendbuffer[1] + 20] = gps_data.Rev_data.CellTmpSors;

                        sendbuffer[sendbuffer[1] + 21] = CELLUSNUM;
                        sendbuffer[sendbuffer[1] + 22] = gps_data.Rev_data.Cellusnum >> 8;
                        sendbuffer[sendbuffer[1] + 23] = gps_data.Rev_data.Cellusnum;

                        sendbuffer[sendbuffer[1] + 24] = CELLZRL;//ѭ����������ΪSOH
                        sendbuffer[sendbuffer[1] + 25] = 0;
                        sendbuffer[sendbuffer[1] + 26] = 0;
                        sendbuffer[sendbuffer[1] + 27] = SOH_Readflash >> 8;
                        sendbuffer[sendbuffer[1] + 28] = SOH_Readflash;

                        sendbuffer[sendbuffer[1] + 29] = CELLZCS;
                        sendbuffer[sendbuffer[1] + 30] = gps_data.Rev_data.CellZnum >> 8;
                        sendbuffer[sendbuffer[1] + 31] = gps_data.Rev_data.CellZnum;

                        sendbuffer[sendbuffer[1] + 32] = CELLHIT;

                        if(HitFlag == 1)
                        {
                            sendbuffer[sendbuffer[1] + 33] = Hitsturt >> 8;
                            sendbuffer[sendbuffer[1] + 34] = Hitsturt;
                            HitFlag = 0; //�ϱ������
                        }
                        else
                        {
                            sendbuffer[sendbuffer[1] + 33] = gps_data.Rev_data.CellhitData >> 8;
                            sendbuffer[sendbuffer[1] + 34] = gps_data.Rev_data.CellhitData;
                        }

                        sendbuffer[sendbuffer[1] + 35] = CELLSTURT;
                        sendbuffer[sendbuffer[1] + 36] = gps_data.Rev_data.CellStrtu >> 8;
                        sendbuffer[sendbuffer[1] + 37] = gps_data.Rev_data.CellStrtu;

                        /////////////////////////////////////////////////////////
                        sendbuffer[sendbuffer[1] + 38] = ZVOL_G;
                        sendbuffer[sendbuffer[1] + 39] = gps_data.RevWrite_data.ZvolG >> 8;
                        sendbuffer[sendbuffer[1] + 40] = gps_data.RevWrite_data.ZvolG;

                        sendbuffer[sendbuffer[1] + 41] = ZVOL_Q;
                        sendbuffer[sendbuffer[1] + 42] = gps_data.RevWrite_data.ZvolQ >> 8;
                        sendbuffer[sendbuffer[1] + 43] = gps_data.RevWrite_data.ZvolQ;

                        sendbuffer[sendbuffer[1] + 44] = SINGVOL_G;
                        sendbuffer[sendbuffer[1] + 45] = gps_data.RevWrite_data.SingvolG >> 8;
                        sendbuffer[sendbuffer[1] + 46] = gps_data.RevWrite_data.SingvolG;

                        sendbuffer[sendbuffer[1] + 47] = SINGVOL_GH;
                        sendbuffer[sendbuffer[1] + 48] = gps_data.RevWrite_data.SingvolGH >> 8;
                        sendbuffer[sendbuffer[1] + 49] = gps_data.RevWrite_data.SingvolGH;

                        sendbuffer[sendbuffer[1] + 50] = SINGOVERTIME_G;
                        sendbuffer[sendbuffer[1] + 51] = gps_data.RevWrite_data.SingvolGtime >> 8;
                        sendbuffer[sendbuffer[1] + 52] = gps_data.RevWrite_data.SingvolGtime;

                        sendbuffer[sendbuffer[1] + 53] = SINGVOL_Q;
                        sendbuffer[sendbuffer[1] + 54] = gps_data.RevWrite_data.SingvolQ >> 8;
                        sendbuffer[sendbuffer[1] + 55] = gps_data.RevWrite_data.SingvolQ;

                        sendbuffer[sendbuffer[1] + 56] = SINGVOL_QH;
                        sendbuffer[sendbuffer[1] + 57] = gps_data.RevWrite_data.SingvolQH >> 8;
                        sendbuffer[sendbuffer[1] + 58] = gps_data.RevWrite_data.SingvolQH;

                        sendbuffer[sendbuffer[1] + 59] = SINGOVERTIME_Q;
                        sendbuffer[sendbuffer[1] + 60] = gps_data.RevWrite_data.SingvolQtime >> 8;
                        sendbuffer[sendbuffer[1] + 61] = gps_data.RevWrite_data.SingvolQtime;

                        sendbuffer[sendbuffer[1] + 62] = CELLXCB;
                        sendbuffer[sendbuffer[1] + 63] = gps_data.RevWrite_data.CellXyc >> 8;
                        sendbuffer[sendbuffer[1] + 64] = gps_data.RevWrite_data.CellXyc;

                        sendbuffer[sendbuffer[1] + 65] = OUTCHGCURR_G;
                        sendbuffer[sendbuffer[1] + 66] = gps_data.RevWrite_data.OutcurrG >> 8;
                        sendbuffer[sendbuffer[1] + 67] = gps_data.RevWrite_data.OutcurrG;

                        sendbuffer[sendbuffer[1] + 68] = OUTCURRTIME_G;
                        sendbuffer[sendbuffer[1] + 69] = gps_data.RevWrite_data.OutcurrGtime >> 8;
                        sendbuffer[sendbuffer[1] + 70] = gps_data.RevWrite_data.OutcurrGtime;

                        sendbuffer[sendbuffer[1] + 71] = CHGCURR_G;
                        sendbuffer[sendbuffer[1] + 72] = gps_data.RevWrite_data.ChgcurrG >> 8;
                        sendbuffer[sendbuffer[1] + 73] = gps_data.RevWrite_data.ChgcurrG;

                        sendbuffer[sendbuffer[1] + 74] = CHGCURRTIME_G;
                        sendbuffer[sendbuffer[1] + 75] = gps_data.RevWrite_data.ChgcurrGtime >> 8;
                        sendbuffer[sendbuffer[1] + 76] = gps_data.RevWrite_data.ChgcurrGtime;

                        sendbuffer[sendbuffer[1] + 77] = EQUALIONVOL;
                        sendbuffer[sendbuffer[1] + 78] = gps_data.RevWrite_data.Equalivol >> 8;
                        sendbuffer[sendbuffer[1] + 79] = gps_data.RevWrite_data.Equalivol;

                        sendbuffer[sendbuffer[1] + 80] = EQUALIVOLC;
                        sendbuffer[sendbuffer[1] + 81] = gps_data.RevWrite_data.Equalivolcc >> 8;
                        sendbuffer[sendbuffer[1] + 82] = gps_data.RevWrite_data.Equalivolcc;

                        sendbuffer[sendbuffer[1] + 83] = EQUALIOPEN;
                        sendbuffer[sendbuffer[1] + 84] = gps_data.RevWrite_data.EqualiON; //--------


                        sendbuffer[sendbuffer[1] + 85] = POWTMPPORT;
                        sendbuffer[sendbuffer[1] + 86] = gps_data.RevWrite_data.PowTmp >> 8;
                        sendbuffer[sendbuffer[1] + 87] = gps_data.RevWrite_data.PowTmp;

                        sendbuffer[sendbuffer[1] + 88] = POWTMPHH;
                        sendbuffer[sendbuffer[1] + 89] = gps_data.RevWrite_data.PowTmpH >> 8;
                        sendbuffer[sendbuffer[1] + 90] = gps_data.RevWrite_data.PowTmpH;

                        sendbuffer[sendbuffer[1] + 91] = EQUALITMPPORT;
                        sendbuffer[sendbuffer[1] + 92] = gps_data.RevWrite_data.Equaltmpb >> 8;
                        sendbuffer[sendbuffer[1] + 93] = gps_data.RevWrite_data.Equaltmpb;

                        sendbuffer[sendbuffer[1] + 94] = EQUALITMPHH;
                        sendbuffer[sendbuffer[1] + 95] = gps_data.RevWrite_data.EqualtmpH >> 8;
                        sendbuffer[sendbuffer[1] + 96] = gps_data.RevWrite_data.EqualtmpH;

                        sendbuffer[sendbuffer[1] + 97] = CELLTMOPORT;
                        sendbuffer[sendbuffer[1] + 98] = gps_data.RevWrite_data.CellTmp >> 8;
                        sendbuffer[sendbuffer[1] + 99] = gps_data.RevWrite_data.CellTmp;

                        sendbuffer[sendbuffer[1] + 100] = CHGGTMPPORT;
                        sendbuffer[sendbuffer[1] + 101] = gps_data.RevWrite_data.CellChgTmpG >> 8;
                        sendbuffer[sendbuffer[1] + 102] = gps_data.RevWrite_data.CellChgTmpG;

                        sendbuffer[sendbuffer[1] + 103] = OUTGTMPPORT;
                        sendbuffer[sendbuffer[1] + 104] = gps_data.RevWrite_data.CellOutTmpG >> 8;
                        sendbuffer[sendbuffer[1] + 105] = gps_data.RevWrite_data.CellOutTmpG;

                        sendbuffer[sendbuffer[1] + 106] = CHGDTMPPORT;
                        sendbuffer[sendbuffer[1] + 107] = gps_data.RevWrite_data.ChgTmpD >> 8;
                        sendbuffer[sendbuffer[1] + 108] = gps_data.RevWrite_data.ChgTmpD;

                        sendbuffer[sendbuffer[1] + 109] = CHGDTMPPORTHH;
                        sendbuffer[sendbuffer[1] + 110] = gps_data.RevWrite_data.ChgTmpDH >> 8;
                        sendbuffer[sendbuffer[1] + 111] = gps_data.RevWrite_data.ChgTmpDH;

                        sendbuffer[sendbuffer[1] + 112] = OUTCHGDTMPPORT;
                        sendbuffer[sendbuffer[1] + 113] = gps_data.RevWrite_data.OutTmpD >> 8;
                        sendbuffer[sendbuffer[1] + 114] = gps_data.RevWrite_data.OutTmpD;

                        sendbuffer[sendbuffer[1] + 115] = OUTCHGDTMPHH;
                        sendbuffer[sendbuffer[1] + 116] = gps_data.RevWrite_data.OutTmpDH >> 8;
                        sendbuffer[sendbuffer[1] + 117] = gps_data.RevWrite_data.OutTmpDH;

                        sendbuffer[sendbuffer[1] + 118] = CELLNUM;
                        sendbuffer[sendbuffer[1] + 119] = gps_data.RevWrite_data.Cellnum;

                        sendbuffer[sendbuffer[1] + 120] = CELLRLS;
                        sendbuffer[sendbuffer[1] + 121] = gps_data.RevWrite_data.CellRl >> 24;
                        sendbuffer[sendbuffer[1] + 122] = gps_data.RevWrite_data.CellRl >> 16;
                        sendbuffer[sendbuffer[1] + 123] = gps_data.RevWrite_data.CellRl >> 8;
                        sendbuffer[sendbuffer[1] + 124] = gps_data.RevWrite_data.CellRl;

                        sendbuffer[sendbuffer[1] + 125] = CHGMOSKG;
                        sendbuffer[sendbuffer[1] + 126] = gps_data.RevWrite_data.ChgMOS;

                        sendbuffer[sendbuffer[1] + 127] = OUTMOSKG;
                        sendbuffer[sendbuffer[1] + 128] = gps_data.RevWrite_data.OutMOS;

                        sendbuffer[sendbuffer[1] + 129] = CURRBZ;
                        sendbuffer[sendbuffer[1] + 130] = gps_data.RevWrite_data.CurrJZ >> 8;
                        sendbuffer[sendbuffer[1] + 131] = gps_data.RevWrite_data.CurrJZ;

                        sendbuffer[sendbuffer[1] + 132] = BFBADRR;
                        sendbuffer[sendbuffer[1] + 133] = gps_data.RevWrite_data.BHBAddr;

                        sendbuffer[sendbuffer[1] + 134] = CELLTYPE;
                        sendbuffer[sendbuffer[1] + 135] = gps_data.RevWrite_data.Celltype;

                        sendbuffer[sendbuffer[1] + 136] = SLEEPTIME;
                        sendbuffer[sendbuffer[1] + 137] = gps_data.RevWrite_data.SleepTime >> 8;
                        sendbuffer[sendbuffer[1] + 138] = gps_data.RevWrite_data.SleepTime;

                        sendbuffer[sendbuffer[1] + 139] = DRLBEEP;
                        sendbuffer[sendbuffer[1] + 140] = gps_data.RevWrite_data.DRLNum;

                        sendbuffer[sendbuffer[1] + 141] = SDATAPASS;
                        memcpy(&sendbuffer[sendbuffer[1] + 142], gps_data.RevWrite_data.Pass, 10);

                        sendbuffer[sendbuffer[1] + 152] = ZCHGKG;
                        sendbuffer[sendbuffer[1] + 153] = gps_data.RevWrite_data.ZChgON;

                        sendbuffer[sendbuffer[1] + 154] = EQUT_ID;
                        memcpy(&sendbuffer[sendbuffer[1] + 155], gps_data.RevWrite_data.EquID, 8);

                        sendbuffer[sendbuffer[1] + 163] = CCDAT;
                        sendbuffer[sendbuffer[1] + 164] = gps_data.RevWrite_data.CCDat[0];
                        sendbuffer[sendbuffer[1] + 165] = gps_data.RevWrite_data.CCDat[1];
                        sendbuffer[sendbuffer[1] + 166] = gps_data.RevWrite_data.CCDat[2];
                        sendbuffer[sendbuffer[1] + 167] = gps_data.RevWrite_data.CCDat[3];

                        sendbuffer[sendbuffer[1] + 168] = SYSTIME;
                        sendbuffer[sendbuffer[1] + 169] = gps_data.RevWrite_data.SysTime >> 24;
                        sendbuffer[sendbuffer[1] + 170] = gps_data.RevWrite_data.SysTime >> 16;
                        sendbuffer[sendbuffer[1] + 171] = gps_data.RevWrite_data.SysTime >> 8;
                        sendbuffer[sendbuffer[1] + 172] = gps_data.RevWrite_data.SysTime;

                        /*�汾����Ϣ*/
                        sendbuffer[sendbuffer[1] + 173] = SOFT_NUM;
                        memcpy(gps_data.RevWrite_data.soft_num, soft_num_ZF, 15);
                        memcpy(&sendbuffer[sendbuffer[1] + 174], gps_data.RevWrite_data.soft_num, 15);

                        /*�Ƿ�����У��*/
                        sendbuffer[sendbuffer[1] + 189] = CURR_JZ;
                        sendbuffer[sendbuffer[1] + 190] = gps_data.RevWrite_data.CurrjzONOFF;

                        /*���ʵ������*/
                        sendbuffer[sendbuffer[1] + 191] = REALITY_Q;
                        sendbuffer[sendbuffer[1] + 192] = gps_data.RevWrite_data.Reali_Q >> 24;
                        sendbuffer[sendbuffer[1] + 193] = gps_data.RevWrite_data.Reali_Q >> 16;
                        sendbuffer[sendbuffer[1] + 194] = gps_data.RevWrite_data.Reali_Q >> 8;
                        sendbuffer[sendbuffer[1] + 195] = gps_data.RevWrite_data.Reali_Q;

                        sendbuffer[sendbuffer[1] + 196] = XXINGID;
                        memcpy(&sendbuffer[sendbuffer[1] + 197], gps_data.RevWrite_data.XID, 24);
                        send_len = sendbuffer[1] + 221;

                        sendbuffer[sendbuffer[1] + 222] = GPSDVOL;
                        sendbuffer[sendbuffer[1] + 223] = gps_data.RevWrite_data.GpsDVol >> 8;
                        sendbuffer[sendbuffer[1] + 224] = gps_data.RevWrite_data.GpsDVol;

                        sendbuffer[sendbuffer[1] + 225] =  GPSDVOLH;
                        sendbuffer[sendbuffer[1] + 226] = gps_data.RevWrite_data.GpsDVolH >> 8;
                        sendbuffer[sendbuffer[1] + 227] = gps_data.RevWrite_data.GpsDVolH;

                        sendbuffer[sendbuffer[1] + 228] = SIDU_KAIGUAN;
                        sendbuffer[sendbuffer[1] + 229] = gps_data.RevWrite_data.ShiduKaiguan;

                        sendbuffer[sendbuffer[1] + 230] =  SIDU_VALUE;  //��ǰʪ����ֵ
                        sendbuffer[sendbuffer[1] + 231] = gps_data.RevWrite_data.ShiduValueNow;

                        sendbuffer[sendbuffer[1] + 232] = SIDU_PROTECT_VALUE;//ʪ�ȱ���ֵ
                        sendbuffer[sendbuffer[1] + 233] = gps_data.RevWrite_data.ShiduValueProtect;

                        sendbuffer[sendbuffer[1] + 234] = SHORT_CUR_VALUE;//��·����ֵ
                        sendbuffer[sendbuffer[1] + 235] = gps_data.RevWrite_data.ShortCurValue;

                        sendbuffer[sendbuffer[1] + 236] = SHORT_CUR_DELAY;    //��·������ʱ
                        sendbuffer[sendbuffer[1] + 237] = gps_data.RevWrite_data.ShortCurDelay >> 8;
                        sendbuffer[sendbuffer[1] + 238] = gps_data.RevWrite_data.ShortCurDelay;

                        sendbuffer[sendbuffer[1] + 239] = SwitchEnable;    //ʹ�ܿ���
                        sendbuffer[sendbuffer[1] + 240] = gps_data.RevWrite_data.EnableSwitch >> 8;
                        sendbuffer[sendbuffer[1] + 241] = gps_data.RevWrite_data.EnableSwitch;


                        sendbuffer[sendbuffer[1] + 242] = OUT2CURR_G;
                        sendbuffer[sendbuffer[1] + 243] = gps_data.RevWrite_data.CellOUT2CURR_G >> 8;
                        sendbuffer[sendbuffer[1] + 244] = gps_data.RevWrite_data.CellOUT2CURR_G;

                        sendbuffer[sendbuffer[1] + 245] = OUT2TIME_G;
                        sendbuffer[sendbuffer[1] + 246] = gps_data.RevWrite_data.CellOUT2TIME_G >> 8;
                        sendbuffer[sendbuffer[1] + 247] = gps_data.RevWrite_data.CellOUT2TIME_G;

                        sendbuffer[sendbuffer[1] + 248] = DRLBEEP_Jiao;
                        sendbuffer[sendbuffer[1] + 249] = gps_data.RevWrite_data.CellDRLBEEP_Jiao >> 8;
                        sendbuffer[sendbuffer[1] + 250] = gps_data.RevWrite_data.CellDRLBEEP_Jiao;

                        send_len = sendbuffer[1] + 251;

                        /*��������*/
                        Send_GpsFun(Bms_num, orde, Type, sendbuffer, send_len, recnum);
                    }

                    break;

                case WRI_ALLORDE: //дȫ��ָ��
                    if(Activate == 1)
                    {
                        u8 CelltypeLast = 0;
                        u8 CellnumLast = 0;
                        u16 temp = 0;
                        u8 WriteSingvolG_flag = 0;
                        u8 WriteSingvolGH_flag = 0;
                        u8 WriteSINGVOL_Q_flag = 0;
                        u8 WriteSINGVOL_QH_flag = 0;

                        Type = 0x01; //Ӧ��
                        memset(sendbuffer, 0, sizeof(sendbuffer)); //��������

                        if(gps_buf->gps_Rev_buf[11 + temp] == ZVOL_G)
                        {
                            gps_data.RevWrite_data.ZvolG = ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                            temp += 3;
                        }

                        if(gps_buf->gps_Rev_buf[11 + temp] == ZVOL_Q)
                        {
                            gps_data.RevWrite_data.ZvolQ = ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                            temp += 3;
                        }

                        if(gps_buf->gps_Rev_buf[11 + temp] == SINGVOL_G)
                        {
                            Gloa_SingvolG = ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);

                            if(Gloa_SingvolG >= 2000 && Gloa_SingvolG <= 4500)
                            {
                                gps_data.RevWrite_data.SingvolG = Gloa_SingvolG;
                                temp += 3;

                            }
                            else
                            {
                                WriteSingvolG_flag = 1;

                            }


                        }

                        if(WriteSingvolG_flag == 0)
                        {

                            if(gps_buf->gps_Rev_buf[11 + temp] == SINGVOL_GH)
                            {

                                Gloa_SingvolGH = ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);

                                if(Gloa_SingvolGH >= 2000 && Gloa_SingvolGH <= 4500)
                                {
                                    gps_data.RevWrite_data.SingvolGH = Gloa_SingvolGH;
                                    temp += 3;

                                }
                                else
                                {
                                    WriteSingvolGH_flag = 1;

                                }

                            }

                            if(WriteSingvolGH_flag == 0)
                            {
                                if(gps_buf->gps_Rev_buf[11 + temp] == SINGOVERTIME_G)
                                {
                                    gps_data.RevWrite_data.SingvolGtime = ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                    temp += 3;
                                }

                                if(gps_buf->gps_Rev_buf[11 + temp] == SINGVOL_Q)
                                {

                                    Gloa_SingvolQ = ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);

                                    if(Gloa_SingvolQ >= 1000 && Gloa_SingvolQ <= 3600)
                                    {
                                        gps_data.RevWrite_data.SingvolQ = Gloa_SingvolQ;
                                        temp += 3;

                                    }
                                    else
                                    {
                                        WriteSINGVOL_Q_flag = 1;

                                    }


                                }

                                if(WriteSINGVOL_Q_flag == 0)
                                {

                                    if(gps_buf->gps_Rev_buf[11 + temp] == SINGVOL_QH)
                                    {


                                        Gloa_SingvolQH = ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);

                                        if(Gloa_SingvolQH >= 1000 && Gloa_SingvolQH <= 3600)
                                        {
                                            gps_data.RevWrite_data.SingvolQH = Gloa_SingvolQH;
                                            temp += 3;

                                        }
                                        else
                                        {
                                            WriteSINGVOL_QH_flag = 1;

                                        }

                                    }

                                    if(WriteSINGVOL_QH_flag == 0)
                                    {
                                        if(gps_buf->gps_Rev_buf[11 + temp] == SINGOVERTIME_Q)
                                        {
                                            gps_data.RevWrite_data.SingvolQtime =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CELLXCB)
                                        {
                                            gps_data.RevWrite_data.CellXyc =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == OUTCHGCURR_G)
                                        {
                                            gps_data.RevWrite_data.OutcurrG =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == OUTCURRTIME_G)
                                        {
                                            gps_data.RevWrite_data.OutcurrGtime =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CHGCURR_G)
                                        {
                                            gps_data.RevWrite_data.ChgcurrG =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CHGCURRTIME_G)
                                        {
                                            gps_data.RevWrite_data.ChgcurrGtime =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == EQUALIONVOL)
                                        {
                                            gps_data.RevWrite_data.Equalivol =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == EQUALIVOLC)
                                        {
                                            gps_data.RevWrite_data.Equalivolcc =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == EQUALIOPEN)
                                        {
                                            gps_data.RevWrite_data.EqualiON =  gps_buf->gps_Rev_buf[12 + temp];
                                            temp += 2;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == POWTMPPORT)
                                        {
                                            gps_data.RevWrite_data.PowTmp =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == POWTMPHH)
                                        {
                                            gps_data.RevWrite_data.PowTmpH =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == EQUALITMPPORT)
                                        {
                                            gps_data.RevWrite_data.Equaltmpb =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == EQUALITMPHH)
                                        {
                                            gps_data.RevWrite_data.EqualtmpH =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CELLTMOPORT)
                                        {
                                            gps_data.RevWrite_data.CellTmp =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CHGGTMPPORT)
                                        {
                                            gps_data.RevWrite_data.CellChgTmpG =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == OUTGTMPPORT)
                                        {
                                            gps_data.RevWrite_data.CellOutTmpG =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CHGDTMPPORT)
                                        {
                                            gps_data.RevWrite_data.ChgTmpD =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CHGDTMPPORTHH)
                                        {
                                            gps_data.RevWrite_data.ChgTmpDH =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == OUTCHGDTMPPORT)
                                        {
                                            gps_data.RevWrite_data.OutTmpD =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == OUTCHGDTMPHH)
                                        {
                                            gps_data.RevWrite_data.OutTmpDH =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CELLNUM)
                                        {
                                            CellnumLast = gps_buf->gps_Rev_buf[12 + temp];
                                            SETIO(VPRO_V11);//����309����
                                            num_sconf = 0;
                                            SetACanshu = 0;
                                            num_sconf =  gps_buf->gps_Rev_buf[12 + temp] & 0x0F;
                                            delay_ms(20);
                                            SetACanshu = (data_309_A.EEPROMRevdata.Sconf1.datas & 0xF0);
                                            SetACanshu = SetACanshu | num_sconf;
                                            MTPWrite_fun_1(EEPROM_SCONF1, 1, &SetACanshu);
                                            RESETIO(VPRO_V11);//����309����
                                            ResetAFE_1();
                                            temp += 2;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CELLRLS)
                                        {
                                            if(gps_data.RevWrite_data.CellRl != (u32)(((gps_buf->gps_Rev_buf[12 + temp] << 8) | (gps_buf->gps_Rev_buf[13 + temp])) * 65536 + ((gps_buf->gps_Rev_buf[14 + temp] << 8) | gps_buf->gps_Rev_buf[15 + temp])))
                                            {
                                                SOCinit = 0;
                                                SOCinit_bit = 0;
                                            }

                                            gps_data.RevWrite_data.CellRl	= (u32)(((gps_buf->gps_Rev_buf[12 + temp] << 8) | (gps_buf->gps_Rev_buf[13 + temp])) * 65536 + ((gps_buf->gps_Rev_buf[14 + temp] << 8) | gps_buf->gps_Rev_buf[15 + temp]));
                                            temp += 5;

                                            /*����ʵ������Լ��*/
                                            if(gps_data.RevWrite_data.Reali_Q > gps_data.RevWrite_data.CellRl)
                                                gps_data.RevWrite_data.Reali_Q = gps_data.RevWrite_data.CellRl;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CHGMOSKG)
                                        {
                                            gps_data.RevWrite_data.ChgMOS = gps_buf->gps_Rev_buf[12 + temp];

                                            if(gps_data.RevWrite_data.ChgMOS == 1) //�򿪳��MOS��
                                            {
                                                Chg_Lock = 0;

                                                if(ChgMos_bit == 0)
                                                {

                                                    Free309CHGMos();
                                                    ChgMos_bit = 0;
                                                }
                                                else
                                                {
                                                    if(Chg_Flag == 0)
                                                    {

                                                        Free309CHGMos();
                                                        ChgMos_bit = 0;
                                                    }
                                                }
                                            }
                                            else						             //�رճ��MOS��
                                            {
                                                Chg_Lock = 1;

                                                Shut309CHGMos();
                                                ChgMos_bit = 1;
                                            }

                                            temp += 2;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == OUTMOSKG)
                                        {
                                            gps_data.RevWrite_data.OutMOS = gps_buf->gps_Rev_buf[12 + temp];

                                            if(gps_data.RevWrite_data.OutMOS == 1) //�򿪷ŵ�MOS��
                                            {
                                                Out_Lock = 0;

                                                if(OutMos_bit == 0)
                                                {

                                                    Free309DSGMos();
                                                    OutMos_bit = 0;
                                                }
                                                else
                                                {
                                                    if(Out_flag == 0)
                                                    {

                                                        Free309DSGMos();
                                                        OutMos_bit = 0;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                Out_Lock = 1;

                                                Shut309DSGMos();
                                                OutMos_bit = 1;
                                            }

                                            temp += 2;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CURRBZ)
                                        {
                                            gps_data.RevWrite_data.CurrJZ =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == BFBADRR)
                                        {
                                            gps_data.RevWrite_data.BHBAddr = gps_buf->gps_Rev_buf[12 + temp];
                                            temp += 2;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CELLTYPE)
                                        {
                                            CelltypeLast = gps_buf->gps_Rev_buf[12 + temp];
                                            temp += 2;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == SLEEPTIME)
                                        {
                                            gps_data.RevWrite_data.SleepTime =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == DRLBEEP)
                                        {
                                            gps_data.RevWrite_data.DRLNum = gps_buf->gps_Rev_buf[12 + temp];
                                            temp += 2;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == SDATAPASS)
                                        {
                                            memcpy(gps_data.RevWrite_data.Pass, &gps_buf->gps_Rev_buf[12 + temp], 10);
                                            temp += 11;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == ZCHGKG)
                                        {
                                            gps_data.RevWrite_data.ZChgON = gps_buf->gps_Rev_buf[12 + temp];
                                            temp += 2;

                                            if(gps_data.RevWrite_data.ZChgON >= 1)	SpecChargerFlag = 1;//ר�ó����
                                            else
                                            {
                                                SpecChargerFlag = 0;
                                                HDCurr_Flag = 0;
                                                HDCurr_num = 0;
                                            }

                                            flash_write_sys_flag(47);
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == EQUT_ID)
                                        {
                                            memcpy(gps_data.RevWrite_data.EquID, &gps_buf->gps_Rev_buf[12 + temp], 8);
                                            temp += 9;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CCDAT)
                                        {
                                            memcpy(gps_data.RevWrite_data.CCDat, &gps_buf->gps_Rev_buf[12 + temp], 4);
                                            temp += 5;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == SYSTIME)
                                        {
                                            gps_data.RevWrite_data.SysTime	= (u32)(((gps_buf->gps_Rev_buf[12 + temp] << 8) | (gps_buf->gps_Rev_buf[13 + temp])) * 65536 + ((gps_buf->gps_Rev_buf[14 + temp] << 8) | gps_buf->gps_Rev_buf[15 + temp]));
                                            temp += 5;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == CURR_JZ)
                                        {
                                            gps_data.RevWrite_data.CurrjzONOFF = gps_buf->gps_Rev_buf[12 + temp];
                                            temp += 2;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == REALITY_Q)
                                        {
                                            gps_data.RevWrite_data.Reali_Q	= (u32)(((gps_buf->gps_Rev_buf[12 + temp] << 8) | (gps_buf->gps_Rev_buf[13 + temp])) * 65536 + ((gps_buf->gps_Rev_buf[14 + temp] << 8) | gps_buf->gps_Rev_buf[15 + temp]));
                                            temp += 5;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == XXINGID)
                                        {
                                            memcpy(gps_data.RevWrite_data.XID, &gps_buf->gps_Rev_buf[12 + temp], 24);
                                            temp += 25;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == GPSDVOL)
                                        {
                                            gps_data.RevWrite_data.GpsDVol = ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == GPSDVOLH)
                                        {
                                            gps_data.RevWrite_data.GpsDVolH = ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == SIDU_KAIGUAN)
                                        {
                                            gps_data.RevWrite_data.ShiduKaiguan = gps_buf->gps_Rev_buf[12 + temp];
                                            temp += 2;
                                        }


                                        if(gps_buf->gps_Rev_buf[11 + temp] == SIDU_PROTECT_VALUE)
                                        {
                                            gps_data.RevWrite_data.ShiduValueProtect = gps_buf->gps_Rev_buf[12 + temp];
                                            temp += 2;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == SHORT_CUR_VALUE)
                                        {
                                            gps_data.RevWrite_data.ShortCurValue = gps_buf->gps_Rev_buf[12 + temp];
                                            temp += 2;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == SHORT_CUR_DELAY)
                                        {
                                            gps_data.RevWrite_data.ShortCurDelay =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == SwitchEnable)
                                        {
                                            gps_data.RevWrite_data.EnableSwitch =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == OUT2CURR_G)
                                        {
                                            gps_data.RevWrite_data.CellOUT2CURR_G =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == OUT2TIME_G)
                                        {
                                            gps_data.RevWrite_data.CellOUT2TIME_G =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }

                                        if(gps_buf->gps_Rev_buf[11 + temp] == DRLBEEP_Jiao)
                                        {
                                            gps_data.RevWrite_data.CellDRLBEEP_Jiao =  ((gps_buf->gps_Rev_buf[12 + temp] << 8) | gps_buf->gps_Rev_buf[13 + temp]);
                                            temp += 3;
                                        }





                                        if(gps_data.RevWrite_data.Celltype != CelltypeLast)
                                        {
                                            SOCinit_bit = 0;

                                            if(CelltypeLast == 0) //���
                                            {
                                                gps_data.RevWrite_data.SingvolG = 3650;
                                                gps_data.RevWrite_data.SingvolGtime = 4;
                                                gps_data.RevWrite_data.SingvolGH = 3600;
                                                gps_data.RevWrite_data.SingvolQ = 2800;
                                                gps_data.RevWrite_data.SingvolQtime = 4;
                                                gps_data.RevWrite_data.SingvolQH = 2900;
                                                gps_data.RevWrite_data.ChgcurrG = 20;
                                                gps_data.RevWrite_data.ChgcurrGtime = 64;
                                                gps_data.RevWrite_data.OutcurrG = 60;
                                                gps_data.RevWrite_data.OutcurrGtime = 60;

                                                gps_data.RevWrite_data.CellOUT2CURR_G = 80;
                                                gps_data.RevWrite_data.CellOUT2TIME_G = 4;

                                                gps_data.RevWrite_data.CellXyc = 1000;
                                                gps_data.RevWrite_data.Equalivol = 3300;
                                                gps_data.RevWrite_data.Equalivolcc = 10;
                                            }
                                            else if(CelltypeLast == 1) //��Ԫ
                                            {
                                                gps_data.RevWrite_data.SingvolG = 4200;
                                                gps_data.RevWrite_data.SingvolGtime = 4;
                                                gps_data.RevWrite_data.SingvolGH = 4100;
                                                gps_data.RevWrite_data.SingvolQ = 2800;
                                                gps_data.RevWrite_data.SingvolQtime = 4;
                                                gps_data.RevWrite_data.SingvolQH = 2900;
                                                gps_data.RevWrite_data.ChgcurrG = 20;
                                                gps_data.RevWrite_data.ChgcurrGtime = 64;
                                                gps_data.RevWrite_data.OutcurrG = 60;
                                                gps_data.RevWrite_data.OutcurrGtime = 60;

                                                gps_data.RevWrite_data.CellOUT2CURR_G = 80;
                                                gps_data.RevWrite_data.CellOUT2TIME_G = 4;

                                                gps_data.RevWrite_data.CellXyc = 1000;
                                                gps_data.RevWrite_data.Equalivol = 4000;
                                                gps_data.RevWrite_data.Equalivolcc = 10;
                                            }
                                            else if(CelltypeLast == 2) //�����
                                            {
                                                gps_data.RevWrite_data.SingvolG = 2300;
                                                gps_data.RevWrite_data.SingvolGtime = 4;
                                                gps_data.RevWrite_data.SingvolGH = 2250;
                                                gps_data.RevWrite_data.SingvolQ = 1500;
                                                gps_data.RevWrite_data.SingvolQtime = 4;
                                                gps_data.RevWrite_data.SingvolQH = 1600;
                                                gps_data.RevWrite_data.ChgcurrG = 20;
                                                gps_data.RevWrite_data.ChgcurrGtime = 64;
                                                gps_data.RevWrite_data.OutcurrG = 60;
                                                gps_data.RevWrite_data.OutcurrGtime = 60;

                                                gps_data.RevWrite_data.CellOUT2CURR_G = 80;
                                                gps_data.RevWrite_data.CellOUT2TIME_G = 4;


                                                gps_data.RevWrite_data.CellXyc = 1000;
                                                gps_data.RevWrite_data.Equalivol = 2000;
                                                gps_data.RevWrite_data.Equalivolcc = 5;
                                            }
                                        }

                                        if(gps_data.RevWrite_data.Cellnum != CellnumLast)
                                        {
                                            gps_data.RevWrite_data.ZvolG = gps_data.RevWrite_data.SingvolG / 10.0 * CellnumLast;
                                            gps_data.RevWrite_data.ZvolQ = gps_data.RevWrite_data.SingvolQ / 10.0 * CellnumLast;
                                        }


                                        gps_data.RevWrite_data.Celltype = CelltypeLast;
                                        gps_data.RevWrite_data.Cellnum = CellnumLast;

                                        /*�洢����*/
                                        flash_write_sys_flag_ALL();

                                        /*���ݷ���*/
                                        sendbuffer[0] = 0xFF;
                                        send_len = 1;
                                        /*��������*/
                                        Send_GpsFun(Bms_num, orde, Type, sendbuffer, send_len, recnum);

                                    }
                                }

                            }
                        }
                    }

                    break;

                case STOP_309_WR:
                    if(Activate == 1)
                    {
                        switch(b_addr)
                        {
                            case 0x01:
                                stopstart_309Flag = gps_buf->gps_Rev_buf[12];

                                if(stopstart_309Flag == 1)
                                    IIC_1_Init(1);
                                else
                                    IIC_1_Init(0);

                                break;

                            default:
                                break;
                        }


                    }

                    break;

                default:
                    break;
            }
        }

        memset(gps_buf->gps_Rev_buf, 0, 355);
    }
}


void Alarm_To_GPS()
{



}
