#include "stm32f10x.h"
#include "stm32f10x_conf.h"

#include "button/iobutton.h"
#include "timer/ntimer.h"
#include <string.h>
#include <stdBool.h>
#include <stdio.h>
#include <math.h>
#include "datahand.h"
#include "gpioinit.h"
#include "perconfig.h"
#include "delay.h"
#include "basetime.h"
#include "usart.h"
#include "iobind.h"
#include "joinbind.h"
#include "IIc.h"
#include "gpsnet.h"
#include "IIc.h"
#include "SH367309.h"
#include "485.h"
#include "stmflash.h"
#include "flash.h"
#include "Jdy_19.h"

#define SOHNUM 200

u8 GPS_Time_Start_Flag = 0;
u8 GPS_LowPower_Flag = 0;
u8 GPS_tongxin_Flag = 0;
u16 GPS_TimeCnt = 0;

u8 Set_SOH_Flag = 0;
u8 Set_SOH_OVFlag = 0;
u8 Set_SOH_DVFlag = 0;
double RongLiang = 0;
double Cell_Out_RL = 0;
u32 NewRongLiang = 0;

u8 DSG_CHG_Switch_Flag = 0;
u8 DSG_Switch_Flag = 0;
u8 CHG_Switch_Flag = 0;

/*��ŵ籣��״̬λ*/
u8 Chg_Flag = 0;  //��籣�� 1����
u8 Out_flag = 0;  //�ŵ籣�� 1����
u8 Chg_Lock = 0;  //��籣�� ����
u8 Out_Lock = 0;  //�ŵ籣�� ����

u8 DS_MCU_Flag = 0;
u8 CH_MCU_Flag = 0;

/*ȫ�ֱ���*/
u8    Cell_Soc = 0;      //���SOC
u8 Cell_Soc_Temp = 0;
float IntVolume = 0;   //��ʼ������ AH
float OutSOC_xs = 1.03;   //�ŵ�SOCϵ��
float ChgSOC_xs = 1.03;   //���SOCϵ��
float SOH_xs = 0;      //SOHϵ��
float Q_hs = 0;        //ʵ�������ͱ����������
u16 Cell_usnum = 0;	   //���ѭ������
u32 Cell_Outrl = 0;    //���ѭ���ŵ�������
u8  Off_lint   = 0;    //���߹��ϴ���
u8  Out_Dea    = 0;    //�ŵ�ʧЧ����
u8  Chg_Dea    = 0;    //���ʧЧ����
u8  Cell_Tmp   = 0;    //��س��´���
u8  Pow_Tmp    = 0;    //���ʰ峬�´���
u8  Chg_Moshit = 0;    //���Mos�ܹ��ϴ���
u8  Out_Moshit = 0;    //�ŵ�MOs�ܹ��ϴ���
float Curr_Res = 0.0;  //����У׼ֵ

/*��ŵ�MOS���Ʊ�ʶ*/
u8 ChgMos_bit_last = 0;
u8 ChgMos_bit = 0;              //���MOS���л���ʶ
u8 OutMos_bit_last = 0;
u8 OutMos_bit = 0;              //�ŵ�MOS���л���ʶ
u16 Out_curr = 0;               //�ŵ���� ��λ��0.01A

/*�����ѹ��־λ����*/
u8 dt_Dchggvol[32] = {0};

/*SOCУ׼��ʶλ*/
u8  SocFlag_Chg = 0;
u32 SocFlag_Chg_Num = 0;
u16 numberdell = 0;
u8  SOCinit = 0;
u8  SOCinit_bit = 0;

/*���ϱ�ʶ*/
u16 Hitsturt = 0;
u8  HitFlag = 0;
/*���ϱ�ʶ2*/
u8  Hitsturt_2 = 0;
u8  Hitsturt_22 = 0;
u8  HitFlag_22 = 0;
/*�͹�����ر�ʶ*/
u8  Time_sce = 0;//��
u8  Time_min = 0;//��
u8  Time_hous = 0;//ʱ

u8  dgpow_bit = 0;     //1�����͹���
u8  dgpow_Time_1 = 0; //�͹��Ŀ���ʱһСʱ��ȡһ������
u8  dgpow_count = 0;  //�͹�����ʱ����
u8  dgPowL_TC = 0;     //�˳���ʶ

u32 nedex = 0;
/*�����_�Ƿ��е�����ʶ*/
u8  HDCurr_Flag = 0;
u16 HDCurr_num = 0;
/*����Լ������*/
u8 Out_curr_Count = 0;
u8 Chg_curr_Count = 0;
/*ָʾ�Ʊ�ʶ*/
u8 count = 0;
u8 tX_bit = 0;
u8 LED_1_bit = 0;
u8 LED_2_bit = 0;
/*����4���־*/
u8 yc_timecount = 0;
u8 yc_timeflat = 0;

u16 cell_vol_max = 0; //��ߵ�о��ѹ
u16 cell_vol_min = 0; //��͵�о��ѹ
u16 cell_vol_num = 0; //���ƽ����ѹ
u8  cellmaxnum = 0;
u8  cellminnum = 0;
u8  ZeroCur5Min = 0;
u8  OverVolFlag = 0;
u8  LowVolFlag  = 0;
u8  Vol4180Flag  = 0;
u8  Vol3500Flag  = 0;
u8  ShiDuFlag = 0;
u8  ShiDuFlag_OVER = 0;


u8  Init_SOC_8S = 0;
u8  Init_SOC_8S_flag = 0;
u8  OverVol_Alarm[32] = {0};
u8  LowerVol_Alarm[32] = {0};
u16 Cores_Vol[32];
u16 CellA_NUM = 0;
u16 CellB_NUM = 0;
u16 Total_Cell_VOl = 0;
u8 CHG_DSG_Status = 0;


u16 cell_Vol_old[32] = {0};
u16 cell_Vol_New[32] = {0};
u16 cell_Vol_Cha = 0;
u8  cell_Vol_Cha_flag = 0;
u8  cell_Vol_Cha_Alarmflag = 0;
u16 Ya_Cha_Diaoxian = 0;
u8 ZhuDAlarm_Flag = 0;
u16 Yacha_TimeCount = 0;


OVER_Time_Struct  Vol4180_Over_time = {0}; //��ʱ���
OVER_Time_Struct  Vol3500_Over_time = {0}; //��ʱ���


s16 Cell_MT_Temper[3] = {0};
s16 Cell_MT_Temper2[3] = {0};
s16 Cell_MT_Temp_MAX = 0;
s16 Cell_MT_Temp_Min = 0;
s16 Cell_MT_Temp_AVR = 0;
u8 Cell_MT_Temp_MAX_Num = 0;
u8 Cell_MT_Temp_Min_Num = 0;
u8 shengyu_jiao_flag = 0;

u8  Equal_Buffer[2][2] = {0};   //ƽ����ƼĴ���ֵ����


/*
*��������Get_Temp
*����������NTC_Res
*��������ֵ�������¶�ֵ �з�������
*�������ܣ�����Rt��������ֵ ����¶�
*/
const float Rp = 10000.0;      //10K NTC���賣���±�׼��ֹ
const float T2 = (273.15 + 25.0); //T2	 �������¶�
const float Bx = 3435.0;       //ϵ��B
const float Ka = 273.15;       //�����¶�

signed int Get_Temp(u32 NTC_Res)
{
    int   tmp;
    float Rt;
    float temp;

    Rt = NTC_Res;	 //like this R=10000, T2=273.15+25,B=3435, RT=10000*EXP(3435*(1/T1-1/(273.15+25)),
    temp = Rt / Rp;
    temp = log(temp);//ln(Rt/Rp)
    temp /= Bx; //ln(Rt/Rp)/B
    temp += (1 / T2);
    temp = 1 / (temp);
    temp -= Ka;

    if(temp < 0 && temp >= -10)	        temp = temp - 2;
    else if(temp < -10 && temp >= -20)	temp = temp - 3;
    else if(temp < -20 && temp >= -30)	temp = temp - 4;
    else if(temp < -30 && temp >= -40)	temp = temp - 5;

    tmp = temp;
    return tmp;
}

//��Ԫ
u8 updataSOC(void)
{
    u8   SOC_Tmp;

    if(cell_vol_max < 3300)
    {
        SOC_Tmp = 5;
    }

    if((cell_vol_max >= 3300) && (cell_vol_max <= gps_data.RevWrite_data.SingvolGH))
    {

        SOC_Tmp = (cell_vol_max - 3250) / 8.9;
    }

    if(cell_vol_max > gps_data.RevWrite_data.SingvolGH)
    {
        SOC_Tmp = 100;
    }

    return SOC_Tmp;


}

//���
u8 updataCell_0SOC(void)
{
    u8   SOC_Tmp;

    if((cell_vol_max >= 2800) && (cell_vol_max <= 3000))
    {
        SOC_Tmp = 5;
    }

    if((cell_vol_max > 3000) && (cell_vol_max <= 3100))
    {

        SOC_Tmp = 20;
    }

    if((cell_vol_max > 3100) && (cell_vol_max <= 3200))
    {

        SOC_Tmp = 40;
    }

    if((cell_vol_max > 3200) && (cell_vol_max <= 3300))
    {

        SOC_Tmp = 60;
    }

    if((cell_vol_max > 3300) && (cell_vol_max <= gps_data.RevWrite_data.SingvolGH))
    {

        SOC_Tmp = 80;
    }

    if(cell_vol_max > gps_data.RevWrite_data.SingvolGH)
    {

        SOC_Tmp = 100;
    }

    return SOC_Tmp;

}





u8 ReadMosState(void)
{
    u8 buff[2] = {0};
    u8 tt = 0;
    MTPRead_fun_1( MTP_BSTATUS3,  1, &buff[0] );
    tt = buff[0];
    return tt;
}

/*������:  data309_485_GPS_handelFun
* ��������:wu
* ��������ֵ:wu
* ��������: ����309 ���ݴ��� ����485 �� GPS���ϴ�
*/
void data309_485_GPS_handelFun(void)
{
    static u8 Flag___485 = 0;
    static u8 Resbit = 0;
    static float Cell_Outrlbuff = 0;
    u16 A_Cellnum = 0; //��309 оƬ��ش���
    u16 B_Cellnum = 0; //��309 оƬ��ش���
    float Rref = 0;   //�ڲ��ο�����(��λ��K��)
    float Rt1  = 0;   //����������ֵ(��λ��K��)
    u16 tmp_t1 = 0;
    u16 tmp_t2 = 0;
    u32 sumVol = 0;
    u8 i, j;
    u16 cell_Vol_1[32] = {0}; //��о��ѹ����
    u16 cell_Vol_2[32] = {0}; //��о��ѹ����
    /*������ر���*/

    u16 Equal_tmp_A = 0;
    u16 Equal_tmp_B = 0;
    u8 SOHnums = 0;	/*soH˥����*/
    u8 SSSOH = 0;

//   Equal_Buffer[2][2] = {0};   //ƽ����ƼĴ���ֵ����
    /*����У׼����*/
    if(gps_data.RevWrite_data.CurrjzONOFF == 1)
    {
        /*���Ե�����ֵУ׼-���У׼ - mA ��*/
        if(data_309_A.RAM_Revdata.Curh_l & 0x8000)  //��ʾ�ŵ�
        {
            Curr_Res =  (65535 - data_309_A.RAM_Revdata.Curh_l) * 200.0 / (26837.0 * gps_data.RevWrite_data.CurrJZ);
        }
        else									   //��ʾ���
        {
            Curr_Res =  data_309_A.RAM_Revdata.Curh_l * 200.0 / (26837.0 * gps_data.RevWrite_data.CurrJZ);
        }

        Resbit = 1;
    }

    if(gps_data.RevWrite_data.CurrjzONOFF == 0 && Resbit == 1)
    {
        flash_write_sys_flag(51);	   //�ѵ���ֵ�洢
        Resbit = 0;
    }

    Rref  = (6.8 + 0.05 * (float)(data_309_A.EEPROMRevdata.Tr & 0x7f));

    //��ش���
    A_Cellnum = (data_309_A.EEPROMRevdata.Sconf1.bits.cn3_cn0 & 0x0f);

    if(A_Cellnum < 5)
    {
        A_Cellnum = 16;
    }

    CellA_NUM = A_Cellnum;


    B_Cellnum = 0;


    if(numberdell != (A_Cellnum))
    {
        SocFlag_Chg = 0;
        SocFlag_Chg_Num = 0;
    }

    numberdell = A_Cellnum;
    sumVol = 0;

    for(i = 0; i < A_Cellnum; i++)
    {
        sumVol += data_309_A.RAM_Revdata.Cell.cellvol[i];

    }



    /*485����-ģ����*/
    Bms_tt_data.Anal_quanuion.Anal_quan.Total_VOl = (u16)((sumVol * 1.0) / 6.403 / 10); //��ذ�ʵ���ܵ�ѹ

    Total_Cell_VOl = (u16)((sumVol * 1.0) / 6.403 / 10); //��ذ�ʵ���ܵ�ѹ

    Bms_tt_data.Anal_quanuion.Anal_quan.Cores_num = (A_Cellnum + B_Cellnum); //��о����

    cell_vol_num = Bms_tt_data.Anal_quanuion.Anal_quan.Total_VOl * 10.0 / Bms_tt_data.Anal_quanuion.Anal_quan.Cores_num; //ƽ����ѹ

    /*�������ַ�SOC����*/
    Cell_Soc = IntVolume / (gps_data.RevWrite_data.CellRl * 1.0) * 100;

    if(Cell_Soc > 100) Cell_Soc = 100;


    //SOC�Ż���ֹ������ֵ���о��ѹ����ֵ���̫��20�����Ե�о��ѹ�����SOCΪ׼
    Cell_Soc_Temp = 0;


    Bms_tt_data.Anal_quanuion.Anal_quan.Pow_SOC = Cell_Soc; //SOC
    Bms_tt_data.Anal_quanuion.Anal_quan.Res_Capa = gps_data.RevWrite_data.CellRl * Cell_Soc / 100.0 * 100;  //0.01ah ʣ������

    SOHnums = gps_data.Rev_data.Cellusnum / SOHNUM;//     ���ʹ��ѭ������/200
    SSSOH = 100 - SOHnums;  //��ؽ���ֵ(ѭ��200�ξͼ�1)
    SOH_xs = 1 - ((SSSOH * 1.0) / 100.0);

    if(data_309_A.RAM_Revdata.Curh_l & 0x8000) //��ʾ�ŵ� ��������
    {
        Out_curr  =  (65535 - data_309_A.RAM_Revdata.Curh_l) * 200.0 / (26837 * Curr_Res) / 10.0;
		
		
        Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr = 0;

        HDCurr_num = 0;

        if(OutMos_bit == 0)
        {
            if((Out_curr > 20))
            {
                Out_curr_Count++;

                if(Out_curr_Count > 125)	Out_curr_Count = 3;
            }

            if( (Out_curr > 20) && (Out_curr <= (gps_data.RevWrite_data.OutcurrG + 20) * 100) )
            {
                IntVolume -= ((Out_curr / 100.0 * (1 / 1800.0)) * (OutSOC_xs + SOH_xs)) * Q_hs;
            }
        }

        if(IntVolume < 0)	IntVolume = 0;
    }
    else	//��ʾ���  ��������
    {
        Out_curr = 0;

        Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr = data_309_A.RAM_Revdata.Curh_l * 200.0 / (26837 * Curr_Res) / 10.0;


        if(ChgMos_bit == 0)
        {
            if(Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr > 50)
            {
                Chg_curr_Count++;

                if(Chg_curr_Count > 125)	Chg_curr_Count = 3;
            }

            if((Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr > 50) && (Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr <= (gps_data.RevWrite_data.ChgcurrG + 20) * 100))
            {


                Set_SOH_OVFlag = 0; //�����δ����磬���г��ʱ���SOHh������־λ
                Set_SOH_DVFlag = 0;
                RongLiang = 0; //
                shengyu_jiao_flag = 0;

                IntVolume += ((Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr / 100.0 * (1 / 1800.0)) * (ChgSOC_xs + SOH_xs)) * Q_hs; //2�������
            }
        }

        if(IntVolume > gps_data.RevWrite_data.CellRl)	IntVolume = gps_data.RevWrite_data.CellRl;
    }

//���ݵ���С��0.2A,��Ϊ�������Ϊ0
    if(Out_curr <= 20)
    {
        Out_curr = 0;
        Out_curr_Count = 0;
    }




    if(Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr <= 50)
    {
        Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr = 0;
        SocFlag_Chg = 0;
        SocFlag_Chg_Num = 0;
        HDCurr_num = 0;
        Chg_curr_Count = 0;
    }
    //�������������0.5A
    else
    {
        if((Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr > 50) && (Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr <= gps_data.RevWrite_data.ChgcurrG * 100))
        {
            SocFlag_Chg_Num++;
          

            if(SocFlag_Chg_Num >= 10)	
			{
				
				SocFlag_Chg = 1;
				SocFlag_Chg_Num=10;
			}

            
        }
    }


    if(Out_curr > 20 && Out_curr_Count < 3)	Out_curr = 0; //�ŵ紥����һ�����˲�

    if(Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr > 50 && Chg_curr_Count < 3)	Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr = 0;

    if(Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr <= 50 && Bms_tt_data.Anal_quanuion.Anal_quan.Total_VOl < 9000)
    {
        //SOC_���������
        float currjzz = 0;

        if(dgpow_bit == 0)
        {
            if(CH_MCU_Flag == 0 && DS_MCU_Flag == 0)
            {
                currjzz = 0.8 * 1000.0 / (Bms_tt_data.Anal_quanuion.Anal_quan.Total_VOl / 100.0);
                IntVolume -= ((currjzz / 1000.0 * (1 / 1800.0)) * (OutSOC_xs + SOH_xs)) * Q_hs; //2�������
            }
        }
        else
        {
            currjzz = 0.6 * 1000.0 / (Bms_tt_data.Anal_quanuion.Anal_quan.Total_VOl / 100.0);
            IntVolume -= ((currjzz / 1000.0 * (1 / 1800.0)) * (OutSOC_xs + SOH_xs)) * Q_hs; //2�������
        }

        if(IntVolume < 0)	IntVolume = 0;
    }

    /*��о�¶�*/
    Rt1 = (float)(data_309_A.RAM_Revdata.TEMP1h_l * 1.0) / (float)(32768 - data_309_A.RAM_Revdata.TEMP1h_l) * Rref;

    if(data_309_A.RAM_Revdata.TEMP1h_l == 32767)
        tmp_t1 = 120;
    else
        tmp_t1 = Get_Temp((u32)(Rt1 * 1000));

    Rt1 = (float)(data_309_A.RAM_Revdata.TEMP2h_l * 1.0) / (float)(32768 - data_309_A.RAM_Revdata.TEMP2h_l) * Rref;

    if(data_309_A.RAM_Revdata.TEMP2h_l == 32767)
        tmp_t2 = 120;
    else
        tmp_t2 = Get_Temp((u32)(Rt1 * 1000));

    Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp = tmp_t1;
    Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp  = tmp_t2;

    /*�忨�¶�*/
    Rt1 = (float)(data_309_A.RAM_Revdata.TEMP3h_l * 1.0) / (float)(32768 - data_309_A.RAM_Revdata.TEMP3h_l) * Rref;


    if(data_309_A.RAM_Revdata.TEMP3h_l == 32767)
        Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp = 120;
    else
        Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp = Get_Temp((u32)(Rt1 * 1000));





    //���ȿ��ƿ����� ��о�¶�С�ڵ��ڳ����±���ֵ���߻����¶�С�ڵ��ڳ����±���ֵ �Ҽ�⵽�����
    if(((Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp <= gps_data.RevWrite_data.ChgTmpD)) && (READIO(HotIO_IN) == 0))
    {
        SETIO(Hot_Control);  //��������

    }
    //���ȿ��ƹرգ� ��о�¶ȴ��ڵ��ڳ����±����ָ�ֵ���߻����¶ȴ��ڳ����»ָ�ֵ
    else if((Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp >= gps_data.RevWrite_data.ChgTmpDH) || (READIO(HotIO_IN) == 1))
    {

        RESETIO(Hot_Control);  //�رռ���
    }


    Cell_MT_Temper[0] = Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp;
    Cell_MT_Temper[1] = Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp;
    Cell_MT_Temper[2] = Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp;

    Cell_MT_Temper2[0] = Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp;
    Cell_MT_Temper2[1] = Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp;
    Cell_MT_Temper2[2] = Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp;

    Cell_MT_Temp_AVR = (Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp + Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp + Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp) / 3;

    //��������¶�

    for(i = 0; i < 2; i++)
    {
        for(j = 0; j < (2 - i); j++)
        {
            if(Cell_MT_Temper[j] > Cell_MT_Temper[j + 1])
            {
                s16 temper = Cell_MT_Temper[j + 1];
                Cell_MT_Temper[j + 1] = Cell_MT_Temper[j];
                Cell_MT_Temper[j] = temper;
            }
        }
    }

    Cell_MT_Temp_MAX = Cell_MT_Temper[2];


    for(i = 0; i < 3; i++)
    {
        //    if(cell_vol_max == Bms_tt_data.Anal_quanuion.monis[9 + i])
        if(Cell_MT_Temp_MAX == Cell_MT_Temper[i])
        {
            Cell_MT_Temp_MAX_Num = i;
            break;
        }
    }


    //��������¶�

    for(i = 0; i < 2; i++)
    {
        for(j = 0; j < (2 - i); j++)
        {
            if(Cell_MT_Temper2[j] < Cell_MT_Temper2[j + 1])
            {
                s16 temp = Cell_MT_Temper2[j + 1];
                Cell_MT_Temper2[j + 1] = Cell_MT_Temper2[j];
                Cell_MT_Temper2[j] = temp;
            }
        }
    }

    Cell_MT_Temp_Min = Cell_MT_Temper2[2];


    for(i = 0; i < 3; i++)
    {
        //  if(cell_vol_min == Bms_tt_data.Anal_quanuion.monis[9 + i])
        if(Cell_MT_Temp_Min == Cell_MT_Temper2[i])

        {
            Cell_MT_Temp_Min_Num = i;
            break;
        }
    }

    /*485��о��ѹ*/
    for(i = 0; i < A_Cellnum; i++)
    {
        Bms_tt_data.Anal_quanuion.monis[9 + i] = (u16)((data_309_A.RAM_Revdata.Cell.cellvol[i] * 1.0) / 6.403);
        Cores_Vol[i] = (u16)((data_309_A.RAM_Revdata.Cell.cellvol[i] * 1.0) / 6.403);
    }


    for(i = 0; i < B_Cellnum; i++)
    {
        if((A_Cellnum + i) < 20) //����ֻ֧��20����ѹ
        {

            Bms_tt_data.Anal_quanuion.monis[9 + A_Cellnum + i] = (u16)((data_309_B.RAM_Revdata.Cell.cellvol[i] * 1.0) / 6.403);

        }


        Cores_Vol[A_Cellnum + i] = (u16)((data_309_B.RAM_Revdata.Cell.cellvol[i] * 1.0) / 6.403);


    }

    /*485������*/
    /*��оѹ����� - ���ֵ*/


    memcpy(cell_Vol_1, &Cores_Vol[0], (A_Cellnum + B_Cellnum) * 2);
    memcpy(cell_Vol_2, &Cores_Vol[0], (A_Cellnum + B_Cellnum) * 2);


    //ѹ���
    if(FirstStart == 1)
    {

        memcpy(cell_Vol_old, &Cores_Vol[0], (A_Cellnum + B_Cellnum) * 2);

    }
    else
    {
        memcpy(cell_Vol_New, &Cores_Vol[0], (A_Cellnum + B_Cellnum) * 2);

        if(cell_Vol_Cha_flag == 0)
        {
            for(i = 0; i < (A_Cellnum + B_Cellnum) - 1; i++)
            {
                if(cell_Vol_old[i] >= cell_Vol_New[i])
                {
                    cell_Vol_Cha = cell_Vol_old[i] - cell_Vol_New[i];

                }
                else
                {
                    cell_Vol_Cha = cell_Vol_New[i] - cell_Vol_old[i];

                }

                if((cell_Vol_Cha >= gps_data.RevWrite_data.CellXyc) && (Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr >= 100 ))
                {
                    Yacha_TimeCount++;

                    if(Yacha_TimeCount >= (gps_data.RevWrite_data.ChgcurrGtime / 2))
                    {
                        Yacha_TimeCount = 0;
                        cell_Vol_Cha_flag = 1;
                        cell_Vol_Cha_Alarmflag = 1;
                        break;


                    }

                }
                else
                {
                    Yacha_TimeCount = 0;
                    cell_Vol_Cha_flag = 0;

                }

            }

        }

        memcpy(cell_Vol_old, &Cores_Vol[0], (A_Cellnum + B_Cellnum) * 2);

    }



    //��ߵ�ѹ

    for(i = 0; i < (A_Cellnum + B_Cellnum) - 1; i++)
    {
        for(j = 0; j < A_Cellnum + B_Cellnum - 1 - i; j++)
        {
            if(cell_Vol_1[j] > cell_Vol_1[j + 1])
            {
                u16 temp = cell_Vol_1[j + 1];
                cell_Vol_1[j + 1] = cell_Vol_1[j];
                cell_Vol_1[j] = temp;
            }
        }
    }

    cell_vol_max = cell_Vol_1[(A_Cellnum + B_Cellnum) - 1];

    /*�������*/
    for(i = 0; i < (A_Cellnum + B_Cellnum); i++)
    {
        //    if(cell_vol_max == Bms_tt_data.Anal_quanuion.monis[9 + i])
        if(cell_vol_max == Cores_Vol[i])
        {
            cellmaxnum = i;
            break;
        }
    }

    //��͵�ѹ

    for(i = 0; i < (A_Cellnum + B_Cellnum) - 1; i++)
    {
        for(j = 0; j < A_Cellnum + B_Cellnum - 1 - i; j++)
        {
            if(cell_Vol_2[j] < cell_Vol_2[j + 1])
            {
                u16 temp = cell_Vol_2[j + 1];
                cell_Vol_2[j + 1] = cell_Vol_2[j];
                cell_Vol_2[j] = temp;
            }
        }
    }

    cell_vol_min = cell_Vol_2[(A_Cellnum + B_Cellnum) - 1];


    for(i = 0; i < (A_Cellnum + B_Cellnum); i++)
    {
        //  if(cell_vol_min == Bms_tt_data.Anal_quanuion.monis[9 + i])
        if(cell_vol_min == Cores_Vol[i])

        {
            cellminnum = i;
            break;
        }
    }



    //��������ѹУ׼

    if(Out_curr >= 100 && Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr == 0 && shengyu_jiao_flag == 0 && (cell_vol_min <= gps_data.RevWrite_data.CellDRLBEEP_Jiao && cell_vol_min > gps_data.RevWrite_data.SingvolQ))
    {
        shengyu_jiao_flag = 1;

        Cell_Soc = gps_data.RevWrite_data.DRLNum;

        if(Cell_Soc >= 98) Cell_Soc = 100;

        IntVolume = Cell_Soc / 100.0 * gps_data.RevWrite_data.CellRl;

    }








    //ѹ���
    if((cell_vol_max - cell_vol_min) > gps_data.RevWrite_data.CellXyc)
    {
        if(yc_timeflat == 0)
        {
            yc_timecount++;

            if(yc_timecount >= gps_data.RevWrite_data.ChgcurrGtime / 2)
            {
                Bms_tt_data.Kaiguan[1] = 1;
                yc_timeflat = 1;
            }
        }
    }
    else
    {
        yc_timecount = 0; //���
        yc_timeflat = 0;
        Bms_tt_data.Kaiguan[1] = 0;
    }

    /*������*/
    if(Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr > (gps_data.RevWrite_data.ChgcurrG * 100))
    {
        Over_time.bits_4 = 1;

        if(Over_time.bits_4_cont_s >= gps_data.RevWrite_data.ChgcurrGtime)	Bms_tt_data.Kaiguan[2] = 1;
    }
    else  		 /*�޸Ļָ�ʱ��16��*/
    {
        if(Over_time.bits_4 == 1)
        {
            Over_time.bits_4 = 0;
            Over_time.bits_4_cont_s = 0;
        }

        if(Bms_tt_data.Kaiguan[2] == 1)	Over_time.bits_4_2 = 1; //�ָ���ʱ��ʼ����

        if(Over_time.bits_4_2_cont_s >= 12)   //12
        {
            Bms_tt_data.Kaiguan[2]  = 0;
            Over_time.bits_4_2 = 0;
            Over_time.bits_4_2_cont_s = 0;
        }
    }

    /*�ŵ����*/
    if(Out_curr > (gps_data.RevWrite_data.OutcurrG * 100) && (Out_curr <= (gps_data.RevWrite_data.CellOUT2CURR_G * 100)))
    {
        Over_time.bits_3 = 1;

        if(Over_time.bits_3_cont_s >= gps_data.RevWrite_data.OutcurrGtime)
        {
            Bms_tt_data.Kaiguan[3] = 1;

        }

    }
    else if(Out_curr > (gps_data.RevWrite_data.CellOUT2CURR_G * 100))
    {
        Over_time.bits_3 = 1;//�ŵ������־����ʱ�ж���ʹ��

        if(Over_time.bits_3_cont_s >= gps_data.RevWrite_data.CellOUT2TIME_G)
        {
            Bms_tt_data.Kaiguan[3] = 1;
        }


    }
    else   /*�޸Ļָ�ʱ��16��*/
    {
        if(Over_time.bits_3 == 1)
        {
            Over_time.bits_3 = 0;
            Over_time.bits_3_cont_s = 0;
        }

        if(Bms_tt_data.Kaiguan[3] == 1)	Over_time.bits_3_2 = 1; //�ָ���ʱ��ʼ����

        if(Over_time.bits_3_2_cont_s >= 12)
        {
            Bms_tt_data.Kaiguan[3]  = 0;
            Over_time.bits_3_2 = 0;
            Over_time.bits_3_2_cont_s = 0;
        }
    }

    /*��·������־λ*/
    if(data_309_A.RAM_Revdata.Bstrtus1.bits.SC == 1)
        Bms_tt_data.Kaiguan[4] = 1;
    else
        Bms_tt_data.Kaiguan[4] = 0;

    /*�����±���*/
    if(Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp >= gps_data.RevWrite_data.CellChgTmpG)
    {
        if(gps_data.RevWrite_data.EnableSwitch & 0x0002)//�¶����ο���ʹ��
        {
            Bms_tt_data.Kaiguan[5] = 0;
            Hitsturt_2 &= ~(1 << 2);

        }
        else
        {
            if(Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr >= 50)
            {

                Bms_tt_data.Kaiguan[5] = 1;
                Hitsturt_2 |= (1 << 2);
            }
        }
    }
    else
    {
        if(Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp  <= gps_data.RevWrite_data.CellChgTmpGH)
        {
            Bms_tt_data.Kaiguan[5] = 0;
            Hitsturt_2 &= ~(1 << 2);
        }
    }

    /*�ŵ���±���*/
    if(Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp >= gps_data.RevWrite_data.CellOutTmpG)
    {
        if(gps_data.RevWrite_data.EnableSwitch & 0x0002)//�¶����ο���ʹ��
        {
            Bms_tt_data.Kaiguan[6] = 0;
            Hitsturt_2 &= ~(1 << 0);
        }
        else
        {
            if(Out_curr >= 20)
            {
                Bms_tt_data.Kaiguan[6] = 1;
                Hitsturt_2 |= (1 << 0);
            }
        }
    }
    else
    {
        if(Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp  <= gps_data.RevWrite_data.CellOutTmpGH)
        {
            Bms_tt_data.Kaiguan[6] = 0;
            Hitsturt_2 &= ~(1 << 0);
        }
    }

    /*�����±���*/
    if(Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp  <= gps_data.RevWrite_data.ChgTmpD)
    {
        if(gps_data.RevWrite_data.EnableSwitch & 0x0002)//�¶����ο���ʹ��
        {
            Bms_tt_data.Kaiguan[7] = 0;
            Hitsturt_2 &= ~(1 << 3);
        }
        else
        {

            if(Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr >= 50)
            {
                Bms_tt_data.Kaiguan[7] = 1;
                Hitsturt_2 |= (1 << 3);
            }
        }
    }
    else
    {
        if(Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp  >= gps_data.RevWrite_data.ChgTmpDH)
        {
            Bms_tt_data.Kaiguan[7] = 0;
            Hitsturt_2 &= ~(1 << 3);
        }
    }

    /*�ŵ���±���*/
    if(Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp  <= gps_data.RevWrite_data.OutTmpD)
    {
        if(gps_data.RevWrite_data.EnableSwitch & 0x0002)//�¶����ο���ʹ��
        {
            Bms_tt_data.Kaiguan[8] = 0;
            Hitsturt_2 &= ~(1 << 1);
        }
        else
        {
            if(Out_curr >= 20)
            {
                Bms_tt_data.Kaiguan[8] = 1;
                Hitsturt_2 |= (1 << 1);
            }
        }
    }
    else
    {
        if(Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp  >= gps_data.RevWrite_data.OutTmpDH)
        {
            Bms_tt_data.Kaiguan[8] = 0;
            Hitsturt_2 &= ~(1 << 1);
        }
    }



    Vol4180Flag = 0;
    Vol3500Flag = 0;
    OverVolFlag = 0;
    /*�ڲ�ͨ���쳣*/
    Bms_tt_data.Kaiguan[11] = 0;

    /*��������ѹ����*/
    for(i = 0; i < (A_Cellnum + B_Cellnum); i ++)
    {
        //SOC�Ż�����ֹ���ɶ�������ʱ�ж�
        // if(Bms_tt_data.Anal_quanuion.monis[9 + i] >= 4180)
        if(Cores_Vol[i] >= gps_data.RevWrite_data.SingvolGH)
        {
            Vol4180_Over_time.bits_4180[i] = 1;

            if(Vol4180_Over_time.bits_4180_cont_s[i] >= gps_data.RevWrite_data.SingvolGtime)
            {
                Vol4180Flag = 1;
                Vol4180_Over_time.bits_4180_cont_s[i] = 0;
                Vol4180_Over_time.bits_4180[i] = 0;
            }

        }
        else
        {
            Vol4180_Over_time.bits_4180_cont_s[i] = 0;
            Vol4180_Over_time.bits_4180[i] = 0;

        }

        //SOC�Ż�����ֹ���ɶ�������ʱ�ж�
        // if(Bms_tt_data.Anal_quanuion.monis[9 + i] >= 3500)
        if(Cores_Vol[i] >= gps_data.RevWrite_data.SingvolGH)
        {
            Vol3500_Over_time.bits_3500[i] = 1;

            if(Vol3500_Over_time.bits_3500_cont_s[i] >= gps_data.RevWrite_data.SingvolGtime)
            {
                Vol3500Flag = 1;
                Vol3500_Over_time.bits_3500_cont_s[i] = 0;
                Vol3500_Over_time.bits_3500[i] = 0;
            }

        }
        else
        {
            Vol3500_Over_time.bits_3500_cont_s[i] = 0;
            Vol3500_Over_time.bits_3500[i] = 0;

        }




        //�����ѹ
        if(Cores_Vol[i] > gps_data.RevWrite_data.SingvolG)
        {
            Over_time.bits_1[i] = 1;

            if(Over_time.bits_1_cont_s[i] >= gps_data.RevWrite_data.SingvolGtime)
            {
                dt_Dchggvol[i] = 1;
                OverVolFlag = 1;
            }
        }
        else
        {
            Over_time.bits_1[i] = 0;
            Over_time.bits_1_cont_s[i] = 0;


            if(Cores_Vol[i] < gps_data.RevWrite_data.SingvolGH)
            {
                dt_Dchggvol[i] = 0;
            }

        }
    }

    //��������趨�����ĵ����ѹ����
    for(i = (A_Cellnum + B_Cellnum); i < 24; i++)
    {
        dt_Dchggvol[i] = 0;
    }

    /*�����쳣��ѹ����*/
    for(i = 0; i < (A_Cellnum + B_Cellnum); i ++)
    {

        if(Cores_Vol[i] > gps_data.RevWrite_data.SingvolG + 50)// //�����ѹ����ֵ
        {
            Over_time.bits_11[i] = 1;

            if(Over_time.bits_11_cont_s[i] >= gps_data.RevWrite_data.SingvolGtime)
            {
                if(i < 20)
                {
                    Bms_tt_data.Kaiguan[12 + i] = 1;
                }

                OverVol_Alarm[i] = 1;

            }
        }
        else
        {
            Over_time.bits_11[i] = 0;
            Over_time.bits_11_cont_s[i] = 0;


            if(Cores_Vol[i] < gps_data.RevWrite_data.SingvolGH + 50)
            {
                if(i < 20)
                {
                    Bms_tt_data.Kaiguan[12 + i] = 0;
                }

                OverVol_Alarm[i] = 0;
            }
        }

    }

    LowVolFlag = 0;

    /*����ŵ��ѹ����*/
    for(i = 0; i < (A_Cellnum + B_Cellnum); i ++)
    {
        //if(Bms_tt_data.Anal_quanuion.monis[9 + i] < gps_data.RevWrite_data.SingvolQ)// //����Ƿѹ����ֵ
        if(Cores_Vol[i] < gps_data.RevWrite_data.SingvolQ)// //����Ƿѹ����ֵ
        {
            Over_time.bits_2[i] = 1;

            if(Over_time.bits_2_cont_s[i] >= gps_data.RevWrite_data.SingvolQtime)//Ƿѹ����ʱ��
            {
                LowVolFlag = 1;

                if(i < 20)
                {
                    Bms_tt_data.Kaiguan[32 + i] = 1;
                }

                LowerVol_Alarm[i] = 1;
            }
        }
        else
        {
            Over_time.bits_2[i] = 0;
            Over_time.bits_2_cont_s[i] = 0;

            // if(Bms_tt_data.Anal_quanuion.monis[9 + i] > gps_data.RevWrite_data.SingvolQH)
            if(Cores_Vol[i] > gps_data.RevWrite_data.SingvolQH)
            {
                if(i < 20)
                {
                    Bms_tt_data.Kaiguan[32 + i] = 0;
                }

                LowerVol_Alarm[i] = 0;

            }
        }
    }

    //��������趨�����Ĺ�ѹ����
    for(i = (A_Cellnum + B_Cellnum); i < 24; i ++)
    {
        OverVol_Alarm[i] = 0;

    }

    //��������趨������Ƿѹ����
    for(i = (A_Cellnum + B_Cellnum); i < 24; i ++)
    {
        LowerVol_Alarm[i] = 0;

    }

    /*************************GPS���ݴ���***************************/
    /*���ڵ�ص�ѹmv*/
    for(i = 0; i < (A_Cellnum + B_Cellnum); i++)
    {
        gps_data.Rev_data.Singcellvol[i][0] = i + 1; //��غ�

        gps_data.Rev_data.Singcellvol[i][1] = Cores_Vol[i]  >> 8;
        gps_data.Rev_data.Singcellvol[i][2] = Cores_Vol[i] ;

    }

    for(i = A_Cellnum; i < 16; i++)
    {
        gps_data.Rev_data.Singcellvol[i][0] = i + 1; //��غ�

        gps_data.Rev_data.Singcellvol[i][1] = 0;
        gps_data.Rev_data.Singcellvol[i][2] = 0 ;

    }



    if(Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp >= 0)
    {
        gps_data.Rev_data.MosTmp = Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp;    //MOS���¶�

        if(gps_data.Rev_data.MosTmp > 100)	gps_data.Rev_data.MosTmp = 100;
    }
    else
    {
        gps_data.Rev_data.MosTmp = 100 - Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp;    //MOS���¶�

        if(gps_data.Rev_data.MosTmp > 140)	gps_data.Rev_data.MosTmp = 140;
    }




    if(Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp >= 0)
    {
        gps_data.Rev_data.QualiTmp = Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp;	 //��������¶�

        if(gps_data.Rev_data.QualiTmp > 100)	gps_data.Rev_data.QualiTmp = 100;
    }
    else
    {
        gps_data.Rev_data.QualiTmp = 100 - Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp; //��������¶�

        if(gps_data.Rev_data.QualiTmp > 140)	gps_data.Rev_data.QualiTmp = 140;
    }





    if(Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp >= 0)
    {
        gps_data.Rev_data.CellTmp = Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp;	 //����¶�

        if(gps_data.Rev_data.CellTmp > 100)
            gps_data.Rev_data.CellTmp = 100;
    }
    else
    {
        gps_data.Rev_data.CellTmp = 100 - Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp;	 //����¶�

        if(gps_data.Rev_data.CellTmp > 140)	gps_data.Rev_data.CellTmp = 140;//�����100��Ϊ140
    }





    gps_data.Rev_data.CellZvol = Bms_tt_data.Anal_quanuion.Anal_quan.Total_VOl; //�ܵ�ѹ

    if(data_309_A.RAM_Revdata.Curh_l & 0x8000)
        gps_data.Rev_data.Currdata = Out_curr + 10000;  //��ʾ�ŵ����
    else
        gps_data.Rev_data.Currdata = 10000 - Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr;   //��ʾ���

    gps_data.Rev_data.Soc = Bms_tt_data.Anal_quanuion.Anal_quan.Pow_SOC;		   //SOC

    gps_data.Rev_data.CellTmpSors = 0x02;	 //����¶ȴ��������� Ĭ��2

    gps_data.Rev_data.Bms_rl = gps_data.RevWrite_data.CellRl * 100;	 //BMSУ׼�������



    /*������ѭ���ŵ���*/
    if((Out_curr > 20) && (Out_curr <= gps_data.RevWrite_data.OutcurrG * 100))
    {
        Cell_Outrlbuff += (Out_curr / 100.0 * (1 / 1800.0) * (OutSOC_xs + SOH_xs)) * Q_hs; //2�������
        gps_data.Rev_data.CellOutrl = Cell_Outrl + Cell_Outrlbuff;    //���ѭ���ŵ�����ʵ�ʷŵ�����

        Cell_Out_RL = Cell_Outrl + Cell_Outrlbuff;    //SOH ʹ��  ���ѭ���ŵ�����ʵ�ʷŵ�����

    }

    gps_data.Rev_data.Cellusnum = gps_data.Rev_data.CellOutrl / gps_data.RevWrite_data.CellRl; //���ʹ��ѭ������
    gps_data.Rev_data.CellZnum = Bms_tt_data.Anal_quanuion.Anal_quan.Cores_num; //��ش���

    if(Cell_Soc < gps_data.RevWrite_data.DRLNum)//״̬
    {
        gps_data.strtu.socdd = 1;
        gps_data.Rev_data.CellhitData |= (1 << 0);
    }
    else
    {
        gps_data.strtu.socdd = 0;
        gps_data.Rev_data.CellhitData &= ~(1 << 0);
    }

    if(gps_data.Rev_data.MosTmp <= 100)
    {

        if(gps_data.Rev_data.MosTmp >= gps_data.RevWrite_data.PowTmp)
        {
            gps_data.strtu.mostmp = 1;
            gps_data.Rev_data.CellhitData |= (1 << 1);
        }
        else
        {
            if(gps_data.Rev_data.MosTmp < gps_data.RevWrite_data.PowTmpH)
            {
                gps_data.strtu.mostmp = 0;
                gps_data.Rev_data.CellhitData &= ~(1 << 1);
            }
        }

    }
    else//�����������
    {

        gps_data.strtu.mostmp = 0;
        gps_data.Rev_data.CellhitData &= ~(1 << 1);


    }

    /*��ŵ��س���*/
    for(i = 5; i <= 6; i++)
    {
        if(Bms_tt_data.Kaiguan[i] == 1)
        {
            gps_data.strtu.cellgtmp = 1;
            gps_data.Rev_data.CellhitData |= (1 << 4);
            break;
        }
        else
        {
            gps_data.strtu.cellgtmp = 0;
            gps_data.Rev_data.CellhitData &= ~(1 << 4);
        }
    }

    if(Bms_tt_data.Kaiguan[2])
    {
        gps_data.strtu.chgcurr = 1;
        gps_data.Rev_data.CellhitData |= (1 << 5);
    }
    else
    {
        gps_data.strtu.chgcurr = 0;
        gps_data.Rev_data.CellhitData &= ~(1 << 5);
    }

    if(Bms_tt_data.Kaiguan[3])
    {
        gps_data.strtu.outcurr = 1;
        gps_data.Rev_data.CellhitData |= (1 << 6);
    }
    else
    {
        gps_data.strtu.outcurr = 0;
        gps_data.Rev_data.CellhitData &= ~(1 << 6);
    }

    if(Bms_tt_data.Kaiguan[1])
    {
        gps_data.strtu.singvol = 1;
        gps_data.Rev_data.CellhitData |= (1 << 7);
    }
    else
    {
        gps_data.strtu.singvol = 0;
        gps_data.Rev_data.CellhitData &= ~(1 << 7);
    }





    if(gps_data.Rev_data.QualiTmp <= 100)
    {
        if(gps_data.Rev_data.QualiTmp > gps_data.RevWrite_data.Equaltmpb)
        {
            if(gps_data.RevWrite_data.EnableSwitch & 0x0002)//�¶����ο���ʹ��
            {
                gps_data.strtu.cellneitmp = 0;
                gps_data.Rev_data.CellhitData &= ~(1 << 8);
            }
            else
            {

                gps_data.strtu.cellneitmp = 1;
                gps_data.Rev_data.CellhitData |= (1 << 8);
            }
        }
        else
        {
            if(gps_data.Rev_data.QualiTmp < gps_data.RevWrite_data.EqualtmpH)
            {
                gps_data.strtu.cellneitmp = 0;
                gps_data.Rev_data.CellhitData &= ~(1 << 8);
            }
        }
    }
    else//�����������
    {
        gps_data.strtu.cellneitmp = 0;
        gps_data.Rev_data.CellhitData &= ~(1 << 8);

    }

    /*��ŵ��ص���*/
    for(i = 7; i <= 8; i++)
    {
        if(Bms_tt_data.Kaiguan[i] == 1)
        {
            gps_data.strtu.celldtmp = 1;
            gps_data.Rev_data.CellhitData |= (1 << 9);
            break;
        }
        else
        {
            gps_data.strtu.celldtmp = 0;
            gps_data.Rev_data.CellhitData &= ~(1 << 9);
        }

    }

    /*�����ѹ����*/
    for(i = 0; i < (A_Cellnum + B_Cellnum); i++)
    {
        if(dt_Dchggvol[i] == 1)
        {
            gps_data.strtu.Dchggvol = 1;
            break;
        }
        else
        {
            gps_data.strtu.Dchggvol = 0;
        }
    }

    for(i = 0; i < (A_Cellnum + B_Cellnum); i++)
    {


        if(OverVol_Alarm[i] == 1)
        {
            gps_data.Rev_data.CellhitData |= (1 << 10);

            break;
        }
        else
        {
            gps_data.Rev_data.CellhitData &= ~(1 << 10);

        }




    }


    /*����Ƿѹ����*/
    for(i = 0; i < (A_Cellnum + B_Cellnum); i++)
    {

        if(LowerVol_Alarm[i] == 1)
        {
            gps_data.strtu.Doutqvol = 1;
            gps_data.Rev_data.CellhitData |= (1 << 11);
            break;
        }
        else
        {
            gps_data.strtu.Doutqvol = 0;
            gps_data.Rev_data.CellhitData &= ~(1 << 11);
        }



    }

    /*����309������Ϣ*/
    if(data_309_A.RAM_Revdata.Bstrtus1.datas != 0 || data_309_A.RAM_Revdata.Bstrtus2.datas != 0)
        gps_data.Rev_data.CellhitData |= (1 << 12); //309_A����
    else
        gps_data.Rev_data.CellhitData &= ~(1 << 12);


    gps_data.Rev_data.CellhitData &= ~(1 << 13);


    //ʪ�ȱ���
    ShiDuFlag = 0;

    if((gps_data.RevWrite_data.ShiduKaiguan == 1) && (gps_data.RevWrite_data.ShiduValueNow > gps_data.RevWrite_data.ShiduValueProtect))
    {
        ShiDuFlag = 1;

        ShiDuFlag_OVER = 1;
    }
    else if((gps_data.RevWrite_data.ShiduKaiguan == 1) && (ShiDuFlag_OVER == 1))
    {
        if( (gps_data.RevWrite_data.ShiduValueNow + 10) <= gps_data.RevWrite_data.ShiduValueProtect )
        {
            ShiDuFlag = 0;
            ShiDuFlag_OVER = 0;
        }
        else
        {
            ShiDuFlag = 1;
        }
    }


    if(ShiDuFlag == 1)
    {
        gps_data.Rev_data.CellhitData |= (1 << 14); //ʪ�ȱ�������
    }
    else
    {
        gps_data.Rev_data.CellhitData &= ~(1 << 14);
    }

    //����������  �����ѹ����ظ��»��ߵ�����ڸ��±�����ʪ�ȱ���
    if( gps_data.Rev_data.CellhitData & 0x4510 )
    {
        SETIO(Beep_Con);//��������
    }
    else
    {
        RESETIO(Beep_Con);//�������ر�
    }


    /*��ؾ�����Ϣ*/
    gps_data.Rev_data.CellhitData |= 0x0000;

    /*�澯��¼����*/
    if(gps_data.Rev_data.CellhitData != 0x0001 && gps_data.Rev_data.CellhitData != 0x0000)
    {
        Hitsturt = gps_data.Rev_data.CellhitData;
        HitFlag = 1;
    }

    if(Hitsturt_2 != 0x00)
    {
        Hitsturt_22 = Hitsturt_2;
        HitFlag_22 = 1;
    }

    if(data_309_A.RAM_Revdata.Bstrtus1.bits.OV == 1 || data_309_B.RAM_Revdata.Bstrtus1.bits.OV == 1)
    {
        if(SocFlag_Chg == 1)
        {
            IntVolume = gps_data.RevWrite_data.CellRl;

        }

    }

    CHG_DSG_Status = 0;
    CHG_DSG_Status = ReadMosState();

    /*���״̬��Ϣ*/

    if((CHG_DSG_Status & 0x3) == 3) //��ŵ�MOS����
    {
        gps_data.Rev_data.CellStrtu |= (1 << 0);
        gps_data.Rev_data.CellStrtu |= (1 << 1);
        CH_MCU_Flag = 0;
        DS_MCU_Flag = 0;
    }

    else if((CHG_DSG_Status & 0x3) == 2) //���MOS�� ���ŵ�ܹر�
    {
        gps_data.Rev_data.CellStrtu |= (1 << 0);
        gps_data.Rev_data.CellStrtu &= ~ (1 << 1);
        CH_MCU_Flag = 0;
        DS_MCU_Flag = 1;
    }
    else if((CHG_DSG_Status & 0x3) == 1) //���ܹر�  �ŵ�ܴ�
    {
        gps_data.Rev_data.CellStrtu &= ~(1 << 0);
        gps_data.Rev_data.CellStrtu |= (1 << 1);
        CH_MCU_Flag = 1;
        DS_MCU_Flag = 0;
    }

    else if((CHG_DSG_Status & 0x3) == 0) //��ŵ綼�ر�
    {
        gps_data.Rev_data.CellStrtu &= ~ (1 << 0);
        gps_data.Rev_data.CellStrtu &= ~ (1 << 1);
        CH_MCU_Flag = 1;
        DS_MCU_Flag = 1;
    }


    if(data_309_A.RAM_Revdata.Balanceh_l.datas != 0 || data_309_B.RAM_Revdata.Balanceh_l.datas != 0)
        gps_data.Rev_data.CellStrtu |= (1 << 2);
    else
        gps_data.Rev_data.CellStrtu &= ~(1 << 2);



    //MOS����״̬�ϱ�����

    if(((CHG_DSG_Status & 0x02) == 0x02 && CH_MCU_Flag == 0) || ((CHG_DSG_Status & 0x02) != 0x02 && CH_MCU_Flag == 1)) //���MOS�����������ҳ�練���ź���ȷ
    {
        gps_data.Rev_data.CellStrtu &= ~(1 << 4);
        ChgMosBreakCnt = 0;

    }
    else if(((CHG_DSG_Status & 0x02) == 0x02 && CH_MCU_Flag == 1) || ((CHG_DSG_Status & 0x02) != 0x02 && CH_MCU_Flag == 0)) //���MOS�����������ҳ�練���źŲ���ȷ
    {
        ChgMosBreakCnt++;

        if(ChgMosBreakCnt == 2)
        {

            gps_data.Rev_data.CellStrtu |= (1 << 4);

        }

    }

    if(((CHG_DSG_Status & 0x01) == 0x01 && DS_MCU_Flag == 0) || ((CHG_DSG_Status & 0x01) != 0x01 && DS_MCU_Flag == 1)) //�ŵ�MOS�����������ҷ����ź���ȷ
    {
        gps_data.Rev_data.CellStrtu &= ~(1 << 5);
        DsgMosBreakCnt = 0;

    }
    else if(((CHG_DSG_Status & 0x01) == 0x01 && DS_MCU_Flag == 1) || ((CHG_DSG_Status & 0x01) != 0x01 && DS_MCU_Flag == 0)) //�ŵ�MOS�����������ҷ����źŲ���ȷ
    {
        DsgMosBreakCnt++;

        if(DsgMosBreakCnt == 2)
        {
            gps_data.Rev_data.CellStrtu |= (1 << 5);
            DsgMosBreakCnt = 0;

        }

    }

    gps_data.Rev_data.CellStrtu |= 0x0008;


    /*���ϼ�¼*/
    if(Off_lint)   gps_data.Rev_data.Hitjlm |= (1 << 0);
    else           gps_data.Rev_data.Hitjlm &= ~(1 << 0);

    if(Out_Dea)    gps_data.Rev_data.Hitjlm |= (1 << 1);
    else           gps_data.Rev_data.Hitjlm &= ~(1 << 1);

    if(Chg_Dea)    gps_data.Rev_data.Hitjlm |= (1 << 2);
    else           gps_data.Rev_data.Hitjlm &= ~(1 << 2);

    if(Cell_Tmp)   gps_data.Rev_data.Hitjlm |= (1 << 3);
    else           gps_data.Rev_data.Hitjlm &= ~(1 << 4);

    if(Pow_Tmp)    gps_data.Rev_data.Hitjlm |= (1 << 4);
    else           gps_data.Rev_data.Hitjlm &= ~(1 << 4);

    if(Chg_Moshit) gps_data.Rev_data.Hitjlm |= (1 << 5);
    else           gps_data.Rev_data.Hitjlm &= ~(1 << 5);

    if(Out_Moshit) gps_data.Rev_data.Hitjlm |= (1 << 6);
    else           gps_data.Rev_data.Hitjlm &= ~(1 << 6);

    gps_data.Rev_data.Hitjlm |= 0xef00;




    /*�����Ż������ѹ*/
    for(i = A_Cellnum + B_Cellnum; i < 20; i ++)
    {
        Bms_tt_data.Kaiguan[12 + i] = 0;
    }

    for(i = A_Cellnum + B_Cellnum; i < 24; i ++)
    {
        OverVol_Alarm[i] = 0;
    }



    //����ⲿ���翪���Ƿ�����ʹ��
    if(gps_data.RevWrite_data.BHBAddr == 101)
    {
        if(READIO(CHGDSG_Control) == 0)
        {

            DSG_Switch_Flag = 0;
            CHG_Switch_Flag = 0;


        }
        else
        {
            CHG_Switch_Flag = 1;
            DSG_Switch_Flag = 0;

        }


    }
    else if(gps_data.RevWrite_data.BHBAddr == 102)
    {
        if(READIO(CHGDSG_Control) == 0)
        {

            DSG_Switch_Flag = 0;
            CHG_Switch_Flag = 0;

        }
        else
        {
            DSG_Switch_Flag = 1;
            CHG_Switch_Flag = 0;

        }


    }
    else if(gps_data.RevWrite_data.BHBAddr == 103)
    {
        if(READIO(CHGDSG_Control) == 0)
        {

            DSG_Switch_Flag = 0;
            CHG_Switch_Flag = 0;


        }
        else
        {
            DSG_Switch_Flag = 1;
            CHG_Switch_Flag = 1;

        }


    }
    else
    {

        DSG_Switch_Flag = 0;
        CHG_Switch_Flag = 0;

    }



    /*���ŵ�MOS�ܽ��в���*/

    /*���ܿ��أ�Bms_tt_data.Kaiguan[9] == 1����������ʾ����������*/

//
    if(Bms_tt_data.Kaiguan[1] == 1 || Bms_tt_data.Kaiguan[2] == 1 || Bms_tt_data.Kaiguan[5] == 1 || ShiDuFlag == 1 || CHG_Switch_Flag == 1 ||
            Bms_tt_data.Kaiguan[7] == 1 || OverVol_Alarm[0] == 1 || OverVol_Alarm[1] == 1 ||
            OverVol_Alarm[2] == 1 ||  OverVol_Alarm[3] == 1 ||  OverVol_Alarm[4] == 1 ||  OverVol_Alarm[5] == 1 ||
            OverVol_Alarm[6] == 1 ||  OverVol_Alarm[7] == 1 ||  OverVol_Alarm[8] == 1 ||  OverVol_Alarm[9] == 1 ||
            OverVol_Alarm[10] == 1 ||  OverVol_Alarm[11] == 1 ||  OverVol_Alarm[12] == 1 ||  OverVol_Alarm[13] == 1 ||
            OverVol_Alarm[14] == 1 || OverVol_Alarm[15] == 1 ||  OverVol_Alarm[16] == 1 ||  OverVol_Alarm[17] == 1 ||
            OverVol_Alarm[18] == 1 ||  OverVol_Alarm[19] == 1 || OverVol_Alarm[20] == 1 || OverVol_Alarm[21] == 1 || OverVol_Alarm[22] == 1 || OverVol_Alarm[23] == 1  || gps_data.strtu.mostmp == 1 || gps_data.strtu.chggvol == 1 ||
            gps_data.strtu.cellgtmp == 1 || gps_data.strtu.chgcurr == 1 || gps_data.strtu.singvol == 1 || gps_data.strtu.cellneitmp == 1 || gps_data.strtu.Dchggvol == 1 || Flag___485 == 1
      )


    {
        Chg_Flag = 1;
        Shut309CHGMos();
        ChgMos_bit = 1;
        ZhuDAlarm_Flag = 1;
    }
    else
    {
        Chg_Flag = 0;

        if(Chg_Lock == 0)//���MOS�ؿ��ش�
        {
            Free309CHGMos();
            ChgMos_bit = 0;
        }
    }

    /*�����Ż�����Ƿѹ*/

    for(i = A_Cellnum + B_Cellnum; i < 20; i ++)
    {
        Bms_tt_data.Kaiguan[32 + i] = 0;
    }

    for(i = A_Cellnum + B_Cellnum; i < 24; i ++)
    {
        LowerVol_Alarm[i] = 0;
    }

    /*�ŵ�ܿ��أ�Bms_tt_data.Kaiguan[10] == 1ֻ��������ʾ����������*/
    if(Bms_tt_data.Kaiguan[3] == 1 || Bms_tt_data.Kaiguan[6] == 1 || Bms_tt_data.Kaiguan[8] == 1 || dahuo_flag == 1 || DSG_Switch_Flag == 1 || ShiDuFlag == 1 || LowerVol_Alarm[0] == 1 || LowerVol_Alarm[1] == 1 || LowerVol_Alarm[2] == 1 ||

            LowerVol_Alarm[3] == 1 || LowerVol_Alarm[4] == 1 || LowerVol_Alarm[5] == 1 || LowerVol_Alarm[6] == 1 ||
            LowerVol_Alarm[7] == 1 || LowerVol_Alarm[8] == 1 || LowerVol_Alarm[9] == 1 || LowerVol_Alarm[10] == 1 ||
            LowerVol_Alarm[11] == 1 || LowerVol_Alarm[12] == 1 || LowerVol_Alarm[13] == 1 || LowerVol_Alarm[14] == 1 ||
            LowerVol_Alarm[15] == 1 || LowerVol_Alarm[16] == 1 || LowerVol_Alarm[17] == 1 || LowerVol_Alarm[18] == 1 ||
            LowerVol_Alarm[19] == 1 || LowerVol_Alarm[20] == 1 || LowerVol_Alarm[21] == 1 || LowerVol_Alarm[22] == 1 || LowerVol_Alarm[23] == 1 || gps_data.strtu.mostmp == 1 || gps_data.strtu.outqvol == 1 ||
            gps_data.strtu.cellgtmp == 1 || gps_data.strtu.outcurr == 1 || gps_data.strtu.singvol == 1 || gps_data.strtu.cellneitmp == 1 || gps_data.strtu.Doutqvol == 1
      )

    {
        Out_flag = 1;
        Shut309DSGMos();
        OutMos_bit = 1;
        ZhuDAlarm_Flag = 1;
    }
    else
    {
        Out_flag = 0;

        if(Out_Lock == 0)//�ŵ�MOS�ؿ��ش�
        {

            Free309DSGMos();
            OutMos_bit = 0;
        }
    }

    /*ֻҪ��⵽�зŵ����ʱ���ʹ򿪳��MOS��-*/
    if(Out_curr > 50)
    {
        ChgMos_bit = 0;

        //�ŵ���������±���
        Bms_tt_data.Kaiguan[7] = 0;
        Hitsturt_2 &= ~(1 << 3);

    }
    else
    {
        if(Chg_Lock == 1)//���MOS�ܿ��عر�
        {

            ChgMos_bit = 1;
        }
    }

    /*ֻҪ��⵽�г�����ʱ���ʹ򿪷ŵ�MOS��*/
    if(Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr > 50)
    {

        OutMos_bit = 0;

        //�������ŵ���±���
        Bms_tt_data.Kaiguan[8] = 0;
        Hitsturt_2 &= ~(1 << 1);
    }
    else
    {
        if(Out_Lock == 1)    //�ŵ�MOS�ܿ��عر�
        {

            OutMos_bit = 1;
        }
    }

    //�������
    Equal_tmp_A = 0;
    Equal_tmp_B = 0;

    for(i = 0; i < (A_Cellnum + B_Cellnum); i++)
    {
        if(	(Out_curr == 0) && ((Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr > 50) || (ZeroCur5Min >= 1)) && (Cores_Vol[i] > gps_data.RevWrite_data.Equalivol) &&
                ((Cores_Vol[i] - cell_vol_min) > gps_data.RevWrite_data.Equalivolcc) && (gps_data.RevWrite_data.EqualiON == 1) )
        {
            if(i < A_Cellnum)
            {
                Equal_tmp_A |= (1 << i);
            }

            if(i >= A_Cellnum && i < (A_Cellnum + B_Cellnum))
            {
                Equal_tmp_B |= (1 << (i - A_Cellnum));
            }

        }
    }


    Equal_Buffer[0][1] = (u8)Equal_tmp_A;//��8λ
    Equal_Buffer[0][0] = (u8)(Equal_tmp_A >> 8); //��8λ

    Equal_Buffer[1][0] = Equal_tmp_B >> 8;//��8λ
    Equal_Buffer[1][1] = Equal_tmp_B;//��8λ


    if(stopstart_309Flag == 0)
    {
        MTPWrite_fun_1(MTP_BALANCEH, 2, &Equal_Buffer[0][0]);
        MTPWrite_fun_2(MTP_BALANCEH, 2, &Equal_Buffer[1][0]);
    }



    Rs485PortNWDataHandle();
    GpsPortNwDataHandle();

    /*ͨ��ָʾ��*/
    if(tX_bit == 1)
    {
        count = 0;
        LED_1_bit = 1;
    }
    else if(tX_bit == 2)
    {
        count = 0;
        LED_1_bit = 2;
    }
    else if(tX_bit == 3)
    {
        count = 0;
        LED_1_bit = 3;
    }

    tX_bit = 0;

    if(LED_1_bit != 0)
    {
        count++;

        if(count >= 10)
        {
            count = 0;
            LED_1_bit = 0;
            SETIO(LED_1);
        }
    }

//printf("\r\nDS_MCU_Flag=%d\r\nCH_MCU_Flag=%d\r\n",DS_MCU_Flag,CH_MCU_Flag);

    /*����ָʾ��*/
    if(DS_MCU_Flag == 1 && CH_MCU_Flag == 1)
    {
        LED_2_bit = 0;
        SETIO(LED_2);
    }
    else if(DS_MCU_Flag == 0 && CH_MCU_Flag == 1)	LED_2_bit = 1;
    else if(DS_MCU_Flag == 1 && CH_MCU_Flag == 0)	LED_2_bit = 2;
    else if(DS_MCU_Flag == 0 && CH_MCU_Flag == 0)	LED_2_bit = 3;

    if( (Out_curr > 20) || (Bms_tt_data.Anal_quanuion.Anal_quan.Chg_Curr > 20) )
    {
        if(Out_curr > 20)	ZeroCur5Min = 0;

        ZeroCur_minute = 0;

        if(Out_curr > 200) HDCurr_Flag = 0;
    }

    /*************���ݵ���о��ѹ���Գ�ʼ��SOC****************/
    if(FirstStart == 1 )
    {
        FirstStart = 0;
        Init_SOC_8S_flag = 0;

        if(SOCinit == 0 && SOCinit_bit == 0)
        {

            if(gps_data.RevWrite_data.Celltype == 0)      //����
            {
                Cell_Soc = updataCell_0SOC();
            }
            else if(gps_data.RevWrite_data.Celltype == 1) //��Ԫ
            {

                Cell_Soc = updataSOC();
            }
            else if(gps_data.RevWrite_data.Celltype == 2) //����
            {
                if(cell_vol_max > 1800)	Cell_Soc = (cell_vol_max - 1800) / 5.0;
            }

            if(Cell_Soc > 100)	Cell_Soc = 100;

            IntVolume = Cell_Soc / 100.0 * gps_data.RevWrite_data.CellRl;
            SOCinit_bit = 1;

        }

    }



    if(OverVolFlag == 1)
    {
        Cell_Soc = 100;
        IntVolume = gps_data.RevWrite_data.CellRl;
    }

    if(LowVolFlag == 1)
    {
        Cell_Soc = 0;
        Set_SOH_DVFlag = 1;
        IntVolume = 0;
    }


    //������ʾLEDָʾ��

    if(Cell_Soc > 80 && Cell_Soc <= 100)
    {
        RESETIO(LED_3);
        RESETIO(LED_4);
        RESETIO(LED_5);
        RESETIO(LED_6);
        RESETIO(LED_7);
    }
    else if(Cell_Soc > 60 && Cell_Soc <= 80)
    {
        SETIO(LED_3);
        RESETIO(LED_4);
        RESETIO(LED_5);
        RESETIO(LED_6);
        RESETIO(LED_7);

    }
    else if(Cell_Soc > 40 && Cell_Soc <= 60)
    {
        SETIO(LED_3);
        SETIO(LED_4);
        RESETIO(LED_5);
        RESETIO(LED_6);
        RESETIO(LED_7);

    }
    else if(Cell_Soc > 20 && Cell_Soc <= 40)
    {
        SETIO(LED_3);
        SETIO(LED_4);
        SETIO(LED_5);
        RESETIO(LED_6);
        RESETIO(LED_7);

    }
    else if(Cell_Soc > 10 && Cell_Soc <= 20)
    {
        SETIO(LED_3);
        SETIO(LED_4);
        SETIO(LED_5);
        SETIO(LED_6);
        RESETIO(LED_7);

    }
    else
    {
        SETIO(LED_3);
        SETIO(LED_4);
        SETIO(LED_5);
        SETIO(LED_6);
        SETIO(LED_7);

    }




    //��ؽ���ֵ
    Bms_tt_data.Anal_quanuion.Anal_quan.SOH = SOH_Readflash;

    if(Set_SOH_OVFlag == 1 && Set_SOH_DVFlag == 1)
    {
        // ���������92%
        Bms_tt_data.Anal_quanuion.Anal_quan.SOH = ((Cell_Out_RL - RongLiang) * 10000 ) / (92 * gps_data.RevWrite_data.CellRl); //

        SOH_Readflash = Bms_tt_data.Anal_quanuion.Anal_quan.SOH;

        if(Bms_tt_data.Anal_quanuion.Anal_quan.SOH > 100)
        {
            Bms_tt_data.Anal_quanuion.Anal_quan.SOH = 100;
            SOH_Readflash = Bms_tt_data.Anal_quanuion.Anal_quan.SOH;
        }

        Set_SOH_OVFlag = 0;
        Set_SOH_DVFlag = 0;

    }



    //��ȡʪ��ֵ
    if((ReadAHT10()) >= 101)
    {
        gps_data.RevWrite_data.ShiduValueNow = 0;
    }
    else
    {
        gps_data.RevWrite_data.ShiduValueNow = ReadAHT10();
    }






}
