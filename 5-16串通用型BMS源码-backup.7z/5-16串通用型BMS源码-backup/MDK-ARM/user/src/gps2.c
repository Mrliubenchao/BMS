
/**************  ˼�ƶ���Э�鲻����************
#include "stm32f10x.h"
#include "stm32f10x_conf.h"

#include "usart.h"
#include "delay.h"
#include "485.h"

#include "stdio.h"
#include "string.h"

#include "gpsnet.h"
#include "flash.h"
#include "gpioinit.h"
#include "datahand.h"
#include "IIc.h"
#include "Jdy_19.h"
#include "iobind.h"

#include "gps2.h"
#include "SH367309.h"


//����ȫ�ֱ���
Rev_Gps Rev_GpsUsart1 = {0}; //���մ����´�������

gpss_datas gps_datas = {0};  //GPS�������

extern uint16_t crc_16(uint8_t *data, uint16_t len);
extern unsigned short rjbb;
extern unsigned short cellnumber;


void Send_Gps2(u8 bmsnum,u8 orde,u8 state,u8 *buff,u16 len)
{
	u16 crc_data = 0;
  u8  sendbuf[150] = {0};
	data_Gps data_frame = {0};

	data_frame.Framehand   = GPSFRAME_HAND;  //֡ͷ
	data_frame.ModeType    = GPSMOD_TYPE;    //ģ�����
	data_frame.ModeNum     = bmsnum;         //ģ�����
  data_frame.Len_L = (u8)len;              //���ĳ��ȵ��ֽ�
	data_frame.Len_H = (u8)(len >> 8);       //���ĳ��ȸ��ֽ�
	orde |= 0x80;
	data_frame.Commond = orde;               //����
	data_frame.ModeWord = state;             //ģ�鹤��״̬
  memcpy(data_frame.Data,buff,len);        //������
	crc_data = crc_16(&data_frame.ModeType,len + 6);
  data_frame.CRC_L = crc_data;
  data_frame.CRC_H = crc_data >> 8;

	sendbuf[0] = data_frame.Framehand;
	sendbuf[1] = data_frame.ModeType;
	sendbuf[2] = data_frame.ModeNum;
	sendbuf[3] = data_frame.Len_L;
	sendbuf[4] = data_frame.Len_H;
	sendbuf[5] = data_frame.Commond;
	sendbuf[6] = data_frame.ModeWord;
	memcpy(&sendbuf[7],data_frame.Data,len);

	sendbuf[7+len] = data_frame.CRC_L;
	sendbuf[8+len] = data_frame.CRC_H;

	//��������
	Send_TString_GPS(sendbuf,(u16)(9 + len));
}

void gpsdecodea_22222(void)
{
  u8  bmsnum = 0;     //BMS���
	u8  orde = 0;       //������
	u8  state = 0;      //ģ�鹤��״̬
	u16 data_len = 0;   //�����峤��
  u16 crc_data = 0;   //CRCУ����
	u16 i = 0;
	u16 j = 0;
	u32 temp_32 = 0;

	u8  sendbuffer[130] = {0};  //�������ݻ���
	u16 send_len = 0;     //�����򳤶�

	//����һ֡���ĳɹ�
	if(Rev_GpsUsart1.gps_Rev_startss == 1)
	{
		Rev_GpsUsart1.gps_Rev_startss = 0; //�����־λ

		data_len = (u16)(Rev_GpsUsart1.gps_Rev_bufss[3] | (Rev_GpsUsart1.gps_Rev_bufss[4] << 8)); //��ȡ�����峤��

		crc_data = crc_16(&Rev_GpsUsart1.gps_Rev_bufss[1],data_len + 6);  //��ȡCRCУ����

		tX_bit |= 0x01;//---------------------

	  //����Լ��
		if((Rev_GpsUsart1.gps_Rev_bufss[data_len + 7] == (u8)crc_data) &&  (Rev_GpsUsart1.gps_Rev_bufss[data_len + 8] == (u8)(crc_data >> 8)))
		{
			//��ȡģ�����
			bmsnum = Rev_GpsUsart1.gps_Rev_bufss[2];
			//��ȡ������
			orde = Rev_GpsUsart1.gps_Rev_bufss[5];
			//��ȡģ�鹤��״̬
			state = Rev_GpsUsart1.gps_Rev_bufss[6];
			switch(orde)
			{
				case GPSCOMMOND_0x30:	   //��Ϣ��ѯ
				{
					s16 tmp[3]={0};
					s16 tmp2[3]={0};
					u8 tmpmaxnum=0;
					u8 tmpminnum=0;
					memset(gps_datas.data_Querysss.data,0,120);
					for(i=0;i<gps_data.Rev_data.CellZnum;i++)                                    //��о��ѹ
					{
						gps_datas.data_Querysss.data[i*2]   = gps_data.Rev_data.Singcellvol[i][2];
						gps_datas.data_Querysss.data[i*2+1] = gps_data.Rev_data.Singcellvol[i][1];
					}
					for(i=gps_data.Rev_data.CellZnum;i<64;i++)                                   //Ĭ��ֵ
					{
						gps_datas.data_Querysss.data[i*2]   = 0xFF;
						gps_datas.data_Querysss.data[i*2+1] = 0xFF;
					}

					gps_datas.data_Querysss.data_Query.tmp_1_l = Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp * 10;      //�¶�1
					gps_datas.data_Querysss.data_Query.tmp_1_h = (Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp * 10) >> 8;

					gps_datas.data_Querysss.data_Query.tmp_2_l = Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp * 10;       //�¶�2
					gps_datas.data_Querysss.data_Query.tmp_2_h = (Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp * 10) >> 8;

					gps_datas.data_Querysss.data_Query.tmp_3_l = Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp * 10;       //�¶�3
					gps_datas.data_Querysss.data_Query.tmp_3_h = (Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp * 10) >> 8;

					gps_datas.data_Querysss.data_Query.mostmp_l = Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp * 10;       //mos���¶�
					gps_datas.data_Querysss.data_Query.mostmp_h = (Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp * 10) >> 8;

					gps_datas.data_Querysss.data_Query.tmp_5_l = 0xD0;       //�¶�5
					gps_datas.data_Querysss.data_Query.tmp_5_h = 0x07;

					gps_datas.data_Querysss.data_Query.tmp_6_l = 0xD0;       //�¶�6
					gps_datas.data_Querysss.data_Query.tmp_6_h = 0x07;

					gps_datas.data_Querysss.data_Query.tmp_7_l = 0xD0;       //�¶�7
					gps_datas.data_Querysss.data_Query.tmp_7_h = 0x07;

					gps_datas.data_Querysss.data_Query.tmp_8_l = 0xD0;       //�¶�8
					gps_datas.data_Querysss.data_Query.tmp_8_h = 0x07;

          ///////////////////////////////////////////////////////////////////////////////////////////////////////
					tmp[0] = Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp * 10;
					tmp[1] = Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp * 10;
					tmp[2] = Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp * 10;
					memcpy(tmp2,tmp,6);

					for(i=0; i<3-1; i++)  //��С�Ƚϴ�С
					{
						for(j=0; j<3-1-i; j++)
						{
						  if(tmp2[j] > tmp2[j+1])
						 {
								u16 temp = tmp2[j+1];
								tmp2[j+1] = tmp2[j];
								tmp2[j] = temp;
						 }
						}
					}

					for(i=0; i<3; i++) //ȡ������
					{
						if(tmp2[3-1] == tmp[i])
						{
							tmpmaxnum = i;
							break;
						}
					}

					for(i=0; i<3; i++) //ȡ��С���
					{
						if(tmp2[0] == tmp[i])
						{
							tmpminnum = i;
							break;
						}
					}
					//////////////////////////////////////////////////

          gps_datas.data_Querysss.data_Query.maxtmp_l = tmp2[3-1];       //����¶ȵ��ֽ� ����¶ȸ��ֽ�
					gps_datas.data_Querysss.data_Query.maxtmp_h = tmp2[3-1] >> 8;

					gps_datas.data_Querysss.data_Query.maxtmpnum = tmpmaxnum;         //����¶����

					gps_datas.data_Querysss.data_Query.mintmp_l = tmp2[0];       //����¶ȵ��ֽ�
					gps_datas.data_Querysss.data_Query.mintmp_h = tmp2[0] >> 8;

					gps_datas.data_Querysss.data_Query.mintmpnum = tmpminnum;         //����¶����

					gps_datas.data_Querysss.data_Query.Singmaxvol_l = cell_vol_max;      //������ߵ�ѹ
					gps_datas.data_Querysss.data_Query.Singmaxvol_h = cell_vol_max >> 8;

					gps_datas.data_Querysss.data_Query.Singminvol_l = cell_vol_min;      //������͵�ѹ
					gps_datas.data_Querysss.data_Query.Singminvol_h = cell_vol_min >> 8;

					gps_datas.data_Querysss.data_Query.SumVol_1 = (gps_data.Rev_data.CellZvol * 10);      //����ܵ�ѹ
					gps_datas.data_Querysss.data_Query.SumVol_2 = (gps_data.Rev_data.CellZvol * 10) >> 8;
					gps_datas.data_Querysss.data_Query.SumVol_3 = (gps_data.Rev_data.CellZvol * 10) >> 16;
					gps_datas.data_Querysss.data_Query.SumVol_4 = (gps_data.Rev_data.CellZvol * 10) >> 24;

					gps_datas.data_Querysss.data_Query.SumCurr_1 = ((10000 - gps_data.Rev_data.Currdata) * 10);      //��������
					gps_datas.data_Querysss.data_Query.SumCurr_2 = ((10000 - gps_data.Rev_data.Currdata) * 10) >> 8;
					gps_datas.data_Querysss.data_Query.SumCurr_3 = ((10000 - gps_data.Rev_data.Currdata) * 10) >> 16;
					gps_datas.data_Querysss.data_Query.SumCurr_4 = ((10000 - gps_data.Rev_data.Currdata) * 10) >> 24;

					gps_datas.data_Querysss.data_Query.eQl_l = (gps_data.Rev_data.Bms_rl / 10);      //�����
					gps_datas.data_Querysss.data_Query.eQl_h = (gps_data.Rev_data.Bms_rl / 10) >> 8;

					gps_datas.data_Querysss.data_Query.SOC_l = (Cell_Soc * 10);         //�����
					gps_datas.data_Querysss.data_Query.SOC_h = (Cell_Soc * 10)>> 8;

					gps_datas.data_Querysss.data_Query.CellXHnum_l = gps_data.Rev_data.Cellusnum;    //���ʹ��ѭ������
					gps_datas.data_Querysss.data_Query.CellXHnum_h = gps_data.Rev_data.Cellusnum >> 8;

					gps_datas.data_Querysss.data_Query.rjbb_l = rjbb;               //�����汾��
					gps_datas.data_Querysss.data_Query.rjbb_h = rjbb >> 8;

					gps_datas.data_Querysss.data_Query.cellnum_l = cellnumber;      //������к�
					gps_datas.data_Querysss.data_Query.cellnum_h = cellnumber >> 8;

					//////////////////////////////////////////////////////////////////////////////////////////////

          gps_datas.data_Querysss.data_Query.BMSerro_1 = 0x00;
					gps_datas.data_Querysss.data_Query.BMSerro_2 = 0x00;
          gps_datas.data_Querysss.data_Query.BMSerro_3 = 0x00;
					gps_datas.data_Querysss.data_Query.BMSerro_4 = 0x00;
					if(HitFlag == 1)
					{
						if(Hitsturt & (1 << 10)) //�����ѹ
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<0); //��ѹ
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<0);

						if(Hitsturt & (1 << 11)) //����Ƿѹ
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<1); //Ƿѹ
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<1);

						/////////////////////////////////////////////////////////
						if(Hitsturt & (1 << 6)) //�ŵ����
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<6);
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<6);

						if(Hitsturt & (1 << 5)) //������
							gps_datas.data_Querysss.data_Query.BMSerro_2 |= (1<<0);
						else
							gps_datas.data_Querysss.data_Query.BMSerro_2 &= ~(1<<0);

						if(Hitsturt & (1 << 0))  //��������
							gps_datas.data_Querysss.data_Query.BMSerro_2 |= (1<<1);
						else
							gps_datas.data_Querysss.data_Query.BMSerro_2 &= ~(1<<1);

						if(Hitsturt & (1 << 7)) //��оѹ��
							gps_datas.data_Querysss.data_Query.BMSerro_2 |= (1<<4);
						else
							gps_datas.data_Querysss.data_Query.BMSerro_2 &= ~(1<<4);

						if(Hitsturt & (1 << 1)) //MOS�ܹ���
							gps_datas.data_Querysss.data_Query.BMSerro_2 |= (1<<5);
						else
							gps_datas.data_Querysss.data_Query.BMSerro_2 &= ~(1<<5);
						HitFlag = 0;		//�ϱ������
					}
          else
					{
						if(gps_data.Rev_data.CellhitData & (1 << 10)) //�����ѹ
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<0); //��ѹ
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<0);

						if(gps_data.Rev_data.CellhitData & (1 << 11)) //����Ƿѹ
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<1); //Ƿѹ
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<1);

						if(gps_data.Rev_data.CellhitData & (1 << 6)) //�ŵ����
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<6);
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<6);

						if(gps_data.Rev_data.CellhitData & (1 << 5)) //������
							gps_datas.data_Querysss.data_Query.BMSerro_2 |= (1<<0);
						else
							gps_datas.data_Querysss.data_Query.BMSerro_2 &= ~(1<<0);

						if(gps_data.Rev_data.CellhitData & (1 << 0))  //��������
							gps_datas.data_Querysss.data_Query.BMSerro_2 |= (1<<1);
						else
							gps_datas.data_Querysss.data_Query.BMSerro_2 &= ~(1<<1);

						if(gps_data.Rev_data.CellhitData & (1 << 7)) //��оѹ��
							gps_datas.data_Querysss.data_Query.BMSerro_2 |= (1<<4);
						else
							gps_datas.data_Querysss.data_Query.BMSerro_2 &= ~(1<<4);

						if(gps_data.Rev_data.CellhitData & (1 << 1)) //MOS�ܹ���
							gps_datas.data_Querysss.data_Query.BMSerro_2 |= (1<<5);
						else
							gps_datas.data_Querysss.data_Query.BMSerro_2 &= ~(1<<5);
					}
          if(HitFlag_22 == 1)
					{
            if(Hitsturt_22 & (1 << 0))
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<2); //�ŵ糬��
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<2);

						if(Hitsturt_22 & (1 << 1))
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<3); //�ŵ����
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<3);

						if(Hitsturt_22 & (1 << 2))
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<4); //��糬��
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<4);

						if(Hitsturt_22 & (1 << 3))
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<5); //������
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<5);
            HitFlag_22 = 0;
					}
					else
					{
						/////////////////////////////////////////////////////////

						if(Bms_tt_data.Kaiguan[6])
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<2); //�ŵ糬��
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<2);

						if(Bms_tt_data.Kaiguan[8])
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<3); //�ŵ����
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<3);

						if(Bms_tt_data.Kaiguan[5])
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<4); //��糬��
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<4);

						if(Bms_tt_data.Kaiguan[7])
							gps_datas.data_Querysss.data_Query.BMSerro_1 |= (1<<5); //������
						else
							gps_datas.data_Querysss.data_Query.BMSerro_1 &= ~(1<<5);
					}

					temp_32 = (data_309_B.RAM_Revdata.Balanceh_l.datas << data_309_A.EEPROMRevdata.Sconf1.datas) | data_309_A.RAM_Revdata.Balanceh_l.datas;

					gps_datas.data_Querysss.data_Query.jhnum_1 = temp_32;      //����ͨ��
					gps_datas.data_Querysss.data_Query.jhnum_2 = temp_32 >> 8;
					gps_datas.data_Querysss.data_Query.jhnum_3 = temp_32 >> 16;
					gps_datas.data_Querysss.data_Query.jhnum_4 = temp_32 >> 24;

					gps_datas.data_Querysss.data_Query.maxsingnum = cellmaxnum;      //��ߵ������
					gps_datas.data_Querysss.data_Query.minsingnum = cellminnum;      //��͵������

					if(CH_MCU_Flag == 0) ///////////////
						gps_datas.data_Querysss.data_Query.ChgMOS = 1;      //   ���MOS��״̬
					else
						gps_datas.data_Querysss.data_Query.ChgMOS = 0;      //
					if(DS_MCU_Flag == 0) ///////////////
						gps_datas.data_Querysss.data_Query.OutMOS = 1;      //   �ŵ�MOS��״̬
					else
						gps_datas.data_Querysss.data_Query.OutMOS = 0;      //

					readdata_485();
					send_len = 120;
					memcpy(sendbuffer,gps_datas.data_Querysss.data,send_len);
				  Send_Gps2(bmsnum,orde,state,sendbuffer,send_len);

				}
				break;
				case GPSCOMMOND_0x40:       //������ȡ
				{
					gps_datas.data_RevWritesss.data_RevWrite.Overvol_l = gps_data.RevWrite_data.SingvolG;
					gps_datas.data_RevWritesss.data_RevWrite.Overvol_h = gps_data.RevWrite_data.SingvolG >> 8;

                    gps_datas.data_RevWritesss.data_RevWrite.Overvoltime = gps_data.RevWrite_data.SingvolGtime;

					gps_datas.data_RevWritesss.data_RevWrite.Qvol_l = gps_data.RevWrite_data.SingvolQ;
					gps_datas.data_RevWritesss.data_RevWrite.Qvol_h = gps_data.RevWrite_data.SingvolQ >> 8;

					gps_datas.data_RevWritesss.data_RevWrite.Qvoltime = gps_data.RevWrite_data.SingvolQtime;

					gps_datas.data_RevWritesss.data_RevWrite.JHON_Vol_l = gps_data.RevWrite_data.Equalivol;
					gps_datas.data_RevWritesss.data_RevWrite.JHON_Vol_h = gps_data.RevWrite_data.Equalivol >> 8;

					gps_datas.data_RevWritesss.data_RevWrite.JHON_yc_l = gps_data.RevWrite_data.Equalivolcc;
					gps_datas.data_RevWritesss.data_RevWrite.JhON_yc_h = gps_data.RevWrite_data.Equalivolcc >> 8;

					gps_datas.data_RevWritesss.data_RevWrite.cyzuz_l = 0xFF;
					gps_datas.data_RevWritesss.data_RevWrite.cyzuz_h = 0xFF;

					gps_datas.data_RevWritesss.data_RevWrite.OutcurrG_l = gps_data.RevWrite_data.OutcurrG * (400/6.1);
					gps_datas.data_RevWritesss.data_RevWrite.OutcurrG_h = (u16)(gps_data.RevWrite_data.OutcurrG * (400/6.1))>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.Outcurrtime_l = gps_data.RevWrite_data.OutcurrGtime * 1000;
					gps_datas.data_RevWritesss.data_RevWrite.Outcurrtime_h = (gps_data.RevWrite_data.OutcurrGtime * 1000)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.Outdl_l = (u8) (80 * (400/6.1));
					gps_datas.data_RevWritesss.data_RevWrite.Outdl_h = (u16)(80 * (400/6.1)) >> 8;
					gps_datas.data_RevWritesss.data_RevWrite.Outdltime_l = (u8)512;
					gps_datas.data_RevWritesss.data_RevWrite.Outdltime_h = (u8)((u16)(512) >> 8);

					gps_datas.data_RevWritesss.data_RevWrite.ChgcurrG_l = gps_data.RevWrite_data.ChgcurrG * (400/6.1);
					gps_datas.data_RevWritesss.data_RevWrite.ChgcurrG_h = (u16)(gps_data.RevWrite_data.ChgcurrG * (400/6.1)) >> 8;

					gps_datas.data_RevWritesss.data_RevWrite.Chgcurrtime = gps_data.RevWrite_data.ChgcurrGtime;
					///////////////////////////////////////////////////////////////////////////////////////////////////
					gps_datas.data_RevWritesss.data_RevWrite.OutCtmp_l = gps_data.RevWrite_data.CellOutTmpG * 10;
					gps_datas.data_RevWritesss.data_RevWrite.OutCtmp_h = (gps_data.RevWrite_data.CellOutTmpG  * 10)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.OutCHtmp_l = gps_data.RevWrite_data.CellOutTmpGH * 10;
					gps_datas.data_RevWritesss.data_RevWrite.OutCHtmp_h = (gps_data.RevWrite_data.CellOutTmpGH  * 10)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.OutDtmp_l = gps_data.RevWrite_data.OutTmpD * 10;
					gps_datas.data_RevWritesss.data_RevWrite.OutDtmp_h = (gps_data.RevWrite_data.OutTmpD  * 10)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.OutDHtmp_l = gps_data.RevWrite_data.OutTmpDH * 10;
					gps_datas.data_RevWritesss.data_RevWrite.OutDHtmp_h = (gps_data.RevWrite_data.OutTmpDH  * 10)>> 8;
					////////////////////////////////////////////////////////////////////////////////////////////////
					gps_datas.data_RevWritesss.data_RevWrite.ChgCtmp_l = gps_data.RevWrite_data.CellChgTmpG * 10;
					gps_datas.data_RevWritesss.data_RevWrite.ChgCtmp_h = (gps_data.RevWrite_data.CellChgTmpG  * 10)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.ChgCHtmp_l = gps_data.RevWrite_data.CellChgTmpGH * 10;
					gps_datas.data_RevWritesss.data_RevWrite.ChgCHtmp_h = (gps_data.RevWrite_data.CellChgTmpGH  * 10)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.ChgDtmp_l = gps_data.RevWrite_data.ChgTmpD * 10;
					gps_datas.data_RevWritesss.data_RevWrite.ChgDtmp_h = (gps_data.RevWrite_data.ChgTmpD  * 10)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.ChgDHtmp_l = gps_data.RevWrite_data.ChgTmpDH * 10;
					gps_datas.data_RevWritesss.data_RevWrite.ChgDHtmp_h = (gps_data.RevWrite_data.ChgTmpDH  * 10)>> 8;
					///////////////////////////////////////////////////////////////////////////////////////////////////
					gps_datas.data_RevWritesss.data_RevWrite.SjRL_l = gps_data.RevWrite_data.CellRl * 10;
					gps_datas.data_RevWritesss.data_RevWrite.SjRL_h = (gps_data.RevWrite_data.CellRl  * 10)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.SyRL_l = Cell_Soc * 10;
					gps_datas.data_RevWritesss.data_RevWrite.SyRL_h = (Cell_Soc * 10)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.FCC_l = 0;
					gps_datas.data_RevWritesss.data_RevWrite.FCC_h = 0;

					gps_datas.data_RevWritesss.data_RevWrite.Statebit = 0;

					gps_datas.data_RevWritesss.data_RevWrite.bhrl = gps_data.RevWrite_data.DRLNum;

					gps_datas.data_RevWritesss.data_RevWrite.znum = gps_data.RevWrite_data.Cellnum;

					gps_datas.data_RevWritesss.data_RevWrite.RSNS_VALUE = 0;

					gps_datas.data_RevWritesss.data_RevWrite.CvolH_l = gps_data.RevWrite_data.SingvolGH;
					gps_datas.data_RevWritesss.data_RevWrite.CvolH_h = gps_data.RevWrite_data.SingvolGH >> 8;

					gps_datas.data_RevWritesss.data_RevWrite.QvolH_l = gps_data.RevWrite_data.SingvolQH;
					gps_datas.data_RevWritesss.data_RevWrite.QvolH_h = gps_data.RevWrite_data.SingvolQH >> 8;

					gps_datas.data_RevWritesss.data_RevWrite.CBvol_l = (u8)3000;
					gps_datas.data_RevWritesss.data_RevWrite.CBvol_h = (u8)((u16)(3000) >> 8);

					gps_datas.data_RevWritesss.data_RevWrite.Sleeptime_l = gps_data.RevWrite_data.SleepTime;
					gps_datas.data_RevWritesss.data_RevWrite.Sleeptime_h = gps_data.RevWrite_data.SleepTime >> 8;

					gps_datas.data_RevWritesss.data_RevWrite.HXCurr_l = (u8)2;
					gps_datas.data_RevWritesss.data_RevWrite.HXCurr_h = (u8)((u16)(2) >> 8);

					gps_datas.data_RevWritesss.data_RevWrite.erGcurr_l = (u8)80 * (400/6.1);
					gps_datas.data_RevWritesss.data_RevWrite.erGcurr_h = (u8)((u16)(80 * (400/6.1)) >> 8);

					gps_datas.data_RevWritesss.data_RevWrite.erGcurrtime_l = (u8)500;
					gps_datas.data_RevWritesss.data_RevWrite.erGcurrtimr_h = (u8)((u16)(500) >> 8);

					gps_datas.data_RevWritesss.data_RevWrite.ChgGcurr = gps_data.RevWrite_data.ChgcurrGtime;

	                gps_datas.data_RevWritesss.data_RevWrite.AFE1 = 11;

					gps_datas.data_RevWritesss.data_RevWrite.AFE2 = gps_data.RevWrite_data.Cellnum - 11;

					if(gps_data.RevWrite_data.Celltype == 0)
						gps_datas.data_RevWritesss.data_RevWrite.celltype = 1;
					else if(gps_data.RevWrite_data.Celltype == 1)
						gps_datas.data_RevWritesss.data_RevWrite.celltype = 0;
					else
						gps_datas.data_RevWritesss.data_RevWrite.celltype = gps_data.RevWrite_data.Celltype;

					gps_datas.data_RevWritesss.data_RevWrite.MOSCtmp_l = gps_data.RevWrite_data.PowTmp * 10;
					gps_datas.data_RevWritesss.data_RevWrite.MOSCtmp_h = (gps_data.RevWrite_data.PowTmp  * 10)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.MOSCHtmp_l = gps_data.RevWrite_data.PowTmpH * 10;
					gps_datas.data_RevWritesss.data_RevWrite.MOSCHtmp_h = (gps_data.RevWrite_data.PowTmpH  * 10)>> 8;

					gps_datas.data_RevWritesss.data_RevWrite.LDcurr_l = (u8)30;
					gps_datas.data_RevWritesss.data_RevWrite.LDcurr_h = (u8)((u16)(30) >> 8);

					gps_datas.data_RevWritesss.data_RevWrite.SleepLDcurr_l = (u8)10;
					gps_datas.data_RevWritesss.data_RevWrite.SleepLDcurr_h = (u8)((u16)(10) >> 8);;

					readdata_485();
					send_len = 75;
					memcpy(sendbuffer,gps_datas.data_RevWritesss.data,send_len);

				  Send_Gps2(bmsnum,orde,state,sendbuffer,send_len);

				}
				break;
				case GPSCOMMOND_0x41: //�����·�
				{
					u8 CelltypeLast = 0;
					u8 CellnumLast = 0;
					memcpy(gps_datas.data_RevWritesss.data,&Rev_GpsUsart1.gps_Rev_bufss[7],75);

					gps_data.RevWrite_data.SingvolG = (gps_datas.data_RevWritesss.data_RevWrite.Overvol_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.Overvol_l;

					gps_data.RevWrite_data.SingvolGtime = gps_datas.data_RevWritesss.data_RevWrite.Overvoltime;

					gps_data.RevWrite_data.SingvolQ = (gps_datas.data_RevWritesss.data_RevWrite.Qvol_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.Qvol_l;

					gps_data.RevWrite_data.SingvolQtime = gps_datas.data_RevWritesss.data_RevWrite.Qvoltime;

					gps_data.RevWrite_data.Equalivol = (gps_datas.data_RevWritesss.data_RevWrite.JHON_Vol_h << 8)| gps_datas.data_RevWritesss.data_RevWrite.JHON_Vol_l;

					gps_data.RevWrite_data.Equalivolcc = (gps_datas.data_RevWritesss.data_RevWrite.JhON_yc_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.JHON_yc_l;

					gps_data.RevWrite_data.OutcurrG = ((gps_datas.data_RevWritesss.data_RevWrite.OutcurrG_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.OutcurrG_l) / 10;

					gps_data.RevWrite_data.OutcurrGtime = ((gps_datas.data_RevWritesss.data_RevWrite.Outcurrtime_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.Outcurrtime_l) / 1000;

					gps_data.RevWrite_data.ChgcurrG = ((gps_datas.data_RevWritesss.data_RevWrite.ChgcurrG_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.ChgcurrG_l) / 10;

					gps_data.RevWrite_data.ChgcurrGtime = gps_datas.data_RevWritesss.data_RevWrite.Chgcurrtime;
					///////////////////////////////////////////////////////////////////////////////////////////////////
					gps_data.RevWrite_data.CellOutTmpG = ((gps_datas.data_RevWritesss.data_RevWrite.OutCtmp_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.OutCtmp_l) / 10;

					gps_data.RevWrite_data.CellOutTmpGH = ((gps_datas.data_RevWritesss.data_RevWrite.OutCHtmp_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.OutCHtmp_l) / 10;

					gps_data.RevWrite_data.OutTmpD = (s16)((gps_datas.data_RevWritesss.data_RevWrite.OutDtmp_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.OutDtmp_l) / 10;

					gps_data.RevWrite_data.OutTmpDH = (s16)((gps_datas.data_RevWritesss.data_RevWrite.OutDHtmp_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.OutDHtmp_l) / 10;
					////////////////////////////////////////////////////////////////////////////////////////////////
					gps_data.RevWrite_data.CellChgTmpG = ((gps_datas.data_RevWritesss.data_RevWrite.ChgCtmp_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.ChgCtmp_l) / 10;

					gps_data.RevWrite_data.CellChgTmpGH = ((gps_datas.data_RevWritesss.data_RevWrite.ChgCHtmp_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.ChgCHtmp_l) / 10;

					gps_data.RevWrite_data.ChgTmpD = (s16)((gps_datas.data_RevWritesss.data_RevWrite.ChgDtmp_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.ChgDtmp_l) / 10;

					gps_data.RevWrite_data.ChgTmpDH = (s16)((gps_datas.data_RevWritesss.data_RevWrite.ChgDHtmp_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.ChgDHtmp_l) / 10;
					///////////////////////////////////////////////////////////////////////////////////////////////////
					if(gps_data.RevWrite_data.CellRl != (((gps_datas.data_RevWritesss.data_RevWrite.SjRL_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.SjRL_l) / 10))
					{
						SOCinit = 0;
						SOCinit_bit = 0;
					}
					gps_data.RevWrite_data.CellRl = ((gps_datas.data_RevWritesss.data_RevWrite.SjRL_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.SjRL_l) / 10;
					//����ʵ������Լ��
					if(gps_data.RevWrite_data.Reali_Q > gps_data.RevWrite_data.CellRl)
						gps_data.RevWrite_data.Reali_Q = gps_data.RevWrite_data.CellRl;


					gps_data.RevWrite_data.DRLNum = gps_datas.data_RevWritesss.data_RevWrite.bhrl;

					CellnumLast = gps_datas.data_RevWritesss.data_RevWrite.znum; /////////////////

					gps_data.RevWrite_data.SingvolGH = (gps_datas.data_RevWritesss.data_RevWrite.CvolH_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.CvolH_l;

					gps_data.RevWrite_data.SingvolQH = (gps_datas.data_RevWritesss.data_RevWrite.QvolH_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.QvolH_l;

					gps_data.RevWrite_data.SleepTime = (gps_datas.data_RevWritesss.data_RevWrite.Sleeptime_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.Sleeptime_l;

					gps_data.RevWrite_data.ChgcurrGtime = gps_datas.data_RevWritesss.data_RevWrite.ChgGcurr;

          if(gps_datas.data_RevWritesss.data_RevWrite.celltype == 0)
						CelltypeLast = 1; //////////////////�������
					else if(gps_datas.data_RevWritesss.data_RevWrite.celltype == 1)
						CelltypeLast = 0;
					else
						CelltypeLast = gps_datas.data_RevWritesss.data_RevWrite.celltype;

					gps_data.RevWrite_data.PowTmp = ((gps_datas.data_RevWritesss.data_RevWrite.MOSCtmp_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.MOSCtmp_l) / 10;

					gps_data.RevWrite_data.PowTmpH = ((gps_datas.data_RevWritesss.data_RevWrite.MOSCHtmp_h << 8) | gps_datas.data_RevWritesss.data_RevWrite.MOSCHtmp_l) / 10;


					////////////////////////////////////////////////////////////////////
					if(gps_data.RevWrite_data.Celltype != CelltypeLast)
					{
						SOCinit_bit = 0;
						if(CelltypeLast == 0) //���
						{
							gps_data.RevWrite_data.SingvolG = 3650;
							gps_data.RevWrite_data.SingvolGtime = 2;
							gps_data.RevWrite_data.SingvolGH = 3600;
							gps_data.RevWrite_data.SingvolQ = 2300;
							gps_data.RevWrite_data.SingvolQtime = 2;
							gps_data.RevWrite_data.SingvolQH = 2400;
							gps_data.RevWrite_data.ChgcurrG = 20;
							gps_data.RevWrite_data.ChgcurrGtime = 4;
							gps_data.RevWrite_data.OutcurrG = 50;
							gps_data.RevWrite_data.OutcurrGtime = 8;
							gps_data.RevWrite_data.CellXyc = 1000;
							gps_data.RevWrite_data.Equalivol = 3300;
							gps_data.RevWrite_data.Equalivolcc = 5;
						}
						else if(CelltypeLast == 1) //��Ԫ
						{
							gps_data.RevWrite_data.SingvolG = 4250;
							gps_data.RevWrite_data.SingvolGtime = 2;
							gps_data.RevWrite_data.SingvolGH = 4200;
							gps_data.RevWrite_data.SingvolQ = 2800;
							gps_data.RevWrite_data.SingvolQtime = 2;
							gps_data.RevWrite_data.SingvolQH = 2900;
							gps_data.RevWrite_data.ChgcurrG = 20;
							gps_data.RevWrite_data.ChgcurrGtime = 4;
							gps_data.RevWrite_data.OutcurrG = 50;
							gps_data.RevWrite_data.OutcurrGtime = 8;
							gps_data.RevWrite_data.CellXyc = 1000;
							gps_data.RevWrite_data.Equalivol = 3600;
							gps_data.RevWrite_data.Equalivolcc = 5;
						}
						else if(CelltypeLast == 2) //�����
						{
							gps_data.RevWrite_data.SingvolG = 2300;
							gps_data.RevWrite_data.SingvolGtime = 2;
							gps_data.RevWrite_data.SingvolGH = 2250;
							gps_data.RevWrite_data.SingvolQ = 1500;
							gps_data.RevWrite_data.SingvolQtime = 2;
							gps_data.RevWrite_data.SingvolQH = 1600;
							gps_data.RevWrite_data.ChgcurrG = 20;
							gps_data.RevWrite_data.ChgcurrGtime = 4;
							gps_data.RevWrite_data.OutcurrG = 50;
							gps_data.RevWrite_data.OutcurrGtime = 8;
							gps_data.RevWrite_data.CellXyc = 1000;
							gps_data.RevWrite_data.Equalivol = 2000;
							gps_data.RevWrite_data.Equalivolcc = 5;
						}
					}

					if(gps_data.RevWrite_data.Cellnum != CellnumLast)
					{
						gps_data.RevWrite_data.ZvolG = gps_data.RevWrite_data.SingvolG / 10.0 * CellnumLast;
						gps_data.RevWrite_data.ZvolQ = gps_data.RevWrite_data.SingvolQ / 10.0 * CellnumLast;
					}

					readdata_485();
					gps_data.RevWrite_data.Celltype = CelltypeLast;
					gps_data.RevWrite_data.Cellnum = CellnumLast;

					//�洢����
					flash_write_sys_flag_ALL();

					//���ݷ���
					memset(sendbuffer,0,75);
					send_len = 0;
					//��������
					Send_Gps2(bmsnum,orde,state,sendbuffer,send_len);

				}
				break;
				case GPSCOMMOND_0x50: //�ָ���������
				{
					flash_write_sys_flag_ALL_Init();

					memset(sendbuffer,0,75);
					send_len = 0;
					//��������
					Send_Gps2(bmsnum,orde,state,sendbuffer,send_len);
//					__set_PRIMASK(1);
//					NVIC_SystemReset(); //����ϵͳ
				}
				break;
				case GPSCOMMOND_0x51: //�����µ�ַ
				{
					memset(sendbuffer,0,75);
					send_len = 0;
					//��������
					Send_Gps2(bmsnum,orde,state,sendbuffer,send_len);
				}
				break;
				case GPSCOMMOND_0x62: //����У׼
					gps_data.RevWrite_data.CurrjzONOFF = Rev_GpsUsart1.gps_Rev_bufss[6];
				  gps_data.RevWrite_data.CurrJZ = (Rev_GpsUsart1.gps_Rev_bufss[7] | (Rev_GpsUsart1.gps_Rev_bufss[8] << 8) | (Rev_GpsUsart1.gps_Rev_bufss[9] << 16) | (Rev_GpsUsart1.gps_Rev_bufss[10] << 24));

				  memset(sendbuffer,0,4);
				  memcpy(sendbuffer,&Rev_GpsUsart1.gps_Rev_bufss[7],4);
					send_len = 4;
					//��������
					Send_Gps2(bmsnum,orde,state,sendbuffer,send_len);
				break;
				case GPSCOMMOND_0x63: //��ȡUUID
				  memcpy(sendbuffer,&UUID,12);
					send_len = 12;
					//��������
					Send_Gps2(bmsnum,orde,state,sendbuffer,send_len);
				break;
				case GPSCOMMOND_0x22: //�رյ�Դ
				{
					u32 data = 0;
					data = (Rev_GpsUsart1.gps_Rev_bufss[7] | (Rev_GpsUsart1.gps_Rev_bufss[8] << 8) | (Rev_GpsUsart1.gps_Rev_bufss[9] << 16) | (Rev_GpsUsart1.gps_Rev_bufss[10] << 24));
					if(data == 0) //�򿪷ŵ�MOS��
					{
						Out_Lock = 0;
						if(OutMos_bit == 0)
						{
							RESETIO(DS_M);
							Free309DSGMos();
							OutMos_bit = 0;
						}
						else
						{
							if(Out_flag == 0)
							{
								RESETIO(DS_M);
								Free309DSGMos();
								OutMos_bit = 0;
							}
						}
					}
					else
					{
						Out_Lock = 1;
						SETIO(DS_M);							 //�رշŵ�MOS��
						Shut309DSGMos();
						OutMos_bit = 1;
					}
					flash_write_sys_flag(40);
				}
				break;
				case GPSCOMMOND_0x23: //�رյ�Դ
				{
					u32 data = 0;
					data = (Rev_GpsUsart1.gps_Rev_bufss[7] | (Rev_GpsUsart1.gps_Rev_bufss[8] << 8) | (Rev_GpsUsart1.gps_Rev_bufss[9] << 16) | (Rev_GpsUsart1.gps_Rev_bufss[10] << 24));
					if(data == 0) //�򿪳��MOS��
					{
						Chg_Lock = 0;
						if(ChgMos_bit == 0)
						{
							RESETIO(CH_M);
							Free309CHGMos();
							ChgMos_bit = 0;
						}
						else
						{
							if(Chg_Flag == 0)        //�ж��Ƿ��й���
							{
								RESETIO(CH_M);
								Free309CHGMos();
								ChgMos_bit = 0;
							}
						}
					}
					else						             //�رճ��MOS��
					{
						Chg_Lock = 1;
						SETIO(CH_M);
						Shut309CHGMos();
						ChgMos_bit = 1;
					}
					flash_write_sys_flag(39);
				}
				break;
				default:
				break;
			}
		}
		readdata_485();
		memset(Rev_GpsUsart1.gps_Rev_bufss,0,100);
		Uart1Flag_GPS = 0;
	}
}
******************/

