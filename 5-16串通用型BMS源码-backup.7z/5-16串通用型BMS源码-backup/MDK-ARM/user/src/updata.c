#include "stm32f10x_conf.h"
#include "stm32f10x.h"
#include "string.h"
#include "stdBool.h"
#include "stdio.h"
#include "stdlib.h"
#include "delay.h"
#include "iobind.h"
#include "updata.h"
#include "usart.h"
#include "stmflash.h"
#include "485.h"
#include "IIC.h"

pFunction Jump_To_Bootload;
uint32_t JumpAddress;

G4_Buf   updata = {0}; //����GPS���ݻ���
unsigned char    gnm_data_4G[544];	    //�Ӻ������ݻ���
unsigned char    sbuffer_4G[544];		  //Ҫ���͵����ݻ���
unsigned char    CRC_Cal_4G[544];		  //Ҫ���͵����ݻ���
u8 FontBuffer_Read2[2048] = {0};

u8 G4_Status = 0;

u16  UpdataReadDate = 0;
u16 G4_crc_data = 0;

u16 Page_2K = 0;
u8 k = 0;
u16 flashpassword = 0;
u8 Flash_Pack_Size = 0;

u16 Suoyi_Count = 0;

const u16 wCRCTalbeAbs[] =
{
    0x0000, 0xCC01, 0xD801, 0x1400, 0xF001, 0x3C00, 0x2800, 0xE401,
    0xA001, 0x6C00, 0x7800, 0xB401, 0x5000, 0x9C01, 0x8801, 0x4400
};


//У��ͣ�������+��״̬λ��+���ݳ���+��������  Modebus
u16 WordCRC16(u8 *pchMsg, u16 wDataLen)
{
    u16 wCRC = 0xFFFF;
    u16 i;
    u8 chChar;

    for(i = 0; i < wDataLen; i++)
    {
        chChar = *pchMsg++;
        wCRC = wCRCTalbeAbs[(chChar ^ wCRC) & 15] ^ (wCRC >> 4);
        wCRC = wCRCTalbeAbs[((chChar >> 4)^wCRC) & 15] ^ (wCRC >> 4);
    }

    return wCRC;
}


void R_4G_gnm_data_return(unsigned char order, u16 num, unsigned char* dtatas)
{
    u16 crc_data;
    u16 i = 0;
    memset(gnm_data_4G, 0, sizeof(gnm_data_4G));
    memset(CRC_Cal_4G, 0, sizeof(CRC_Cal_4G));
    gnm_data_4G[0] =  0x55;
    gnm_data_4G[1] =  0xAA;
    gnm_data_4G[2] =  order;
    gnm_data_4G[3] =  G4_Status;
    gnm_data_4G[4] =  num >> 8;
    gnm_data_4G[5] =  (u8)num;

    CRC_Cal_4G[0] = order;
    CRC_Cal_4G[1] = G4_Status;
    CRC_Cal_4G[2] = num >> 8;
    CRC_Cal_4G[3] = (u8)num;

    for(i = 0; i < num; i++)
    {
        gnm_data_4G[6 + i] = dtatas[i];
        CRC_Cal_4G[4 + i] = dtatas[i];

    }

    crc_data = WordCRC16(CRC_Cal_4G, num + 4);


    gnm_data_4G[6 + num] = crc_data >> 8;

    gnm_data_4G[6 + num + 1] = (u8)crc_data;
    gnm_data_4G[6 + num + 2] = 0x77;
    gnm_data_4G[6 + num + 3] = 0xEE;

    Send_TString_GPS(gnm_data_4G, num + 10);

}


void APP_TO_Bootload()
{

//    if (((*(__IO uint32_t*)Boot_ADDR) & 0x2FFE0000 ) == 0x20000000)
//    {
//        __set_PRIMASK(1);//�ر������ж�

//        //��ת��Bootload����
//        JumpAddress = *(__IO uint32_t*) (Boot_ADDR + 4);
//        Jump_To_Bootload = (pFunction) JumpAddress;
//        //��ʼ���û�����Ķ�ջָ��
//        __set_MSP(*(__IO uint32_t*) Boot_ADDR);
//        Jump_To_Bootload();
//    }

}


void G4DataHandle(void)
{
    u16 start_addr = 0;  //��ʼ��ַ
    u16 mum = 0;         //��������
    u16 datasss = 0;
    u16 Crc_num = 0;
    u16 Data_Length = 0;
    u16 i = 0;
    G4_crc_data = 0;

    /*����һ֡���ĳɹ�*/
    if(updata.G4_Rev_start == 1)
    {
        updata.G4_Rev_start = 0; //�����־λ

        /*���յ����������*/
        Data_Length = (updata.G4_Rev_buf[3] << 8 | updata.G4_Rev_buf[4]);
        G4_crc_data = WordCRC16(&(updata.G4_Rev_buf[2]), (Data_Length + 3));
        memset(sbuffer_4G, 0, sizeof(sbuffer_4G));
        Crc_num = Data_Length + 8;

        /*����Լ��*/
        if((unsigned char)(G4_crc_data >> 8) == updata.G4_Rev_buf[Crc_num - 3] && (unsigned char)(G4_crc_data) == updata.G4_Rev_buf[Crc_num - 2])
        {
            if(updata.G4_Rev_buf[0] == 0x55 & updata.G4_Rev_buf[1] == 0xAA)
            {

                switch(updata.G4_Rev_buf[2])
                {
                    case Cell_INF_4G: //��ػ�������
                    {

                    }
                    break;

                    case Singer_Cell_4G:  //�����ѹ����


                        mum = Bms_tt_data.Anal_quanuion.Anal_quan.Cores_num;
                        sbuffer_4G[0] = mum;

                        for(i = 1; i < mum * 2 + 1;)
                        {
                            sbuffer_4G[i]     = Bms_tt_data.Anal_quanuion.monis[start_addr] >> 8;
                            sbuffer_4G[i + 1] = Bms_tt_data.Anal_quanuion.monis[start_addr];

                            i += 2;
                            start_addr ++;
                        }

                        R_4G_gnm_data_return(Singer_Cell_4G, mum * 2 + 1, sbuffer_4G);


                        break;

                    case Temper_Cell_4G:	  //�¶Ȳ���

                        sbuffer_4G[0] = 3;
                        sbuffer_4G[1] = Bms_tt_data.Anal_quanuion.Anal_quan.Cores_Tmp;
                        sbuffer_4G[2] = Bms_tt_data.Anal_quanuion.Anal_quan.Ambi_Tmp;
                        sbuffer_4G[3] = Bms_tt_data.Anal_quanuion.Anal_quan.Card_Tmp;

                        R_4G_gnm_data_return(Temper_Cell_4G, 4, sbuffer_4G);

                        break;

                    case Get_Internet_4G:    //

                        break;

                    case Set_Internet_4G:     //

                        break;

                    case Get_Product_4G:      //������Ϣ


                        break;

                    case Control_4G: //

                        break;

                    case Send_Information_4G:     //

                        break;

                    case Updata_4G:      //
                        sbuffer_4G[0] = 0x52;
                        sbuffer_4G[1] = 0x53;
                        sbuffer_4G[2] = 0x54;
                        memset(FontBuffer_Read2, 0xFF, sizeof(FontBuffer_Read2));
                        Page_2K = 0;
                        updata.Update_SuoYin = 0;
                        Flash_Pack_Size = 0;
                        Suoyi_Count = 0;
                        R_4G_gnm_data_return(Reboot_4G, 3, sbuffer_4G);
                        printf("\r\n............��ʼ����............\r\n");

                        break;

                    case Reboot_4G: //
                        sbuffer_4G[0] = 0x52;
                        sbuffer_4G[1] = 0x53;
                        sbuffer_4G[2] = 0x54;


                        break;

                    case File_Size_4G:     //A2

                        memset(FontBuffer_Read2, 0xFF, sizeof(FontBuffer_Read2));
                        delay_ms(5);
                        FLASH_Unlock();

                        updata.G4_PACK_SIZE = updata.G4_Rev_buf[5] << 8 | updata.G4_Rev_buf[6];//���ݰ���С

                        updata.G4_PACK_Num = updata.G4_Rev_buf[7] << 8 | updata.G4_Rev_buf[8]; //���ݰ�����

                        updata.G4_File_SIZE = updata.G4_Rev_buf[9] << 24 | updata.G4_Rev_buf[10] << 16 | updata.G4_Rev_buf[11] << 8 | updata.G4_Rev_buf[12]; //�ļ���С

                        printf("���ݰ���С��%d   ���ݰ�������%d    �ļ���С��%d\r\n", updata.G4_PACK_SIZE, updata.G4_PACK_Num, updata.G4_File_SIZE);

                        // printf("\r\n............�ļ���С��%d............\r\n", updata.G4_File_SIZE);

                        //����������������
                        for(k = 0; k < FLASH_USER_SIZE / 2; k++)// FLASH_USER_SIZE:100
                        {
                            FLASH_ErasePage(k * 2048 + FLASH_APP2_ADDR);
                            delay_ms(10);
                        }

                        FLASH_Lock();

                        R_4G_gnm_data_return(File_Size_4G, 0, sbuffer_4G);

                        break;

                    case File_Send_4G:      //A3

                        updata.Updata_Time_Flag = 0;

                        //printf("��ʼ�����·������ļ���\r\n");
                        if(updata.Updata_Time_Count < Over_Time) //�ȴ�δ��ʱС��Over_Time ms

                        {
                            updata.Updata_Time_Count = 0;
                            updata.Update_SuoYin = updata.G4_Rev_buf[5] << 8 | updata.G4_Rev_buf[6]; //���ݰ�����
                            updata.Updata_Length = (updata.G4_Rev_buf[3] << 8 | updata.G4_Rev_buf[4]) - 2; //�����ļ����ݳ���

                            if(updata.G4_PACK_Num > 0)
                            {
                                // printf("��������:    %.1f%%\r\n", (float)((updata.Update_SuoYin * 100) / updata.G4_PACK_Num));

                            }

                            printf("���ݰ�������%d,����������%d\r\n", updata.Update_SuoYin, Suoyi_Count);

                            if(updata.Update_SuoYin < ( updata.G4_PACK_Num - 1)) //���ݰ�����С�����ݰ�����
                            {

                                if(updata.Update_SuoYin == Suoyi_Count)
                                {
                                    updata.Updata_Time_Flag = 1;

                                    memcpy(&(FontBuffer_Read2[Flash_Pack_Size * updata.Updata_Length]), &(updata.G4_Rev_buf[7]), updata.Updata_Length);
                                    delay_ms(5);
                                    Flash_Pack_Size++;
                                    Suoyi_Count++;

                                    if(Flash_Pack_Size == 4)
                                    {
                                        IapWrite_num(FontBuffer_Read2, FLASH_APP2_ADDR + 2048 * Page_2K, 2048);

                                        Page_2K++;

                                        memset(FontBuffer_Read2, 0xFF, sizeof(FontBuffer_Read2));

                                        Flash_Pack_Size = 0;

                                    }

                                }
                                else
                                {
                                    printf("���������ظ�\r\n");


                                }

                                G4_Status = 0x00;
                                delay_ms(10);
                                R_4G_gnm_data_return(File_Send_4G, 0, sbuffer_4G);



                            }

                            else if( updata.Update_SuoYin == (updata.G4_PACK_Num - 1))
                            {
                                memcpy(&(FontBuffer_Read2[Flash_Pack_Size * updata.Updata_Length]), &(updata.G4_Rev_buf[7]), updata.Updata_Length);
                                IapWrite_num(FontBuffer_Read2, FLASH_APP2_ADDR + 2048 * Page_2K, 2048);
                                memset(FontBuffer_Read2, 0xFF, sizeof(FontBuffer_Read2));
                                G4_Status = 0x00;
                                delay_ms(10);
                                R_4G_gnm_data_return(File_Send_4G, 0, sbuffer_4G);
                                Flash_Pack_Size = 0;
                                Suoyi_Count = 0;
                                updata.Updata_Data_OK = 1;
                                //  printf("��������2:    100%%\r\n");
                            }
                            else//�������ݴ���
                            {
                                printf("�������ݴ���\r\n");
                                memset(FontBuffer_Read2, 0xFF, sizeof(FontBuffer_Read2));
                                G4_Status = 0x83;
                                delay_ms(10);
                                R_4G_gnm_data_return(File_Send_4G, 0, sbuffer_4G);
                            }


                        }
                        else
                        {
                            Page_2K = 0;
                            updata.Updata_Time_Flag = 0;
                            updata.Updata_Time_Count = 0;
                            updata.Updata_Data_OK = 0;
                            Flash_Pack_Size = 0;
                            G4_Status = 0x82;
                            R_4G_gnm_data_return(End_Updata_4G, 0, sbuffer_4G);//�ȴ���ʱ���·���
                            printf("�����·��������ݳ�ʱ\r\n");

                        }

                        break;

                    case End_Updata_4G: //

                        if(updata.G4_Rev_buf[5] == 0x45 && updata.G4_Rev_buf[6] == 0x46 && updata.G4_Rev_buf[7] == 0x47)
                        {
                            Page_2K = 0;

                            //STMFLASH_Read(FLASH_APP2_ADDR_Password, &flashpassword, 1);

                            if(updata.Updata_Data_OK == 1)//���·����������ݰ���������

                            {
                                G4_Status = 0x84; //����������MCU����
                                R_4G_gnm_data_return(End_Updata_4G, 0, sbuffer_4G);
                                printf("���յ���������ָ��\r\n");

                                UpdataReadDate = 10;	//����������MCU������־
                                STMFLASH_Write(FLASH_UPDATE_ADDR, &UpdataReadDate, 1);

                                updata.Updata_Data_OK = 0;

                                __set_PRIMASK(1);//�ر����ж�

                                RESETIO(DC_Power); //DC������
                                delay_ms(2000);

                                //����
                                //	NVIC_SystemReset(); //����ϵͳ
                                //

                            }
                            else//���������쳣
                            {

                                updata.Updata_Data_OK = 0;

                                G4_Status = 0x82;

                                R_4G_gnm_data_return(End_Updata_4G, 0, sbuffer_4G);//����ʧ��

                                //��������������������������ԭ������
                                UpdataReadDate = 0;

                                STMFLASH_Write(FLASH_UPDATE_ADDR, &UpdataReadDate, 1);
                                __set_PRIMASK(1);//�ر����ж�

                                RESETIO(DC_Power); //DC������
                                delay_ms(2000);

                                NVIC_SystemReset(); //����ϵͳ

                            }


                        }

                        break;

                    default:
                        break;
                }
            }
        }
        else
        {

            G4_Status = 0x81; //CRCУ�����
            //485�ڼ��
            printf("\r\n CRCУ����� \r\n");

            if(Data_Length == 3 && updata.G4_Rev_buf[2] == 0xA1)
            {
                sbuffer_4G[0] = 0x52;
                sbuffer_4G[1] = 0x53;
                sbuffer_4G[2] = 0x54;
                R_4G_gnm_data_return(updata.G4_Rev_buf[2], 3, sbuffer_4G);

            }
            else if(updata.G4_Rev_buf[2] == 0xA3)
            {
                updata.Updata_Time_Flag = 0;
                updata.Updata_Time_Count = 0;
                R_4G_gnm_data_return(updata.G4_Rev_buf[2], 0, sbuffer_4G);

            }
            else
            {
                R_4G_gnm_data_return(updata.G4_Rev_buf[2], 0, sbuffer_4G);

            }


            //���ͷ�������
            updata.G4_Rev_buftmp = 0;  //������������
            UartData4GMsCnt = 0;
            UartData4GMsCntEnable = 0;
            memset(updata.G4_Rev_buf, 0, sizeof(updata.G4_Rev_buf));
        }

        /*�����������*/
        Uart14GNWDataFlag = 0;
        memset(updata.G4_Rev_buf, 0, sizeof(updata.G4_Rev_buf));

    }
}
