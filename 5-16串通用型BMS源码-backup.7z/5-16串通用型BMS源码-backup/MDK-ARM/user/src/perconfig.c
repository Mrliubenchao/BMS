/*
*�ļ����ã����׮������������
*�ļ���дʱ�䣺2020��5��19��
*/
#include "stm32f10x_conf.h"
#include "stm32f10x.h"
#include "button/iobutton.h"
#include "perconfig.h"
#include "stdio.h"
#include "iobind.h"

void USART1_Config_9600(void)
{
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    /* config USART1 clock */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    /* USART1 mode config */
    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No ;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);
    USART_Cmd(USART1, ENABLE);
    USART1->CR1 |= (1 << 5); //��5λ�жϿ���λ  ���������ж�
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
    /* Enable the USARTy Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void USART1_DeConfig_9600(void) //����ʼ��
{
//    NVIC_InitTypeDef NVIC_DeInitStructure;

//    /* config USART1 clock */
//    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE);
//    USART1->SR  = 0x00C0;
//    USART1->BRR = 0x0000;
//    USART1->CR1 = 0x0000;
//    USART1->CR2 = 0x0000;
//    USART1->CR3 = 0x0000;
//    USART1->GTPR = 0x0000;

//    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
//    /* Enable the USARTy Interrupt */
//    NVIC_DeInitStructure.NVIC_IRQChannel = USART1_IRQn;
//    NVIC_DeInitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//    NVIC_DeInitStructure.NVIC_IRQChannelSubPriority = 0;
//    NVIC_DeInitStructure.NVIC_IRQChannelCmd = DISABLE;
//    NVIC_Init(&NVIC_DeInitStructure);
}

void USART2_Config(void)
{
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    /* config USART1 clock */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
    /* USART2 mode config */
    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No ;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART2, &USART_InitStructure);
    USART_Cmd(USART2, ENABLE);

    USART2->CR1 |= (1 << 5); //��5λ�жϿ���λ  ���������ж�

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
    /* Enable the USARTy Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void USART3_Config(void)
{
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    /* config USART1 clock */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

    /* USART2 mode config */
    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No ;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART3, &USART_InitStructure);
    USART_Cmd(USART3, ENABLE);

    USART3->CR1 |= (1 << 5); //��5λ�жϿ���λ  ���������ж�

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
    /* Enable the USARTy Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}


void USART2_DeConfig_9600(void) //����ʼ��
{
//    NVIC_InitTypeDef NVIC_DeInitStructure;

//    /* config USART2 clock */
//    RCC_APB2PeriphClockCmd(RCC_APB1Periph_USART2, DISABLE);
//    USART2->SR  = 0x00C0;
//    USART2->BRR = 0x0000;
//    USART2->CR1 = 0x0000;
//    USART2->CR2 = 0x0000;
//    USART2->CR3 = 0x0000;
//    USART2->GTPR = 0x0000;

//    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
//    /* Enable the USARTy Interrupt */
//    NVIC_DeInitStructure.NVIC_IRQChannel = USART2_IRQn;
//    NVIC_DeInitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//    NVIC_DeInitStructure.NVIC_IRQChannelSubPriority = 0;
//    NVIC_DeInitStructure.NVIC_IRQChannelCmd = DISABLE;
//    NVIC_Init(&NVIC_DeInitStructure);
}

/*
*��������IniTime
*������������
*��������ֵ����
*�������ܣ�TIM2��ʱ1MS��ʼ����������������ʱ
*/
void InitTime(void)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    TIM_TimeBaseStructure.TIM_Period = 1000 - 1;   //�Զ���װ��ֵ
    TIM_TimeBaseStructure.TIM_Prescaler = 72 - 1;  //ʱ�ӷ�Ƶ��
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
    TIM_Cmd(TIM2, ENABLE);

    /* Enable the TIM2 global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

/*
*�������ܣ������ʼ������
*/
void allBaseInit(void)
{
    InitTime();
    USART1_Config_9600();
    USART2_Config();
    USART3_Config();

    USART_ITConfig(USART1, USART_IT_PE, ENABLE);  //����PE��������ж�Bit 8PEIE: PE interrupt enable
    USART_ITConfig(USART1, USART_IT_ERR, ENABLE);	//CR2 ����ERR�ж�
    USART_ITConfig(USART2, USART_IT_PE, ENABLE);  //����PE��������ж�Bit 8PEIE: PE interrupt enable
    USART_ITConfig(USART2, USART_IT_ERR, ENABLE);	//CR2 ����ERR�ж�
}

#if 1
//�ض���c�⺯��printf��USART1
int fputc(int ch, FILE *f)
{
    /* ����һ���ֽ����ݵ�USART1 */
    USART_SendData(USART2, (uint8_t) ch);

    /* �ȴ�������� */
    while (USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET);

    return (ch);
}

///�ض���c�⺯��scanf��USART1
int fgetc(FILE *f)
{
    /* �ȴ�����1�������� */
    while (USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == RESET);

    return (int)USART_ReceiveData(USART2);
}
#endif





