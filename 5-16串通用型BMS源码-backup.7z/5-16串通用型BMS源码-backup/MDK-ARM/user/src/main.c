#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#include "button/iobutton.h"
#include "timer/ntimer.h"
#include <string.h>
#include <stdBool.h>
#include <stdio.h>
#include <math.h>
#include "datahand.h"
#include "gpioinit.h"
#include "perconfig.h"
#include "delay.h"
#include "basetime.h"
#include "usart.h"
#include "iobind.h"
#include "joinbind.h"
#include "IIc.h"
#include "gpsnet.h"

#include "SH367309.h"
#include "485.h"
#include "stmflash.h"
#include "flash.h"
#include "Jdy_19.h"
#include "gps2.h"
#include "LCD.h"

//#define USE_CHG_CKH_HARDWARE

/*������ʱ������*/
AllTimer alltimer = {NULL, 8};
u16 ZeroCur_minute = 0;
u8  SpecChargerFlag = 0;


u8 Ble_TX_Control = 0;

u16 UartDataMsCnt;
u16 UartDataMsCnt2;
u16 UartDataTTCnt;
u16 UartDataMsCnt3;

u8  dahuo_flag;
u8  UartDataMsCntEnable;
u8  UartDataMsCntEnable2;
u8  UartDataTTCntEnable2;
u8  UartDataMsCntEnable3;

u8  UartData4GMsCntEnable;
u16 UartData4GMsCnt;

u8  OpenOrCloseChgMosCmd = 0;  //0�ر�
u8  OpenOrCloseDsgMosCmd = 0;
u8  ChgMosBreakCnt = 0;
u8  DsgMosBreakCnt = 0;
u8  start500_flag = 0 ;
u8  start500_1000flag = 0 ;
u8  end500_flag = 0 ;
u8  start1000_flag = 0 ;
u8  end1000_flag = 0 ;

RCC_ClocksTypeDef get_rcc_clock;//��ȡϵͳʱ����

u8 Uart1NW_GPS_StopFlag = 0;
u32 Uart1NW_GPS_StopTimeCount = 0;

u8  Alarm_SendFlag = 0;

u8 Alarm_5S = 0;

u8 RX_Control[8] = {0};
s8 RX_Control2[8] = {0};

/*ȫ�ֹر��ж�*/
void closeirq()
{
    __set_PRIMASK(1);
}
/*ȫ�ִ��ж�*/
void openirq()
{
    __set_PRIMASK(0);
}




u8 ReadChgMosState(void) //1���MOS����    0���MOS�ر�
{
    u8 buff[2] = {0};
    u8 tt = 0;
    MTPRead_fun_1( MTP_BSTATUS3,  1, &buff[0] );
    tt = buff[0] & 0x02;
    return tt;
}

u8 ReadDsgMosState(void) //1�ŵ�MOS����    0�ŵ�MOS�ر�
{
    u8 buff[2] = {0};
    u8 tt = 0;
    MTPRead_fun_1( MTP_BSTATUS3,  1, &buff[0] );
    tt = buff[0] & 0x01;
    return tt;
}

void Shut309DSGMos(void)
{
    u8 buff[2] = {0};
    MTPRead_fun_1( MTP_CONF,  1, &buff[0]);
    buff[0] &= (~0x20);
    MTPWrite_1(MTP_ID, MTP_CONF, buff[0]);
    OpenOrCloseDsgMosCmd = 0;
}

void Free309DSGMos(void)
{
    u8 buff[2] = {0};
    MTPRead_fun_1( MTP_CONF,  1, &buff[0]);
    buff[0] |= 0x20;
    MTPWrite_1(MTP_ID, MTP_CONF, buff[0]);
    OpenOrCloseDsgMosCmd = 1;

}

void Shut309CHGMos(void)
{
    u8 buff[2] = {0};
    MTPRead_fun_1( MTP_CONF,  1, &buff[0]);
    buff[0] &= (~0x10);
    MTPWrite_1(MTP_ID, MTP_CONF, buff[0]);
    OpenOrCloseChgMosCmd = 0;
}

void Free309CHGMos(void)
{
    u8 buff[2] = {0};
    MTPRead_fun_1( MTP_CONF,  1, &buff[0]);
    buff[0] |= 0x10;
    MTPWrite_1(MTP_ID, MTP_CONF, buff[0]);
    OpenOrCloseChgMosCmd = 1;
}

void Watch_dog(void)//���Ź�����
{
    RCC_LSICmd(ENABLE);
    IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);//д��0x5555,�����������Ź��Ĵ���д�빦��
    IWDG_SetPrescaler(IWDG_Prescaler_256); //���Ź�ʱ�ӷ�Ƶ��40KHz/256=156Hz(6.4ms)
    IWDG_SetReload(1800);              // 11S    ���26��(4095)
    IWDG_ReloadCounter();
    IWDG_Enable();
}

void PrintUart1And2Regs(void)
{
    u32 temp_uart_cr1 = 0;

}

//AT+OTAFM=http://47.115.171.177:8080/fm_bms/FM_MT309_OT2324.bin;

/*�����汾��*/
u8 soft_num_ZF[16] = {"FM_MT309_OT3208"};

unsigned char MainYe[7] = {0xA5, 0x5A, 0x04, 0x80, 0x03, 0x00, 0x00};
unsigned char ClearPhone[14] = {0xA5, 0x5A, 0x0B, 0x82, 0x06, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
unsigned char ClearPass[10] = {0xA5, 0x5A, 0x07, 0x82, 0x04, 0x40, 0x00, 0x00, 0x00, 0x00};

unsigned char RstBle[] = {"AT+RESET\r\n"};
u16 cont_b1e = 0;
u8  Reset_Hour_Flag = 0;
u8  Reset_Hour_Time = 0;

u8 UUID[12] = {0x01, 0x32, 0x02, 0x02, 0x96, 0x00, 0x20, 0x21, 0x01, 0x22, 0x00, 0x01};
u16 rjbb = 10112;  //�����汾��
u16 cellnumber = 0x01; //������к�
u8 RevBit = 0; //��ȡ�Ĵ������ݱ�־λ
u16 cont_num = 0;
u16 cont_num_2 = 0;
u16 circue_cont_num = 0;

u8 FirstStart = 0;
u8 FirstSOC = 0;
u8 FirstSOC_Count = 0;
u8 FirstStart_OV = 0;

/*������*/
int main(void)
{
    u8 i = 0;
    u8 TEMP9 = 0;
    u8 rbits = 1;
    u8 xnum = 0;
    u8 ChkGpsDataTimeS = 0;
    u8 ClearUartRegSecCnt = 0;
    static u8  flagtime_485 = 0;
    ShiDuFlag_OVER = 0;

    closeirq();
    UartDataMsCnt = 0;
    UartDataMsCnt2 = 0;
    UartDataMsCntEnable = 0;
    UartDataMsCntEnable2 = 0;

    SpecChargerFlag = 0;
    FirstStart = 0;
    Uart1NWDataFlag = 0;
    Uart2NWDataFlag = 0;

    ClearUartRegSecCnt = 0;

    Watch_dog();                      //���Ź���ʼ��
    Delay_init();                     //��શ�ʱ��
    base_gpio();                      //��ʼ��IO

    InitAllIO();                     /*io�ڼĴ�������������ʼ��*/

    delay_ms(5000);
    allBaseInit();                    //�����ʼ������
    InitAHT10();                      //��ʼ��ʪ�ȴ�����
    openirq();                        //��ȫ���ж�

    FInitNTimer();                    //��ʼ��������ʱ��
    timerbind();                      //��������ʱ��
    InputStructAssignment();   //�������ʼ��
    flash_read_sys_flag();     //ÿ�γ�ʼ���ȶ�ȡFLASH����

    RevBit = 1;
    delay_ms(1000);//��ʱ1��



    startTimeMs(&time_2000, 2000);
    startTimeMs(&time_5000, 5000);
    startTimeMs(&time_60000, 60000);


    while(1)
    {
        FNTImerTask();                  //CPU��ʱˢ�¶�ʱ��
        IWDG_ReloadCounter();           //ι��

        if(isTimerOut(&time_2000))      //2�����һ������
        {

            rbits = !rbits;

            xnum = 1;


            if(stopstart_309Flag == 0) RevResData(xnum); //��309оƬ����


            data309_485_GPS_handelFun();//BMS���ݴ���

            if(Reset_Hour_Flag == 1) //�����ر�10�����´�
            {

                Reset_Hour_Time++;

                if(Reset_Hour_Time >= 5)
                {
                    Reset_Hour_Time = 0;
                    Reset_Hour_Flag = 0;
                    SETIO(BLE_MOS);

                }

                Send_string_BLEReset(RstBle);

            }

        }

        if(isTimerOut(&time_5000))
        {
            ClearUartRegSecCnt++;

            ZeroCur_minute++;
         //   LCD_Write();//LCD ���� �����ϴ�

            if(ClearUartRegSecCnt >= 6)
            {
                ClearUartRegSecCnt = 0;
            }

            if(ZeroCur_minute >= 60)  ZeroCur5Min = 1;


        }

        if(isTimerOut(&time_60000) || Ble_TX_Control == 1)
        {
            cont_num++;
            cont_num_2++;
            circue_cont_num++;
            cont_b1e++;

            if(cont_b1e >= 60 || Ble_TX_Control == 1)//����1Сʱ��ʱ����
            {
                cont_b1e = 0;
                Ble_TX_Control = 0;
                Reset_Hour_Flag = 1;
                RESETIO(BLE_MOS);
                Send_string_BLEReset(RstBle);

            }

            if(cont_num >= 660)//11Сʱ�洢
            {
                cont_num = 0;
                flash_write_sys_flag(50);	    //�洢ϵͳʱ��
            }

            if(cont_num_2 >= 660)//1Сʱ�洢
            {
                cont_num_2 = 0;


            }

            if(circue_cont_num >= 659) //11Сʱ�洢
            {
                circue_cont_num = 0;
                flash_write_sys_flag(2);	    //ѭ���ŵ����洢

            }
        }

        //LCD��½���޲�����ʱ������ҳ
//        if(Login_TimeFlag == 1)
//        {

//            Send_string_Ye(ClearPhone, 14);//���ֻ���
//            delay_ms(200);
//            Send_string_Ye(ClearPass, 10);//������
//            delay_ms(200);
//            Send_string_Ye(MainYe, 7);//����ҳ
//            Login_TimeFlag = 0;

//        }


        JDYPortNwDataHandle();//��������ͨ��
        Rs485PortNWDataHandle();//485����ͨ��
        GpsPortNwDataHandle();//GPS���� ͨ��
       // LCD_DataHandle();//����������ͨ��

    }



}
