/*************************�˲���ΪSH367309����������ʹ��I2C��������*************************************/

#include "SH367309.h"
#include "IIC.h"
#include "usart.h"
#include "485.h"

#include "stdio.h"
#include "string.h"


extern unsigned char RevBit; //�Ƿ��ȡ 309���ݱ�־λ

Data_309buf  data_309_A = {0};  //��309�������  ���16������
Data_309buf  data_309_B = {0};  //��309�������  ���16������

/*
*оƬһ����
*оƬ������
*�˰汾Ϊֻ��309ARM���ݽ��д���
*/

/*��ȡ�Ĵ�������*/

void RevResData(u8 num)
{
    u8  buff[2] = {0};

    if(RevBit == 1)
    {
        if(num == 1)
        {
            MTPRead_fun_1( EEPROM_SCONF1,  1, &buff[0]);
            data_309_A.EEPROMRevdata.Sconf1.datas = buff[0];


            MTPRead_fun_1( EEPROM_TR,  1, &buff[0]);
            data_309_A.EEPROMRevdata.Tr = buff[0];


            MTPRead_fun_1( MTP_CONF,  1, &buff[0]);
            data_309_A.RAM_Revdata.Conf.datas = buff[0];

            MTPRead_fun_1( MTP_BALANCEH,  2, &buff[0]);
            data_309_A.RAM_Revdata.Balanceh_l.datas = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_BSTATUS1,  1, &buff[0]);
            data_309_A.RAM_Revdata.Bstrtus1.datas = buff[0];

            MTPRead_fun_1( MTP_BSTATUS2,  1, &buff[0]);
            data_309_A.RAM_Revdata.Bstrtus2.datas = buff[0];

            MTPRead_fun_1( MTP_BSTATUS3,  1, &buff[0]);
            data_309_A.RAM_Revdata.Bstrtus3.datas = buff[0];

            MTPRead_fun_1( MTP_TEMP1,  2, &buff[0]);
            data_309_A.RAM_Revdata.TEMP1h_l = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_TEMP2,  2, &buff[0]);
            data_309_A.RAM_Revdata.TEMP2h_l = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_TEMP3,  2, &buff[0]);
            data_309_A.RAM_Revdata.TEMP3h_l = (buff[0] << 8) | buff[1];

            buff[0] = 0;
            buff[1] = 0;
            MTPRead_fun_1( MTP_CUR,  2, &buff[0]);
            data_309_A.RAM_Revdata.Curh_l = (buff[0] << 8) | buff[1];


            MTPRead_fun_1( MTP_CELL1,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell1_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL2,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell2_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL3,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell3_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL4,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell4_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL5,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell5_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL6,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell6_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL7,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell7_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL8,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell8_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL9,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell9_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL10,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell10_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL11,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell11_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL12,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell12_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL13,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell13_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL14,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell14_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL15,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell15_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_CELL16,  2, &buff[0]);
            data_309_A.RAM_Revdata.Cell.cellbits.cell16_vol = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_ADC2,  2, &buff[0]);
            data_309_A.RAM_Revdata.CADcdh_l = (buff[0] << 8) | buff[1];

            MTPRead_fun_1( MTP_BFLAG1,  1, &buff[0]);
            data_309_A.RAM_Revdata.Bflag1.datas = buff[0];

            MTPRead_fun_1( MTP_BFLAG2,  1, &buff[0]);
            data_309_A.RAM_Revdata.Bflag2.datas = buff[0];
        }


    }
}
