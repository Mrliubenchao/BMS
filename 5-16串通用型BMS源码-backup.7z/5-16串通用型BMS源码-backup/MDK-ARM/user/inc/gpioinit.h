#ifndef _GPIOINIT_H_
#define _GPIOINIT_H_


extern void base_gpio(void);

extern void IIC_1_Init(unsigned char type);

#endif
