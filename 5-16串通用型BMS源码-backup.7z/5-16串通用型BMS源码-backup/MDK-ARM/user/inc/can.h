#ifndef _CAN_H_
#define _CAN_H_


#include "stm32f10x.h"

//����ͨ��
#define Cell_UpdataFile_INFO_ID      0x00850101 //�����ļ�
#define Cell_UpdataFile_CON_ID      0x00850102 //д���ļ�
#define Cell_UpdataFile_END_ID      0x00850103 //��������
#define Cell_UpdataRestart_SYS_ID      0x00850104 //����

//ϵͳͨ��
#define Cell_System_SN1_ID      0x00850201
#define Cell_System_Bootload_Ver_ID      0x00850202

#define Cell_System_APP_Ver_ID      0x00850203
#define Cell_System_RecData_ID      0x00850204
#define Cell_System_SedData_ID      0x00850205
#define Cell_System_Repair_ID      0x0085020A
#define Cell_System_Transport_ID      0x0085020B
#define Cell_System_RepairBack_ID      0x0085020C

//����ͨ��
#define BMS_Fuction_ALL_GROUP_STATE_ID      0x00850301
#define BMS_Fuction_Get_GROUP1_STATE1_ID    0x00850302
#define BMS_Fuction_Get_GROUP1_STATE2_ID    0x00850303

#define BMS_Fuction_Get_V0l_1_4_ID     0x00850307
#define BMS_Fuction_Get_V0l_5_8_ID     0x00850308
#define BMS_Fuction_Get_V0l_9_12_ID    0x00850309
#define BMS_Fuction_Get_V0l_13_16_ID   0x0085030A
#define BMS_Fuction_Get_V0l_17_20_ID   0x0085030B

#define BMS_Fuction_Get_NTC_ID    0x0085030E

extern u8 SN[18];

extern u8 RX_IT[8];

extern u8 Can_Out_Flag;
extern u8 Can_Chg_Flag;
extern u8 Can_OutChg_Flag;
/*����*/
typedef struct
{
	u32 sw_ver;
	u8 hw_ver;
	
	
}ver_info;


typedef struct
{	
	u8 sn[14];
		
}sn_t;  //���룬ΨһID


typedef struct
{	
	u8 shift;
	u8 err_code;
		
}mcu_state_t;  //���룬ΨһID

typedef struct
{
	u16 Parm1;
	u16 Parm2;
    u16 Parm3;
	u16 Parm4;
	
	
}bms_u16_t;


typedef struct
{
	u8 Parm1;
	u8 Parm2;
    u8 Parm3;
	u8 Parm4;
	u8 Parm5;
	u8 Parm6;
    u8 Parm7;
	u8 Parm8;
	
	
}bms_u8_t;




typedef struct
{
	u32 Stand_ID;
	u32 Exd_ID;
	u8 length;
	u8 Data[8];
	u8 RTR;

		
}can_rec_msg;


typedef struct
{
	u32 Stand_ID;
	u32 Exd_ID;
	u8 length;
	u8 Data[2048];
    u8 SendData[2048];
	u8 RTR;

		
}can_long_msg;





extern u8 Can_Rec_Flag;
extern u8 BMS_Rec_Flag;
extern u8 BMS_Long_Flag;
extern can_rec_msg Can_Rec_Data;
extern can_rec_msg BMS_Rec_Data;
extern can_long_msg BMS_Long_Data;
extern u8  start500_flag ;
extern u8  end500_flag ;
extern u8  start1000_flag ;
extern u8  end1000_flag ;
extern void can_init(void);
extern void Can_Stand_WriteData(u32 Stand_Can_ID, u8 *WriteData,u8 length);
extern void Can_Ext_WriteData(u32 Exd_CAN_ID, u8 *WriteData, u8 length);
extern void Can_Long_SendData(u32 Long_ID,u8 *Data,u16 DataLength)	;
extern void MingTang500ms_CANSendData(void);
extern void MingTang1000ms_CANSendData(void);
extern void CHG_Power_SendData(void);
//extern void Can_Ext_WriteData(u32 Exd_CAN_ID, u8 length);





#endif

