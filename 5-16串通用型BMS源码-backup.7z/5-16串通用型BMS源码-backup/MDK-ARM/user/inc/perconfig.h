#ifndef _PERCONFIG_H_
#define _PERCONFIG_H_
#include "stm32f10x.h"

extern void allBaseInit(void);

extern void USART1_Config_9600(void);	

extern void USART2_Config(void); 
extern void USART3_Config(void); 

#endif
